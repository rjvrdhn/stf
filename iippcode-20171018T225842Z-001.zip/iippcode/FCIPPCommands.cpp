// FCIPPCommands.cpp: implementation of the CFCIPPCommands class.

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	A macro that defines window 32 lean and mean. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers

#include <windows.h>
#if __cplusplus
extern "C" {
#endif
#include "http-private.h"   // Cups external library
#if __cplusplus
}
#endif
#include <stdio.h>
#include <vector>
#include <string>
using namespace std;

#include "StringExtensions.h"
#include "Device.h"
#include "FCIPPCommands.h"
#include "FCIPPJobObject.h"
#include "harmony10.h"
#include "JobConfDefines.h"
#include <sys/stat.h>

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Constructor. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pDevice">	[in,out] If non-null, the device. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

CFCIPPCommands::CFCIPPCommands(CDevice* pDevice) : CFCIPPCommandsBase(pDevice)
{
	m_bProtocolCreatedAndReady = true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Destructor. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

CFCIPPCommands::~CFCIPPCommands()
{
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets the device's ppd. </summary>
///
/// <remarks>	</remarks>
///
/// <returns>	An UINT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommands::GetDevicePPD()
{
	// Don/Jeff to do
//	return GetPPD();
	return NO_ERROR;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Print job. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pSubJob">	[in,out] If non-null, the sub job. </param>
///
/// <returns>	An UINT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommands::PrintJob(CSubJob* pSubJob)
{
	UINT uiError = NO_ERROR;

	if (NULL == pSubJob)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPCommands::PrintJob: Invalid param.");
        return ERROR_INVALID_DATA;
	}

	bool bJobRequiresFakeSuspend = false;
	bool bRequiresSpecialLargeJobProcessing = false;
	bool bRequiresSpecialJobIDProcessing = false;
	bool bJobFailedSendingToDevice = false;
	bool bPartOfSplitJob = false;
	bool bIsFirstSubJobOfJob = false;

	if (m_bRequiresSpecialLargeJobSupport)
	{
		struct stat fileinfo;
		stat(pSubJob->m_strJobFilename.c_str(), &fileinfo);

		if ((long)fileinfo.st_size > m_iSpecialLargeJobSupportSize)
		{
			bRequiresSpecialLargeJobProcessing = true;
			if (m_iCheckJobProgessPrintingState != CHECK_JOB_PROGESS_NONE)
			{
				bJobRequiresFakeSuspend = true;
				IncrementFakeJobsSuspendedOnDevice();
			}
		}
	}

	SetSpecialJobProcessing(bRequiresSpecialLargeJobProcessing, false);
	SetPrintJobInProgress();

	CJob* pParent = pSubJob->GetParentJob();
	CSubJobArray* pSubJobArray = pParent->GetSubJobArray();
	CSubJob* pFirstSubJob = pSubJobArray->at(0);
	CCollatedJob* pCollatedJob = pSubJob->GetDeviceReadyJob();
	string strJobName = pCollatedJob->GetJobAttribute(JOB_CONF_FC_JOBNAME);

	if (pSubJob->GetParentJob()->IsCancelled())
	{
		CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPCommands::PrintJob: %s Device %s, Job \"%s\"", GetErrorMessage(ERROR_DEVICE_JOB_CANCELLED_BY_USER).c_str(), GetDeviceID().c_str(), strJobName.c_str());

		if (bRequiresSpecialLargeJobProcessing || bRequiresSpecialJobIDProcessing)
			ResetSpecialJobProcessing();

		ResetPrintJobInProgress();
		return ERROR_DEVICE_JOB_CANCELLED_BY_USER;
	}

	if (pFirstSubJob->m_uiSubJobPrintNumber == pSubJob->m_uiSubJobPrintNumber)
		bIsFirstSubJobOfJob = true;

	CDevicePrintJob* pDevicePrintJob = new CDevicePrintJob(pSubJob);
	if (pDevicePrintJob)
	{
		bool bSaved = false;
		bool bAddDevicePrintJob = false;
		uiError = pDevicePrintJob->UpdateDevicePrintJobWithSubJob(pParent, pSubJob, strJobName, bJobRequiresFakeSuspend, m_bAddIDToUserNameForJobMappingID);
		if (uiError != NO_ERROR)
			return uiError;

		if ((int)pParent->GetSubJobArray()->size() > 1)
			bPartOfSplitJob = true;

		pSubJob->m_strRemoteJobID = FormatString("%d", pSubJob->m_uiSubJobPrintNumber);
		string strJLJobID = pSubJob->m_strRemoteJobID;
		CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPCommands::PrintJob: Device %s, add Job: \"%s\" Username: \"%s\" FieryCentral Job Folder: FCSubJob_%d, SubJob ID: %d to JobList", GetDeviceID().c_str(), strJobName.c_str(), pDevicePrintJob->m_strActualUserNameSentToDevice.c_str(), pSubJob->m_uiJobPrintNumber, pSubJob->m_uiSubJobPrintNumber);
		DeviceProtocolRemoteJobIDCallback(pSubJob, true);

		CFCIPPConnectionObject* pFCIPPConnectionObject = GetIPPConnectionObject();
		if (pFCIPPConnectionObject)
		{
			m_pDevicePrintJobCache->AddDevicePrintJob(pDevicePrintJob);
			bAddDevicePrintJob = true;

			uiError = pFCIPPConnectionObject->OpenIPPConnection();
			if (NO_ERROR == uiError)
			{
				CFCIPPJobObject* pFCIPPJobObject = new CFCIPPJobObject(this, pFCIPPConnectionObject, pDevicePrintJob);
				if (pFCIPPJobObject)
				{
					uiError = (UINT)pFCIPPConnectionObject->StartIPPPrintJob(pFCIPPJobObject);

					if (NO_ERROR == uiError)
					{
						uiError = (UINT)pFCIPPJobObject->SendJob();

						if (uiError == IPPLIB_JOBSEND_TIMEOUT_ERROR)
						{
							bJobFailedSendingToDevice = true;
							pDevicePrintJob = NULL;
						}
						else
						{
							// We at least tried to send the job to the device, pass or not we need to start the job poll list counting
							pDevicePrintJob->m_bStartJobListPollCounters = true;

							if ((NO_ERROR == uiError) && (!pSubJob->m_strRemotePQMID.empty() && (pSubJob->m_strRemotePQMID != "0")))
							{
								// Before updating the remote job id we want to make sure the job hasn't completed printing
								//  and/or been removed from our chache. This prevents a potential crash when attempting
								//  to update a job that has already completed.
								CDevicePrintJob* pReferenceDevicePrintJob = m_pDevicePrintJobCache->GetDevicePrintJobFromJLJobID(strJLJobID);
								if (pReferenceDevicePrintJob)
								{
									pDevicePrintJob->m_strJLPQMID = pSubJob->m_strRemotePQMID;
									if ((pReferenceDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_DONE_PRINTING) &&
										(pReferenceDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_CANCELLED) &&
										(pReferenceDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_ABORTED))
									{
										CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPCommands::PrintJob: Device %s, update Job: \"%s\" Username: \"%s\" FieryCentral Job Folder: FCSubJob_%d, SubJob ID: %d to JobList", GetDeviceID().c_str(), strJobName.c_str(), pDevicePrintJob->m_strActualUserNameSentToDevice.c_str(), pSubJob->m_uiJobPrintNumber, pSubJob->m_uiSubJobPrintNumber);
										DeviceProtocolRemoteJobIDCallback(pSubJob, false);
									}
									else
									{
										CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPCommands::PrintJob: Device %s, Skipped update Job: \"%s\" SubJob ID: %d Job already done", GetDeviceID().c_str(), strJobName.c_str(), strJLJobID);
									}
									m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(strJLJobID);
								}
								else
								{
									CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPCommands::PrintJob: Device %s, Skipped update Job: \"%s\" SubJob ID: %d No Longer in Cache", GetDeviceID().c_str(), strJobName.c_str(), strJLJobID);
								}

								pDevicePrintJob->m_bJobSentToDevice = true;
								bSaved = true;
							}
							else
							{
								if (!pSubJob->m_strProjectedRemotePQMID.empty() && !m_bIPPErrorOnJobID0)
								{
									CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPCommands::PrintJob: Device %s, Job \"%s\" Subjob username = %s_%s, setting ProjectedRemotePQMID of %s", GetDeviceID().c_str(), strJobName.c_str(), pSubJob->m_strJobUserName.c_str(), pSubJob->m_strRemoteJobID.c_str(), pSubJob->m_strProjectedRemotePQMID.c_str());
									pDevicePrintJob->m_bJobContainsProjectedJobID = true;
									pDevicePrintJob->m_iEventType = HARMONY_JOBEVENTTYPE_REDIRECT_START;
									pDevicePrintJob->m_strJLPQMID = pSubJob->m_strProjectedRemotePQMID;
									pDevicePrintJob->m_strProjectedRemotePQMID = pSubJob->m_strProjectedRemotePQMID;

									if (!bRequiresSpecialLargeJobProcessing)
									{
										bRequiresSpecialJobIDProcessing = true;
										SetSpecialJobProcessing(false, bRequiresSpecialJobIDProcessing);
									}
								}
								else
									bJobFailedSendingToDevice = true;
							}
						}
					}

					delete pFCIPPJobObject;
				}
				else
				{
					// Failed to create new CFCIPPJobObject so job was never sent.
					bJobFailedSendingToDevice = true;
				}

				pFCIPPConnectionObject->CloseIPPConnection();
			}
			else
			{
				// Failed to open connection so job was never sent.
				bJobFailedSendingToDevice = true;
			}

			if (!bSaved && !bJobFailedSendingToDevice)
			{
				if (WasJobSentSuccessfullyToTheDevice(pDevicePrintJob))
				{
					if (pDevicePrintJob->m_bJobVerifiedOnDevice)
					{
						pSubJob->m_strRemotePQMID = pDevicePrintJob->m_strJLPQMID;
						CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPCommands::PrintJob: Device %s, Job \"%s\" ProjectedRemotePQMID of %s successfully mapped", GetDeviceID().c_str(), strJobName.c_str(), pSubJob->m_strProjectedRemotePQMID.c_str());
					}
					else
						CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPCommands::PrintJob: Device %s, Job \"%s\" ProjectedRemotePQMID of %s not successfully mapped", GetDeviceID().c_str(), strJobName.c_str(), pSubJob->m_strProjectedRemotePQMID.c_str());

					DeviceProtocolRemoteJobIDCallback(pSubJob, false);

					// Erasing the m_strProjectedRemotePQMID tells the IPP connection object that the callback to the
					// device manager was made. This is important because we don't want to start sending
					// job list updates before trying to fix the bad job list ID.
					pSubJob->m_strProjectedRemotePQMID.erase();
					pDevicePrintJob->m_bJobSentToDevice = true;
					bSaved = true;
				}
				else
					bJobFailedSendingToDevice = true;
			}

			delete pFCIPPConnectionObject;
		}
		else
		{
			uiError = IPPLIB_CONNECT_FAILED;
			CLogUtils::LOG_UTILS_EX(eERROR, "CFCIPPCommands::PrintJob: Device %s, IPP Connection failure.", GetDeviceID().c_str());
		}

		if (IPPLIB_JOBSEND_TIMEOUT_ERROR != uiError)
		{
			if (bJobFailedSendingToDevice)
			{
				pParent->SetCancelReason(CANCEL_JOB_BY_DEVICE);
				pParent->SetCancelStatus(CANCEL_JOB_FAILED);

				if (bIsFirstSubJobOfJob)
				{
					pParent->SetCancelled();
					DeviceProtocolRemoteJobIDCallback(pSubJob, false);
				}
				else
				{
					pParent->SetSubJobPrintAborted(true);
					pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_ERRORED;
					bSaved = true;
				}

				string strLogMsg = FormatString("CFCIPPCommands::PrintJob: Device %s, Sending PrintJob %s failed so it had to be cancelled. IPP Error = %d", GetDeviceID().c_str(), strJobName.c_str(), uiError);
				CLogUtils::LOG_UTILS_ERROR(strLogMsg);

				uiError = ERROR_JOB_SUBJOB_SEND_FAILURE;
			}

			if (!bSaved)
			{
				if (bAddDevicePrintJob)
					m_pDevicePrintJobCache->RemoveDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
				else
					delete pDevicePrintJob;

				pDevicePrintJob = NULL;
			}

			// Only want to delay when there is a Job ID of 0 to give the engine time
			//  to prevent the next job we send from running to the same issue.
			if (pSubJob->m_strRemotePQMID.empty() || (pSubJob->m_strRemotePQMID == "0"))
			{
				if (bPartOfSplitJob)
					Sleep(m_iIPPPrintThreadSubsetDelay);
				else
					Sleep(m_iIPPPrintThreadDelay);
			}
		}
	}

	if (bRequiresSpecialLargeJobProcessing || bRequiresSpecialJobIDProcessing)
		ResetSpecialJobProcessing();

	ResetPrintJobInProgress();

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets device unfiltered job list. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pJobList">	[in,out] If non-null, list of jobs. </param>
///
/// <returns>	The device unfiltered job list. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommands::GetDeviceUnfilteredJobList(CJobList* pJobList)
{
	UINT uiError = NO_ERROR;

	if (!m_bUsesJobListModule)
		return uiError;

	if (NULL == pJobList)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPCommands::GetDeviceUnfilteredJobList: Invalid param.");
        return IPPLIB_INVALID_PARAM;
	}

	CFCIPPConnectionObject* pFCIPPConnectionObject = GetIPPConnectionObject();

	if (pFCIPPConnectionObject)
	{
		uiError = pFCIPPConnectionObject->OpenIPPConnection();

		if (IPPLIB_SUCCESS == uiError)
		{
			CDeviceJobList::FreeJobList(pJobList);
			EnterCriticalSection(&m_csDeviceJobList);

			bool bJobCompleted = false;
			bool bMyJobsOnly = false;
			bool bMonitorJobStatus = false;
			uiError = (UINT)pFCIPPConnectionObject->GetIPPJobList(pJobList, bMyJobsOnly, bJobCompleted, bMonitorJobStatus);

			LeaveCriticalSection(&m_csDeviceJobList);

			pFCIPPConnectionObject->CloseIPPConnection();
		}

		delete pFCIPPConnectionObject;
	}
	else
	{
		uiError = IPPLIB_CONNECT_FAILED;
		CLogUtils::LOG_UTILS_EX(eERROR, "CFCIPPCommands::GetDeviceUnfilteredJobList: Device %s, IPP Connection failure.", GetDeviceID().c_str());
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Was job sent successfully to the device. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pDevicePrintJob">	[in,out] If non-null, the job base. </param>
///
/// <returns>	true if it succeeds, false if it fails. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

bool CFCIPPCommands::WasJobSentSuccessfullyToTheDevice(CDevicePrintJob* pDevicePrintJob)
{
	bool bJobSentSuccessfullyToTheDevice = false;
	int iJobWaitCounter = 0;

	while (!m_bShuttingdown && !pDevicePrintJob->m_bJobVerifiedOnDevice && (iJobWaitCounter < m_iIPPWaitForJobDelayLimit))
	{
		UINT uiResult = WaitForSingleObject(m_hIPPJobMappedEvent, 5000);
		switch (uiResult)
		{
			case WAIT_TIMEOUT:
				++iJobWaitCounter;
				break;
			case WAIT_OBJECT_0:
			default:
				break;
		}
	}

	if (pDevicePrintJob->m_bJobVerifiedOnDevice)
		bJobSentSuccessfullyToTheDevice = true;

	CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPCommands::WasJobSentSuccessfullyToTheDevice %s, Job \"%s\", JLJobID %s, JLPQMID %s, Job Wait Counter %d",
		bJobSentSuccessfullyToTheDevice ? "True" : "False", pDevicePrintJob->m_strJobName.c_str(), pDevicePrintJob->m_strJLJobID.c_str(),
		pDevicePrintJob->m_strJLPQMID.c_str(), iJobWaitCounter);

	return bJobSentSuccessfullyToTheDevice;
}
