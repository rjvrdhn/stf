// CFCIPPCommandsBase.cpp: implementation of the CFCIPPCommandsBase class.

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	A macro that defines window 32 lean and mean. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers, Needed with CUPS

#include <windows.h>
#if __cplusplus
extern "C" {
#endif
#include "http-private.h"   // Cups external library
#if __cplusplus
}
#endif

#include "Device.h"
#include "FCIPPCommandsBase.h"
#include "DeviceSetupInfoParser.h"
#include "harmony10.h"
#include "FCIPPJobObject.h"
#include "DeviceStatus.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Constructor. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pDevice">	[in,out] If non-null, the device. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

CFCIPPCommandsBase::CFCIPPCommandsBase(CDevice* pDevice) : CFCProtocolBase(pDevice, DEVICE_USES_IPP, (HINSTANCE)&__ImageBase)
{
	m_strDeviceIPPVersion = m_pDevice->GetDeviceIPPVersion();
	m_iIPPMaxThreads = m_pDevice->GetDeviceIPPMaxThreads();
	m_iIPPMaxThreadsDelay = m_pDevice->GetDeviceIPPMaxThreadsDelay();
	m_iIPPPrintThreadDelay = m_pDevice->GetDeviceIPPPrintThreadDelay();
	m_iIPPPrintThreadSubsetDelay = m_pDevice->GetDeviceIPPPrintThreadSubsetDelay();
	m_iIPPWaitForJobDelayLimit = m_pDevice->GetDeviceIPPWaitForJobDelayLimit();
	m_bIPPRecoverFromBadJobID = m_pDevice->DoesDeviceIPPRecoverFromBadJobID();
	m_bIPPErrorOnJobID0 = m_pDevice->DoesDeviceIPPErrorOnJobID0();

	m_bRequiresSpecialLargeJobSupport = m_pDevice->DoesDeviceRequireSpecialLargeJobSupport();
	m_iSpecialLargeJobSupportSize = m_pDevice->GetSpecialLargeJobSupportSize();
	m_iCheckJobProgessPrintingState = m_pDevice->GetCheckJobProgessPrintingState();
	m_bUseJobNameToGetJobID = m_pDevice->DoesDevicePerformAccountTracking();
	m_pMediaTypeUtilities = m_pDevice->GetMediaTypeUtilities();
	m_pPaperTypeUtilities = m_pDevice->GetPaperTypeUtilities();

	m_hIPPJobMappedEvent = CreateEvent(NULL, false, false, NULL);
	m_hSpecialJobProcessingEvent = CreateEvent(NULL, false, false, NULL);

	m_pFCIPPDeviceMonitorConnectionObject = NULL;
	m_bDeviceStatusInitialized = false;
	m_bDeviceJobListInitialized = false;
	m_iLastDeviceJobListID = -1;
	m_iNumJobsInJobList = 0;
	m_iFakeJobsSuspendedOnDevice = 0;
	m_bJobsSuspendedOnDevice = false;
	m_bStopConnectionsForSpecialJobProcessing = false;

	InitializeCriticalSection(&m_csIPPRequestID);
	InitializeCriticalSection(&m_csIPPConnection);
	InitializeCriticalSection(&m_csIPPCheckConnections);
	InitializeCriticalSection(&m_csLastDeviceJobListID);
	InitializeCriticalSection(&m_csSpecialJobProcessing);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Destructor. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

CFCIPPCommandsBase::~CFCIPPCommandsBase()
{
	ShutDownDeviceMonitoringServices();

	FreeIPPConnectionObjectMap();

	if (m_pFCIPPDeviceMonitorConnectionObject)
		delete m_pFCIPPDeviceMonitorConnectionObject;

	DeleteCriticalSection(&m_csIPPRequestID);
	DeleteCriticalSection(&m_csIPPConnection);
	DeleteCriticalSection(&m_csIPPCheckConnections);
	DeleteCriticalSection(&m_csLastDeviceJobListID);
	DeleteCriticalSection(&m_csSpecialJobProcessing);

	CloseHandle(m_hIPPJobMappedEvent);
	CloseHandle(m_hSpecialJobProcessingEvent);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Free ipp connection object map. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CFCIPPCommandsBase::FreeIPPConnectionObjectMap()
{
	CFCIPPConnectionObject* pFCIPPConnectionObject = NULL;
	CFCIPPConnectionObjectMap::iterator iter;
	EnterCriticalSection(&m_csIPPConnection);

	for (iter=m_FCIPPConnectionObjectMap.begin(); iter!=m_FCIPPConnectionObjectMap.end(); iter++)
	{
		pFCIPPConnectionObject = (CFCIPPConnectionObject*)iter->second;

		if (pFCIPPConnectionObject)
		{
			pFCIPPConnectionObject->SetConnectionID(-1);
			delete pFCIPPConnectionObject;
			pFCIPPConnectionObject = NULL;
		}
	}

	m_FCIPPConnectionObjectMap.clear();

	LeaveCriticalSection(&m_csIPPConnection);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Increment fake jobs suspended on device. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CFCIPPCommandsBase::IncrementFakeJobsSuspendedOnDevice()
{
	++m_iFakeJobsSuspendedOnDevice;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Decrement fake jobs suspended on device. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CFCIPPCommandsBase::DecrementFakeJobsSuspendedOnDevice()
{
	if (m_iFakeJobsSuspendedOnDevice == 0)
		CLogUtils::LOG_UTILS_ERROR("CFCIPPCommandsBase::DecrementFakeJobsSuspendedOnDevice: Decrement was called when there were no fake jobs suspended");
	else
		--m_iFakeJobsSuspendedOnDevice;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets ipp connection object. </summary>
///
/// <remarks>	</remarks>
///
/// <returns>	null if it fails, else the ipp connection object. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

CFCIPPConnectionObject* CFCIPPCommandsBase::GetIPPConnectionObject()
{
	CFCIPPConnectionObject* pFCIPPConnectionObject = NULL;
	EnterCriticalSection(&m_csIPPCheckConnections);

	while (!m_bShuttingdown && ((int)m_FCIPPConnectionObjectMap.size() >= m_iIPPMaxThreads))
	{
		UINT uiResult = WaitForSingleObject(m_hShutdownEvent, m_iIPPMaxThreadsDelay);
		switch (uiResult)
		{
			case WAIT_TIMEOUT:
				break;
			case WAIT_OBJECT_0:
			default:
				return NULL;
				break;
		}
	}

	if (m_bShuttingdown)
		return NULL;

	pFCIPPConnectionObject = new CFCIPPConnectionObject(this);

	if (pFCIPPConnectionObject)
	{
		EnterCriticalSection(&m_csIPPConnection);
		pFCIPPConnectionObject->SetConnectionID(GetNextIPPConnectionID());
		m_FCIPPConnectionObjectMap.insert(CFCIPPConnectionObjectMap::value_type(pFCIPPConnectionObject->GetConnectionID(), pFCIPPConnectionObject));
		LeaveCriticalSection(&m_csIPPConnection);
	}

	LeaveCriticalSection(&m_csIPPCheckConnections);

	return pFCIPPConnectionObject;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sets number jobs in job list. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="iNumJobsInJobList">	Number of jobs in job lists. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CFCIPPCommandsBase::SetNumJobsInJobList(int iNumJobsInJobList)
{
	if ((m_iNumJobsInJobList != iNumJobsInJobList) || (iNumJobsInJobList > 10))
		CLogUtils::LOG_UTILS_EX(eDEBUG, "GetNumJobsInList: Number of Jobs = %d, Device %s", iNumJobsInJobList, m_strDeviceID.c_str());

	m_iNumJobsInJobList = iNumJobsInJobList;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Removes the ipp connection identifier described by uiConnectionID. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="uiConnectionID">	Identifier for the connection. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CFCIPPCommandsBase::RemoveIPPConnectionID(UINT uiConnectionID)
{
	if (uiConnectionID != -1)
	{
		EnterCriticalSection(&m_csIPPConnection);

		CFCIPPConnectionObjectMap::iterator iter = m_FCIPPConnectionObjectMap.find(uiConnectionID);

		if (iter != m_FCIPPConnectionObjectMap.end())
		{
			// Do not delete the CFCIPPConnectionObject here.
			// just remove it from the map.
			m_FCIPPConnectionObjectMap.erase(iter);
		}

		LeaveCriticalSection(&m_csIPPConnection);
	}	
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets the next ipp request identifier. </summary>
///
/// <remarks>	</remarks>
///
/// <returns>	The next ipp request identifier. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommandsBase::GetNextIPPRequestID()
{
	EnterCriticalSection(&m_csIPPRequestID);

	UINT uiIPPRequestID = atoi(CRegistryUtils::GetIPPRequestID().c_str());
	++uiIPPRequestID;

	string strIPPRequestID = FormatString("%u", uiIPPRequestID);

	if (!strIPPRequestID.empty())
		CRegistryUtils::SetIPPRequestID(strIPPRequestID);

	LeaveCriticalSection(&m_csIPPRequestID);

	return uiIPPRequestID;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets the next ipp connection identifier. </summary>
///
/// <remarks>	</remarks>
///
/// <returns>	The next ipp connection identifier. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommandsBase::GetNextIPPConnectionID()
{
	UINT uiIPPConnectionID = atoi(CRegistryUtils::GetIPPConnectionID().c_str());
	++uiIPPConnectionID;

	string strIPPConnectionID = FormatString("%u", uiIPPConnectionID);

	if (!strIPPConnectionID.empty())
		CRegistryUtils::SetIPPConnectionID(strIPPConnectionID);

	return uiIPPConnectionID;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Opens protocol connection. </summary>
///
/// <remarks>	</remarks>
///
/// <returns>	An UINT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommandsBase::OpenProtocolConnection()
{
	UINT uiError = NO_ERROR;

	if (NULL == m_pFCIPPDeviceMonitorConnectionObject)
		m_pFCIPPDeviceMonitorConnectionObject = new CFCIPPConnectionObject(this);

	if (m_pFCIPPDeviceMonitorConnectionObject)
	{
		uiError = m_pFCIPPDeviceMonitorConnectionObject->OpenIPPConnection();
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Closes protocol connection. </summary>
///
/// <remarks>	</remarks>
///
/// <returns>	An UINT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommandsBase::CloseProtocolConnection()
{
	UINT uiError = NO_ERROR;

	if (m_pFCIPPDeviceMonitorConnectionObject)
	{
		m_pFCIPPDeviceMonitorConnectionObject->CloseIPPConnection();
//		delete m_pFCIPPDeviceMonitorConnectionObject;
//		m_pFCIPPDeviceMonitorConnectionObject = NULL;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets device job list ex. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pJobList">		  	[in,out] If non-null, list of jobs. </param>
/// <param name="bInitialJobList">	true to initial job list. </param>
///
/// <returns>	An UINT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommandsBase::GetDeviceJobListEx(CJobList* pJobList, bool bInitialJobList)
{
	UINT uiError = NO_ERROR;

	if (!m_bUsesJobListModule)
		return uiError;

	if ((NULL == pJobList) || (NULL == m_pFCIPPDeviceMonitorConnectionObject))
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPCommandsBase::GetDeviceJobListEx: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	EnterCriticalSection(&m_csDeviceJobList);
	CDeviceJobList::FreeJobList(pJobList);

	if (bInitialJobList && m_bDeviceJobListInitialized)
	{
		CDeviceJobList::CopyJobList(&m_CurrLocalDeviceJobList, pJobList);
		LeaveCriticalSection(&m_csDeviceJobList);
		return uiError;
	}

	bool bJobCompleted = false;
	bool bStopConnectionsForCancellingJobsProcessing = false;
	bool bMyJobsOnly = true;
	bool bMonitorJobStatus = true;
	uiError = (UINT)m_pFCIPPDeviceMonitorConnectionObject->GetIPPJobList(pJobList, bMyJobsOnly, bJobCompleted, bMonitorJobStatus);

	if (uiError == NO_ERROR)
	{
		m_iSequentialJobListPollingFailures = 0;

		if (!m_bDeviceJobListInitialized)
			m_bDeviceJobListInitialized = true;

		if (bInitialJobList)
			CDeviceJobList::CopyJobList(pJobList, &m_CurrLocalDeviceJobList);
	}
	else
	{
		++m_iSequentialJobListPollingFailures;

		if (m_pPrevLocalDeviceJobList && (m_CurrLocalDeviceJobList.size() == 0))
		{
			// No new job list, reuse the previous one for this cycle
			CDeviceJobList::CopyJobList(m_pPrevLocalDeviceJobList, &m_CurrLocalDeviceJobList);

			// Remove all jobs in the current list that have m_bRemoveJobfromJobList == true
			CDevicePrintJob* pDevicePrintJob = NULL;
			CDevicePrintJob* pReferenceDevicePrintJob = NULL;
			for (int i=(int)m_CurrLocalDeviceJobList.size()-1; i>=0; i--)
			{
				pDevicePrintJob = m_CurrLocalDeviceJobList.at(i);
				if (pDevicePrintJob)
				{
					pReferenceDevicePrintJob = m_pDevicePrintJobCache->GetDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
					if (pReferenceDevicePrintJob)
					{
						string strJLJobId = pDevicePrintJob->m_strJLJobID;
						if (pReferenceDevicePrintJob->m_bJobCancelledByFieryCentral)
						{
							if (m_iSequentialJobListPollingFailures < 4)
								bStopConnectionsForCancellingJobsProcessing = true;
						}

						if (pReferenceDevicePrintJob->m_bRemoveCancelledJobFromJobList)
						{
							// Remove job from our current job list
							delete pDevicePrintJob;
							pDevicePrintJob = NULL;
							m_CurrLocalDeviceJobList.erase(m_CurrLocalDeviceJobList.begin()+i);
						}

						m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(strJLJobId);
						pReferenceDevicePrintJob = NULL;
					}
				}
			}
		}
	
		// If connections are frozen do to processing a large job, cancelling jobs or any other special case don't return error 
		if (m_bStopConnectionsForSpecialJobProcessing || bStopConnectionsForCancellingJobsProcessing)
		{
			CLogUtils::LOG_UTILS_DEBUG("CFCIPPCommandsBase::GetDeviceJobListEx: GetJobListFailed while sending a large job. Resetting error code to 0");
			uiError = NO_ERROR;
		}
	}

	LeaveCriticalSection(&m_csDeviceJobList);

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets device media catalog ex. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pstrMediaCatalog">	   	[in,out] If non-null, the pstr media catalog. </param>
/// <param name="bInitialMediaCatalog">	true to initial media catalog. </param>
///
/// <returns>	An UINT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommandsBase::GetDeviceMediaCatalogEx(string* pstrMediaCatalog, bool bInitialMediaCatalog)
{
	UINT uiError = NO_ERROR;

	if (!m_bUsesImportMediaCatalogModule)
		return uiError;

	if ((NULL == pstrMediaCatalog) || (NULL == m_pFCIPPDeviceMonitorConnectionObject))
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPCommandsBase::GetDeviceMediaCatalogEx: Invalid param.");
        return IPPLIB_INVALID_PARAM;
	}

	EnterCriticalSection(&m_csDeviceMediaCatalog);

	if (bInitialMediaCatalog && m_bDeviceMediaCatalogInitialized)
	{
		*pstrMediaCatalog = m_strCurrLocalDeviceMediaCatalog;
		LeaveCriticalSection(&m_csDeviceMediaCatalog);
		return uiError;
	}

	pstrMediaCatalog->erase();

	uiError = m_pFCIPPDeviceMonitorConnectionObject->GetIPPMediaList(pstrMediaCatalog);

	if (!m_bDeviceMediaCatalogInitialized)
		m_bDeviceMediaCatalogInitialized = true;

	if (bInitialMediaCatalog)
		m_strCurrLocalDeviceMediaCatalog = *pstrMediaCatalog;

	LeaveCriticalSection(&m_csDeviceMediaCatalog);

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets the device's status. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pDeviceStatus"> 	[in,out] If non-null, the device's status. </param>
/// <param name="bInitialStatus">	true if initial status request. </param>
///
/// <returns>	An UINT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommandsBase::GetDeviceStatusEx(CDeviceStatus* pDeviceStatus, bool bInitialStatus)
{
	UINT uiError = NO_ERROR;

	if (!m_bUsesStatusModule)
		return uiError;

	if ((NULL == pDeviceStatus) || (NULL == m_pFCIPPDeviceMonitorConnectionObject))
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPCommandsBase::GetDeviceStatusEx: Invalid param.");
        return IPPLIB_INVALID_PARAM;
	}

	EnterCriticalSection(&m_csDeviceStatus);

	if (bInitialStatus && m_bDeviceStatusInitialized)
	{
		pDeviceStatus->Copy(&m_CurrLocalDeviceStatus);
		LeaveCriticalSection(&m_csDeviceStatus);
		return uiError;
	}

	pDeviceStatus->Reset();
	pDeviceStatus->SetConnection(m_strDeviceIPAddress);
	pDeviceStatus->SetModelName(m_strDeviceName);
	pDeviceStatus->SetDeviceID(m_strDeviceID);
	pDeviceStatus->SetDeviceName(m_strDeviceName);
	pDeviceStatus->SetDevicePrettyName(m_strDevicePrettyName);
	pDeviceStatus->SetDeviceClusterArray(m_strDeviceClusterArray);
	pDeviceStatus->SetDeviceSupportsRecoverFromSleep(m_bDeviceSupportsRecoverFromSleep);
	pDeviceStatus->InitForNewStatusCycle();

	IPPPRINTERSTATE State;
	IPPPRINTERSTATEREASONSTRUCT Reason;
	PRTIPPDETAILEDMSG pMsg = NULL;
	bool bInErrorState = false;
	bool bInWarnState = false;
	string strValue;

	uiError = (UINT)m_pFCIPPDeviceMonitorConnectionObject->GetIPPPrinterState(&State, &Reason, &pMsg);

	if (IPPLIB_SUCCESS == uiError)
	{
		pDeviceStatus->SetStatusValid(true);
		strValue.erase();

		int iDeviceStatus = (int)State;
		CPrinterInfo PrinterInfo = pDeviceStatus->GetPrinterInfo(); 
		PrinterInfo.m_strDeviceModelName = pDeviceStatus->GetModelName();
		PrinterInfo.m_uiDeviceStatus = pDeviceStatus->GetDeviceStatus();
		pDeviceStatus->SetPrinting(false);
		pDeviceStatus->SetPaused(false);

		switch(iDeviceStatus)
		{
			case IPP_PRT_STATE_UNKNOWN:
				pDeviceStatus->SetGeneralStatus(EM_OFFLINE);
				PrinterInfo.m_strGeneralStatus = LoadStringEx(IDS_SNMP_OFFLINE);
				PrinterInfo.m_strDeviceStatus = LoadStringFromID(IDS_SNMP_UNKNOWN);
				break;
			case IPP_PRT_STATE_IDLE:
				pDeviceStatus->SetGeneralStatus(EM_IDLE);
				PrinterInfo.m_strGeneralStatus = LoadStringFromID(IDS_SNMP_IDLE);
				PrinterInfo.m_strDeviceStatus = LoadStringEx(IDS_SNMP_RUNNING);
				strValue = LoadStringFromID(IDS_SNMP_IDLE);
				break;
			case IPP_PRT_STATE_STOPPED:
				pDeviceStatus->SetPaused(true);
				pDeviceStatus->SetGeneralStatus(EM_OFFLINE);
				PrinterInfo.m_strGeneralStatus = LoadStringEx(IDS_SNMP_OFFLINE);
				PrinterInfo.m_strDeviceStatus = LoadStringEx(IDS_SNMP_DOWN);
				break;
			case IPP_PRT_STATE_PROCESSING:
				// If error recovery is not desired for the engine, override this virtual method
				// to false because if engine is printing, the PSM will not send another job to
				// the printer until it has stopped.  
				if (_EnableEnginePrintingStatus())
				{
					PrinterInfo.m_strDeviceStatus = LoadStringFromID(IDS_SNMP_PRINTING);
					PrinterInfo.m_strGeneralStatus = LoadStringFromID(IDS_SNMP_PRINTING);
					pDeviceStatus->SetGeneralStatus(EM_PRINTING);
					pDeviceStatus->SetPrinting(true);
					strValue = LoadStringFromID(IDS_SNMP_PRINTING);
				}
				else
				{
					PrinterInfo.m_strDeviceStatus = LoadStringFromID(IDS_SNMP_IDLE);
					PrinterInfo.m_strGeneralStatus = LoadStringFromID(IDS_SNMP_IDLE);
					pDeviceStatus->SetGeneralStatus(EM_IDLE);
					strValue = LoadStringFromID(IDS_SNMP_IDLE);
				}
				break;
			default:
				// See Don if this happens. We may want to add more cases.
				pDeviceStatus->SetDeviceStatus(MIB_DEVICE_STATUS_UNKNOWN);
				break;
		}

		 pDeviceStatus->SetPrinterInfo(PrinterInfo);

		if (!strValue.empty())
		{
			pDeviceStatus->AddStatusString(strValue);
			pDeviceStatus->AddDisplayString(strValue);
		}

		for (int i=0; i<Reason.nCount; i++)
		{
			strValue = Reason.Strings[i];
			CStringUtils::MakeLower(strValue);

			if (!bInErrorState)
			{
				if (strValue.find("error") != -1)
					bInErrorState = true;
			}
			
			if (!bInErrorState && !bInWarnState)
			{
				if (strValue.find("warning") != -1)
					bInWarnState = true;
			}

			switch (Reason.Reasons[i])
			{
				case PRT_STATE_REASON_OTHER:
				case PRT_STATE_REASON_OTHER_REPORT:
				case PRT_STATE_REASON_OTHER_WARNING:
				case PRT_STATE_REASON_OTHER_ERROR:
					break;
				case PRT_STATE_REASON_NONE:
				case PRT_STATE_REASON_NONE_REPORT:
				case PRT_STATE_REASON_NONE_WARNING:
				case PRT_STATE_REASON_NONE_ERROR:
					break;
				case PRT_STATE_REASON_MEDIA_NEEDED:
				case PRT_STATE_REASON_MEDIA_NEEDED_REPORT:
				case PRT_STATE_REASON_MEDIA_NEEDED_WARNING:
				case PRT_STATE_REASON_MEDIA_NEEDED_ERROR:
					break;
				case PRT_STATE_REASON_MEDIA_JAM:
				case PRT_STATE_REASON_MEDIA_JAM_REPORT:
				case PRT_STATE_REASON_MEDIA_JAM_WARNING:
				case PRT_STATE_REASON_MEDIA_JAM_ERROR:
					pDeviceStatus->SetJam(true);
					break;
				case PRT_STATE_REASON_MOVING_TO_PAUSED:
				case PRT_STATE_REASON_MOVING_TO_PAUSED_REPORT:
				case PRT_STATE_REASON_MOVING_TO_PAUSED_WARNING:
				case PRT_STATE_REASON_MOVING_TO_PAUSED_ERROR:
					break;
				case PRT_STATE_REASON_PAUSED:
				case PRT_STATE_REASON_PAUSED_REPORT:
				case PRT_STATE_REASON_PAUSED_WARNING:
				case PRT_STATE_REASON_PAUSED_ERROR:
					pDeviceStatus->SetPaused(true);
					break;
				case PRT_STATE_REASON_STOPPED:
				case PRT_STATE_REASON_STOPPED_REPORT:
				case PRT_STATE_REASON_STOPPED_WARNING:
				case PRT_STATE_REASON_STOPPED_ERROR:
					break;
				case PRT_STATE_REASON_SHUTDOWN:
				case PRT_STATE_REASON_SHUTDOWN_REPORT:
				case PRT_STATE_REASON_SHUTDOWN_WARNING:
				case PRT_STATE_REASON_SHUTDOWN_ERROR:
					pDeviceStatus->SetPowerOff(true);
					break;
				case PRT_STATE_REASON_CONNECTING_TO_DEVICE:
				case PRT_STATE_REASON_CONNECTING_TO_DEVICE_REPORT:
				case PRT_STATE_REASON_CONNECTING_TO_DEVICE_WARNING:
				case PRT_STATE_REASON_CONNECTING_TO_DEVICE_ERROR:
					break;
				case PRT_STATE_REASON_TIMED_OUT:
				case PRT_STATE_REASON_TIMED_OUT_REPORT:
				case PRT_STATE_REASON_TIMED_OUT_WARNING:
				case PRT_STATE_REASON_TIMED_OUT_ERROR:
					break;
				case PRT_STATE_REASON_STOPPING:
				case PRT_STATE_REASON_STOPPING_REPORT:
				case PRT_STATE_REASON_STOPPING_WARNING:
				case PRT_STATE_REASON_STOPPING_ERROR:
					break;
				case PRT_STATE_REASON_STOPPED_PARTLY:
				case PRT_STATE_REASON_STOPPED_PARTLY_REPORT:
				case PRT_STATE_REASON_STOPPED_PARTLY_WARNING:
				case PRT_STATE_REASON_STOPPED_PARTLY_ERROR:
					break;
				case PRT_STATE_REASON_TONER_LOW:
				case PRT_STATE_REASON_TONER_LOW_REPORT:
				case PRT_STATE_REASON_TONER_LOW_WARNING:
				case PRT_STATE_REASON_TONER_LOW_ERROR:
					pDeviceStatus->SetMarkerLow(true);
					break;
				case PRT_STATE_REASON_TONER_EMPTY:
				case PRT_STATE_REASON_TONER_EMPTY_REPORT:
				case PRT_STATE_REASON_TONER_EMPTY_WARNING:
				case PRT_STATE_REASON_TONER_EMPTY_ERROR:
					pDeviceStatus->SetMarkerOut(true);
					break;
				case PRT_STATE_REASON_SPOOL_AREA_FULL:
				case PRT_STATE_REASON_SPOOL_AREA_FULL_REPORT:
				case PRT_STATE_REASON_SPOOL_AREA_FULL_WARNING:
				case PRT_STATE_REASON_SPOOL_AREA_FULL_ERROR:
					break;
				case PRT_STATE_REASON_COVER_OPEN:
				case PRT_STATE_REASON_COVER_OPEN_REPORT:
				case PRT_STATE_REASON_COVER_OPEN_WARNING:
				case PRT_STATE_REASON_COVER_OPEN_ERROR:
					pDeviceStatus->SetCoverOpen(true);
					break;
				case PRT_STATE_REASON_INTERLOCK_OPEN:
				case PRT_STATE_REASON_INTERLOCK_OPEN_REPORT:
				case PRT_STATE_REASON_INTERLOCK_OPEN_WARNING:
				case PRT_STATE_REASON_INTERLOCK_OPEN_ERROR:
					pDeviceStatus->SetCoverOpen(true);
					break;
				case PRT_STATE_REASON_DOOR_OPEN:
				case PRT_STATE_REASON_DOOR_OPEN_REPORT:
				case PRT_STATE_REASON_DOOR_OPEN_WARNING:
				case PRT_STATE_REASON_DOOR_OPEN_ERROR:
					pDeviceStatus->SetCoverOpen(true);
					break;
				case PRT_STATE_REASON_INPUT_TRAY_MISSING:
				case PRT_STATE_REASON_INPUT_TRAY_MISSING_REPORT:
				case PRT_STATE_REASON_INPUT_TRAY_MISSING_WARNING:
				case PRT_STATE_REASON_INPUT_TRAY_MISSING_ERROR:
					pDeviceStatus->SetTrayNotReady(true);
					break;
				case PRT_STATE_REASON_MEDIA_LOW:
				case PRT_STATE_REASON_MEDIA_LOW_REPORT:
				case PRT_STATE_REASON_MEDIA_LOW_WARNING:
				case PRT_STATE_REASON_MEDIA_LOW_ERROR:
					break;
				case PRT_STATE_REASON_MEDIA_EMPTY:
				case PRT_STATE_REASON_MEDIA_EMPTY_REPORT:
				case PRT_STATE_REASON_MEDIA_EMPTY_WARNING:
				case PRT_STATE_REASON_MEDIA_EMPTY_ERROR:
					break;
				case PRT_STATE_REASON_OUTPUT_TRAY_MISSING:
				case PRT_STATE_REASON_OUTPUT_TRAY_MISSING_REPORT:
				case PRT_STATE_REASON_OUTPUT_TRAY_MISSING_WARNING:
				case PRT_STATE_REASON_OUTPUT_TRAY_MISSING_ERROR:
					break;
				case PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL:
				case PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL_REPORT:
				case PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL_WARNING:
				case PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL_ERROR:
					break;
				case PRT_STATE_REASON_OUTPUT_AREA_FULL:
				case PRT_STATE_REASON_OUTPUT_AREA_FULL_REPORT:
				case PRT_STATE_REASON_OUTPUT_AREA_FULL_WARNING:
				case PRT_STATE_REASON_OUTPUT_AREA_FULL_ERROR:
					break;
				case PRT_STATE_REASON_MARKER_SUPPLY_LOW:
				case PRT_STATE_REASON_MARKER_SUPPLY_LOW_REPORT:
				case PRT_STATE_REASON_MARKER_SUPPLY_LOW_WARNING:
				case PRT_STATE_REASON_MARKER_SUPPLY_LOW_ERROR:
					pDeviceStatus->SetMarkerLow(true);
					break;
				case PRT_STATE_REASON_MARKER_SUPPLY_EMPTY:
				case PRT_STATE_REASON_MARKER_SUPPLY_EMPTY_REPORT:
				case PRT_STATE_REASON_MARKER_SUPPLY_EMPTY_WARNING:
				case PRT_STATE_REASON_MARKER_SUPPLY_EMPTY_ERROR:
					pDeviceStatus->SetMarkerOut(true);
					break;
				case PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL:
				case PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL_REPORT:
				case PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL_WARNING:
				case PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL_ERROR:
					break;
				case PRT_STATE_REASON_MARKER_WASTE_FULL:
				case PRT_STATE_REASON_MARKER_WASTE_FULL_REPORT:
				case PRT_STATE_REASON_MARKER_WASTE_FULL_WARNING:
				case PRT_STATE_REASON_MARKER_WASTE_FULL_ERROR:
					break;
				case PRT_STATE_REASON_FUSER_OVER_TEMP:
				case PRT_STATE_REASON_FUSER_OVER_TEMP_REPORT:
				case PRT_STATE_REASON_FUSER_OVER_TEMP_WARNING:
				case PRT_STATE_REASON_FUSER_OVER_TEMP_ERROR:
					break;
				case PRT_STATE_REASON_FUSER_UNDER_TEMP:
				case PRT_STATE_REASON_FUSER_UNDER_TEMP_REPORT:
				case PRT_STATE_REASON_FUSER_UNDER_TEMP_WARNING:
				case PRT_STATE_REASON_FUSER_UNDER_TEMP_ERROR:
					break;
				case PRT_STATE_REASON_OPC_NEAR_EOL:
				case PRT_STATE_REASON_OPC_NEAR_EOL_REPORT:
				case PRT_STATE_REASON_OPC_NEAR_EOL_WARNING:
				case PRT_STATE_REASON_OPC_NEAR_EOL_ERROR:
					break;
				case PRT_STATE_REASON_OPC_LIFE_OVER:
				case PRT_STATE_REASON_OPC_LIFE_OVER_REPORT:
				case PRT_STATE_REASON_OPC_LIFE_OVER_WARNING:
				case PRT_STATE_REASON_OPC_LIFE_OVER_ERROR:
					break;
				case PRT_STATE_REASON_DEVELOPER_LOW:
				case PRT_STATE_REASON_DEVELOPER_LOW_REPORT:
				case PRT_STATE_REASON_DEVELOPER_LOW_WARNING:
				case PRT_STATE_REASON_DEVELOPER_LOW_ERROR:
					pDeviceStatus->SetMarkerLow(true);
					break;
				case PRT_STATE_REASON_DEVELOPER_EMPTY:
				case PRT_STATE_REASON_DEVELOPER_EMPTY_REPORT:
				case PRT_STATE_REASON_DEVELOPER_EMPTY_WARNING:
				case PRT_STATE_REASON_DEVELOPER_EMPTY_ERROR:
					pDeviceStatus->SetMarkerOut(true);
					break;
				case PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE:
				case PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE_REPORT:
				case PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE_WARNING:
				case PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE_ERROR:
//					pDeviceStatus->SetAvailable(false);
					break;
				default:
					// See Don if this happens
					CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPCommandsBase::GetDeviceStatusEx: Reason.Reasons[i] = %d Undefined.", Reason.Reasons[i]);
					break;
			}

			pDeviceStatus->AddStatusString(Reason.Strings[i]);
		}

		if (NULL != pMsg)
		{
			for (int i=0; i<pMsg->count; i++)
			{
				strValue = pMsg->msg[i];

				if (!strValue.empty())
				{
					CStringUtils::MakeLower(strValue);
									
					if (strValue.find("sleep") != -1)
						pDeviceStatus->SetSleep(true);
					else if (strValue.find("energy save mode") != -1)
						pDeviceStatus->SetSleep(true);

					pDeviceStatus->AddDisplayString(pMsg->msg[i]);
				}
			}
			m_pFCIPPDeviceMonitorConnectionObject->FreeIPPDetailedMsg(&pMsg);
		}

		pDeviceStatus->SetGeneralStatus(pDeviceStatus->GetCompiledGeneralStatus());
	}

	if (IPPLIB_SUCCESS != uiError)
	{
		pDeviceStatus->SetStatusValid(false);
		pDeviceStatus->SetGeneralStatus(EM_COMM_ERR);
	}

	if (bInitialStatus)
		m_CurrLocalDeviceStatus.Copy(pDeviceStatus);

	if (!m_bDeviceStatusInitialized)
		m_bDeviceStatusInitialized = true;

	LeaveCriticalSection(&m_csDeviceStatus);

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets number of jobs on device ex. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="iNumJobsInJobList">	[in,out] Number of jobs in job lists. </param>
///
/// <returns>	An UINT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommandsBase::GetNumberOfJobsOnDeviceEx(int& iNumJobsInJobList)
{
	UINT uiError = NO_ERROR;
	iNumJobsInJobList = 0;

	if (m_bUsesDeviceJobListMonitoring)
	{
		if (m_pFCIPPDeviceMonitorConnectionObject)
		{
			iNumJobsInJobList = GetNumJobsInJobList();
		}
		else
		{
			uiError = ERROR_DEVICE_NOT_INITIALIZED;
			CLogUtils::LOG_UTILS_ERROR("CFCIPPCommandsBase::GetNumberOfJobsOnDeviceEx: Device Monitor Connection unavailable.");
		}
	}
	else
	{
		CJobList JobList;
		uiError = GetDeviceUnfilteredJobList(&JobList);

		iNumJobsInJobList = (int)JobList.size();
		CDeviceJobList::FreeJobList(&JobList);
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Are jobs suspended on device ex. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="bJobSuspended">	[in,out] The job suspended. </param>
///
/// <returns>	An UINT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommandsBase::AreJobsSuspendedOnDeviceEx(bool& bJobSuspended)
{
	UINT uiError = NO_ERROR;
	bJobSuspended = false;

	if (m_bUsesDeviceJobListMonitoring)
	{
		if (m_pFCIPPDeviceMonitorConnectionObject)
		{
			bJobSuspended = AreJobsSuspended();
		}
		else
		{
			uiError = ERROR_DEVICE_NOT_INITIALIZED;
			CLogUtils::LOG_UTILS_ERROR("CFCIPPCommandsBase::AreJobsSuspendedOnDeviceEx: Device Monitor Connection unavailable.");
		}
	}
	else
	{
		CFCIPPConnectionObject* pFCIPPConnectionObject = GetIPPConnectionObject();
		if (pFCIPPConnectionObject)
		{
			uiError = pFCIPPConnectionObject->OpenIPPConnection();

			if (IPPLIB_SUCCESS == uiError)
			{
				EnterCriticalSection(&m_csDeviceJobList);

				CJobList JobList;
				bool bJobCompleted = false;
				bool bMyJobsOnly = false;
				bool bMonitorJobStatus = false;
				uiError = (UINT)pFCIPPConnectionObject->GetIPPJobList(&JobList, bMyJobsOnly, bJobCompleted, bMonitorJobStatus);
				CDeviceJobList::FreeJobList(&JobList);
				bJobSuspended = AreJobsSuspended();

				LeaveCriticalSection(&m_csDeviceJobList);
				pFCIPPConnectionObject->CloseIPPConnection();
			}

			delete pFCIPPConnectionObject;
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets device installable options ex. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pDeviceInstallableOptionsMap">	[in,out] If non-null, the device installable
/// 											options map. </param>
/// <param name="bInitialInstallableOptions">  	true to initial installable options. </param>
///
/// <returns>	An UINT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

UINT CFCIPPCommandsBase::GetDeviceInstallableOptionsEx(stringMap* pDeviceInstallableOptionsMap, bool bInitialInstallableOptions)
{
	UINT uiError = NO_ERROR;

	if (!m_bUsesInstallableOptionsModule)
		return uiError;

	if (NULL == pDeviceInstallableOptionsMap)
	{
 		CLogUtils::LOG_UTILS_DEBUG("CFCIPPCommandsBase::GetDeviceInstallableOptionsEx: Invalid param.");
		return ERROR_DEVICE_CONNECT;
	}

	EnterCriticalSection(&m_csDeviceInstallableOptions);

	if (bInitialInstallableOptions && m_bDeviceInstallableOptionsInitialized)
	{
		// Need to verify map copy  Don
		*pDeviceInstallableOptionsMap = m_CurrLocalDeviceInstallableOptionsMap;
		LeaveCriticalSection(&m_csDeviceInstallableOptions);
		return uiError;
	}

	m_CurrLocalDeviceInstallableOptionsMap.clear();

	CFCIPPConnectionObject* pFCIPPConnectionObject = GetIPPConnectionObject();

	// Don need to map PrtInfo to pDeviceInstallableOptionsMap for below
	if (pFCIPPConnectionObject)
	{
		uiError = pFCIPPConnectionObject->OpenIPPConnection();

		if (IPPLIB_SUCCESS == uiError)
		{
			IPPPRINTERINFO PrtInfo;
			uiError = pFCIPPConnectionObject->GetIPPPrinterInfo(&PrtInfo);
			pFCIPPConnectionObject->CloseIPPConnection();
		}

		if (!m_bDeviceInstallableOptionsInitialized)
			m_bDeviceInstallableOptionsInitialized = true;

		if (bInitialInstallableOptions)
			m_CurrLocalDeviceInstallableOptionsMap = *pDeviceInstallableOptionsMap;

		delete pFCIPPConnectionObject;
	}
	else
	{
		uiError = IPPLIB_CONNECT_FAILED;
		CLogUtils::LOG_UTILS_EX(eERROR, "CFCIPPCommands::GetDeviceUnfilteredJobList: Device %s, IPP Connection failure.", GetDeviceID().c_str());
	}

	LeaveCriticalSection(&m_csDeviceInstallableOptions);

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Compare device status changes. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CFCIPPCommandsBase::CompareDeviceStatusChanges()
{
	bool bStatusCallbackRequired = false;
	bool bCopyStatusRequired = false;
	string strStatusMsg;
	int iStatusCount = m_CurrLocalDeviceStatus.GetStatusStringCount();
	int iDisplayCount = m_CurrLocalDeviceStatus.GetDisplayStringCount();

	EnterCriticalSection(&m_csDeviceProtocol);

	if (m_pPrevLocalDeviceStatus == NULL)
		m_pPrevLocalDeviceStatus = new CDeviceStatus;

	if (m_pPrevLocalDeviceStatus)
	{
		if (m_CurrLocalDeviceStatus.GetDeviceStatus() != m_pPrevLocalDeviceStatus->GetDeviceStatus())
		{
			bStatusCallbackRequired = true;
		}

		if (m_CurrLocalDeviceStatus.GetCoverOpen() != m_pPrevLocalDeviceStatus->GetCoverOpen())
		{
			bStatusCallbackRequired = true;
			if (m_CurrLocalDeviceStatus.GetCoverOpen())
				m_CurrLocalDeviceStatus.AddStatusString(IDS_SNMP_DOOR_OPEN);
			else
				m_CurrLocalDeviceStatus.AddStatusString(IDS_SNMP_DOOR_CLOSED);
		}
		if (m_CurrLocalDeviceStatus.GetAdhesiveOut() != m_pPrevLocalDeviceStatus->GetAdhesiveOut())
		{
			bStatusCallbackRequired = true;
			if (m_CurrLocalDeviceStatus.GetAdhesiveOut())
				m_CurrLocalDeviceStatus.AddStatusString("Adhesive Out");
			else
				m_CurrLocalDeviceStatus.AddStatusString("Adhesive Out Cleared");
		}
		if (m_CurrLocalDeviceStatus.GetJam() != m_pPrevLocalDeviceStatus->GetJam())
		{
			bStatusCallbackRequired = true;
			if (m_CurrLocalDeviceStatus.GetJam())
				m_CurrLocalDeviceStatus.AddStatusString(IDS_SNMP_JAMMED);
			else
				m_CurrLocalDeviceStatus.AddStatusString("Jam Cleared");
		}
		if (m_CurrLocalDeviceStatus.GetMarkerOut() != m_pPrevLocalDeviceStatus->GetMarkerOut())
		{
			bStatusCallbackRequired = true;
			if (m_CurrLocalDeviceStatus.GetMarkerOut())
				m_CurrLocalDeviceStatus.AddStatusString(IDS_SNMP_MARKER_TONER_EMPTY);
			else
				m_CurrLocalDeviceStatus.AddStatusString(IDS_SNMP_MARKER_TONER_EMPTY " Cleared");
		}
		if (m_CurrLocalDeviceStatus.GetMarkerLow() != m_pPrevLocalDeviceStatus->GetMarkerLow())
		{
			bStatusCallbackRequired = true;
			if (m_CurrLocalDeviceStatus.GetMarkerLow())
				m_CurrLocalDeviceStatus.AddStatusString(IDS_SNMP_MARKER_TONER_ALMOST_EMPTY);
			else
				m_CurrLocalDeviceStatus.AddStatusString(IDS_SNMP_MARKER_TONER_ALMOST_EMPTY " Cleared");
		}
		if (m_CurrLocalDeviceStatus.GetPowerOff() != m_pPrevLocalDeviceStatus->GetPowerOff())
		{
			bStatusCallbackRequired = true;
			if (m_CurrLocalDeviceStatus.GetPowerOff())
				m_CurrLocalDeviceStatus.AddStatusString(IDS_SNMP_POWERED_DOWN);
			else
				m_CurrLocalDeviceStatus.AddStatusString(IDS_SNMP_POWERED_UP);
		}
		if (m_CurrLocalDeviceStatus.GetPunchFull() != m_pPrevLocalDeviceStatus->GetPunchFull())
		{
			bStatusCallbackRequired = true;
			if (m_CurrLocalDeviceStatus.GetPunchFull())
				m_CurrLocalDeviceStatus.AddStatusString("Punch Waste Full");
			else
				m_CurrLocalDeviceStatus.AddStatusString("Punch Waste Full Cleared");
		}
		if (m_CurrLocalDeviceStatus.GetRingMaterialOut() != m_pPrevLocalDeviceStatus->GetRingMaterialOut())
		{
			bStatusCallbackRequired = true;
			if (m_CurrLocalDeviceStatus.GetRingMaterialOut())
				m_CurrLocalDeviceStatus.AddStatusString("Ring Material Out");
			else
				m_CurrLocalDeviceStatus.AddStatusString("Ring Material Out Cleared");
		}
		if (m_CurrLocalDeviceStatus.GetRingPunchFull() != m_pPrevLocalDeviceStatus->GetRingPunchFull())
		{
			bStatusCallbackRequired = true;
			if (m_CurrLocalDeviceStatus.GetRingPunchFull())
				m_CurrLocalDeviceStatus.AddStatusString("Ring Punch Waste Full");
			else
				m_CurrLocalDeviceStatus.AddStatusString("Ring Punch Waste Full Cleared");
		}
		if (m_CurrLocalDeviceStatus.GetTrimWasteFull() != m_pPrevLocalDeviceStatus->GetTrimWasteFull())
		{
			bStatusCallbackRequired = true;
			if (m_CurrLocalDeviceStatus.GetTrimWasteFull())
				m_CurrLocalDeviceStatus.AddStatusString("Trimmer Waste Full");
			else
				m_CurrLocalDeviceStatus.AddStatusString("Trimmer Waste Full Cleared");
		}
		if (m_CurrLocalDeviceStatus.GetStaplesOut() != m_pPrevLocalDeviceStatus->GetStaplesOut())
		{
			bStatusCallbackRequired = true;
			if (m_CurrLocalDeviceStatus.GetStaplesOut())
				m_CurrLocalDeviceStatus.AddStatusString("Staples Out");
			else
				m_CurrLocalDeviceStatus.AddStatusString("Staples Out Cleared");
		}
		if (m_CurrLocalDeviceStatus.GetGeneralStatus() != m_pPrevLocalDeviceStatus->GetGeneralStatus())
		{
			bStatusCallbackRequired = true;
			UINT uiGeneralStatus = m_CurrLocalDeviceStatus.GetGeneralStatus();
			if (uiGeneralStatus == EM_ERROR)
				m_CurrLocalDeviceStatus.AddStatusString("Engine in Error State");
			else if (uiGeneralStatus == EM_WARNING)
				m_CurrLocalDeviceStatus.AddStatusString("Engine in Warning State");

			if (m_CurrLocalDeviceStatus.GetSleep())
				m_CurrLocalDeviceStatus.AddStatusString("Engine Sleep");
			if (m_CurrLocalDeviceStatus.GetPrinting())
				m_CurrLocalDeviceStatus.AddStatusString("Engine Printing");
			if (m_CurrLocalDeviceStatus.GetPaused())
				m_CurrLocalDeviceStatus.AddStatusString("Engine Paused");
			if (m_CurrLocalDeviceStatus.GetWarming())
				m_CurrLocalDeviceStatus.AddStatusString("Engine Warming");
		}

		if ((iDisplayCount != m_CurrLocalDeviceStatus.GetDisplayStringCount()) ||
			(iStatusCount != m_CurrLocalDeviceStatus.GetStatusStringCount()))
		{
			bStatusCallbackRequired = true;
		}

		if (bStatusCallbackRequired)
			DeviceProtocolDeviceStatusCallback(&m_CurrLocalDeviceStatus, false);

		m_pPrevLocalDeviceStatus->Copy(&m_CurrLocalDeviceStatus);
	}

	LeaveCriticalSection(&m_csDeviceProtocol);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Compare device job list changes. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CFCIPPCommandsBase::CompareDeviceJobListChanges()
{
	CDevicePrintJob* pCurrDevicePrintJob = NULL;
	CDevicePrintJob* pPrevDevicePrintJob = NULL;
	CDevicePrintJob* pCurrReferenceDevicePrintJob = NULL;
	CDevicePrintJob* pPrevReferenceDevicePrintJob = NULL;
	map<int, CDevicePrintJob*> PossibleBadJobListMap;
	map<int, CDevicePrintJob*>::iterator PossibleBadJobListMapIter;
	bool bCopyJobListRequired = false;
	bool bFound = false;
	map<string, string>::iterator iter;
	string strEventType;
	string strLogMsg;
	int iLowestJLPQMID = 0;
	int iLowestJLJobID = 0;
	int iInterrupts = 0;
	
	EnterCriticalSection(&m_csDeviceJobList);

	if (m_pPrevLocalDeviceJobList)
	{
		int iCurrJLPQMID = 0;
		int iCurrJLJobID = 0;

		for (int i=0; i<(int)m_CurrLocalDeviceJobList.size(); i++)
		{
			pCurrDevicePrintJob = m_CurrLocalDeviceJobList.at(i);
			iCurrJLPQMID = atoi(pCurrDevicePrintJob->m_strJLPQMID.c_str());
			iCurrJLJobID = atoi(pCurrDevicePrintJob->m_strJLJobID.c_str());

			if (iCurrJLPQMID > 0)
			{
				if (iLowestJLPQMID > 0)
				{
					if (iCurrJLPQMID < iLowestJLPQMID)
						iLowestJLPQMID = iCurrJLPQMID;
				}
				else
					iLowestJLPQMID = iCurrJLPQMID;
			}

			if (iCurrJLJobID > 0)
			{
				if (iLowestJLJobID > 0)
				{
					if (iCurrJLJobID < iLowestJLJobID)
						iLowestJLJobID = iCurrJLJobID;
				}
				else
					iLowestJLJobID = iCurrJLJobID;
			}

			strEventType.erase();
			strLogMsg.erase();
			bFound = false;

			for (int j=0; j<(int)m_pPrevLocalDeviceJobList->size(); j++)
			{
				pPrevDevicePrintJob = m_pPrevLocalDeviceJobList->at(j);

				if (pPrevDevicePrintJob->m_strJLJobID == pCurrDevicePrintJob->m_strJLJobID)
				{
					bFound = true;

					switch(pPrevDevicePrintJob->m_iJobStatusMode)
					{
						case JOBLIST_STATUS_MODE_SPOOLING:
							if (!m_bDeviceJobListSupportsStatusRipping)
								pCurrDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_RIPPING;
							break;
						case JOBLIST_STATUS_MODE_RIPPING:
							if (!m_bDeviceJobListSupportsStatusWaiting)
								pCurrDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_WAITING_TO_PRINT;
							break;
						case JOBLIST_STATUS_MODE_INTERRUPTED:
							pPrevDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_SUSPENDED;
							GetJobStatusStringFromJobStatusMode(pPrevDevicePrintJob->m_iJobStatusMode, pPrevDevicePrintJob->m_strJobStatus);
							break;
						//case JOBLIST_STATUS_MODE_WAITING_TO_PRINT:
						//	pCurrDevicePrintJob->m_iJobStatusMode = pPrevDevicePrintJob->m_iJobStatusMode;
						//	break;
						default:
							break;
					}

					GetJobStatusStringFromJobStatusMode(pCurrDevicePrintJob->m_iJobStatusMode, pCurrDevicePrintJob->m_strJobStatus);

					if ((pPrevDevicePrintJob->m_iJobStatusMode != pCurrDevicePrintJob->m_iJobStatusMode) ||
						(pPrevDevicePrintJob->m_uiTotalPagesPrinted != pCurrDevicePrintJob->m_uiTotalPagesPrinted) ||
//						(pPrevDevicePrintJob->m_iPercentageComplete != pCurrDevicePrintJob->m_iPercentageComplete) ||
						(pPrevDevicePrintJob->m_iCopies != pCurrDevicePrintJob->m_iCopies) ||
						(pPrevDevicePrintJob->m_strJobName != pCurrDevicePrintJob->m_strJobName))
					{
						pCurrDevicePrintJob->m_iEventType = HARMONY_JOBEVENTTYPE_CHANGED;
						strEventType = "IPP_JOBEVENTTYPE_CHANGED";

						if (pPrevDevicePrintJob->m_uiTotalPagesPrinted != pCurrDevicePrintJob->m_uiTotalPagesPrinted)
						{
//							pCurrDevicePrintJob->m_iEventType = HARMONY_JOBEVENTTYPE_PAGE_PRINTED;
							strEventType = "IPP_JOBEVENTTYPE_PAGE_PRINTED";
						}

						if ((pCurrDevicePrintJob->m_iPercentageComplete == 0) && (pCurrDevicePrintJob->m_uiTotalPagesPrinted > 0) && (pCurrDevicePrintJob->m_uiTotalPagesExpected > 0))
							pCurrDevicePrintJob->m_iPercentageComplete = ((pCurrDevicePrintJob->m_uiTotalPagesPrinted*100)/pCurrDevicePrintJob->m_uiTotalPagesExpected);

						strLogMsg = FormatString("CFCIPPCommandsBase::CompareDeviceJobListChanges: Device %s, received IPP EventType = %s, JobName = %s, Job Status %d: %s", 
							GetDeviceID().c_str(), strEventType.c_str(), pCurrDevicePrintJob->m_strJobName.c_str(), pCurrDevicePrintJob->m_iJobStatusMode, pCurrDevicePrintJob->m_strJobStatus.c_str());
						CLogUtils::LOG_UTILS_DEBUG(strLogMsg);

						bool bStatusIsCompletedJob = false;
						if ((pCurrDevicePrintJob->m_iJobStatusMode == JOBLIST_STATUS_MODE_DONE_PRINTING) ||
							(pCurrDevicePrintJob->m_iJobStatusMode == JOBLIST_STATUS_MODE_CANCELLED) ||
							(pCurrDevicePrintJob->m_iJobStatusMode == JOBLIST_STATUS_MODE_ABORTED))
						{
							bStatusIsCompletedJob = true;
						}

						if (!m_bDeviceJobListSupportsStatusPrintDone)
						{
							DeviceProtocolJobStatusCallback(pCurrDevicePrintJob, false);

							if (bStatusIsCompletedJob)
							{
								strLogMsg = FormatString("CFCIPPCommandsBase::CompareDeviceJobListChanges: Device is set to not support status done. Device %s, received IPP Job Status %d: %s", 
									GetDeviceID().c_str(), pCurrDevicePrintJob->m_iJobStatusMode, pCurrDevicePrintJob->m_strJobStatus.c_str());
								CLogUtils::LOG_UTILS_ERROR(strLogMsg);
							}
						}
						else
							ProcessCancelledAndDonePrintedJobs(pCurrDevicePrintJob);
					}
					else
					{
						// Check for a possible lost OCE job
						if (m_bDeviceJobListRequiresPossibleCorrections)
						{
							pCurrReferenceDevicePrintJob = m_pDevicePrintJobCache->GetDevicePrintJobFromJLJobID(pCurrDevicePrintJob->m_strJLJobID);
							if (pCurrReferenceDevicePrintJob)
							{
								if ((pCurrReferenceDevicePrintJob->m_iCurrJobListStatusMode == JOBLIST_STATUS_MODE_PRINTING) &&
									(pCurrReferenceDevicePrintJob->m_iJobListPollCountSinceLastStatusChanged > 5))
								{
									PossibleBadJobListMap.insert(map<int, CDevicePrintJob*>::value_type(i, pCurrReferenceDevicePrintJob));
								}

								m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(pCurrDevicePrintJob->m_strJLJobID);
								pCurrReferenceDevicePrintJob = NULL;
							}
						}
					}

					delete pPrevDevicePrintJob;
					m_pPrevLocalDeviceJobList->erase(m_pPrevLocalDeviceJobList->begin()+j);
					--j;
					bCopyJobListRequired = true;
					break;
				}
			}

			if (!bFound)
			{
				//new job
				strEventType = "IPP_JOBEVENTTYPE_NEW_JOB";
				pCurrDevicePrintJob->m_iEventType = HARMONY_JOBEVENTTYPE_NEW_JOB;

				strLogMsg = FormatString("CFCIPPCommandsBase::CompareDeviceJobListChanges: Device %s, received IPP EventType = %s, JobName = %s, Job Status %d: %s", 
					GetDeviceID().c_str(), strEventType.c_str(), pCurrDevicePrintJob->m_strJobName.c_str(), pCurrDevicePrintJob->m_iJobStatusMode, pCurrDevicePrintJob->m_strJobStatus.c_str());
				CLogUtils::LOG_UTILS_DEBUG(strLogMsg);

				DeviceProtocolJobStatusCallback(pCurrDevicePrintJob, false);
				bCopyJobListRequired = true;
			}
		}

		bool bDelayPrevLocalDeviceJobListProcess = DelayPrevLocalDeviceJobListProcess();
		int iCurrLocalDeviceJobListInsertIndex = 0;

		// check to see if the current job list has a printed job
		if (!bDelayPrevLocalDeviceJobListProcess && m_bDeviceJobListRequiresPossibleCorrections)
		{
			int iCurrJobListIndex = 0;
			for (PossibleBadJobListMapIter=PossibleBadJobListMap.begin(); PossibleBadJobListMapIter!=PossibleBadJobListMap.end(); PossibleBadJobListMapIter++)
			{
				bFound = false;
				iCurrJobListIndex = PossibleBadJobListMapIter->first;
				pCurrReferenceDevicePrintJob = PossibleBadJobListMapIter->second;
				pCurrDevicePrintJob = m_CurrLocalDeviceJobList.at(iCurrJobListIndex);

				if (pCurrReferenceDevicePrintJob->m_strJLJobID == pCurrDevicePrintJob->m_strJLJobID)
				{
					for (int j=0; j<(int)m_pPrevLocalDeviceJobList->size(); j++)
					{
						pPrevDevicePrintJob = m_pPrevLocalDeviceJobList->at(j);

						if (pPrevDevicePrintJob->m_iJobStatusMode == JOBLIST_STATUS_MODE_PRINTING)
						{
							// Get the current state from the printer and if it was CANCELLED then we
							//  want to skip removing jobs from the IPP Job List
							CFCIPPJobObject FCIPPJobObject(this, m_pFCIPPDeviceMonitorConnectionObject, pPrevDevicePrintJob);
							FCIPPJobObject.jobID = atoi(pPrevDevicePrintJob->m_strJLPQMID.c_str());
							IPPLIB_RESULT uiIPPError = m_pFCIPPDeviceMonitorConnectionObject->GetJobProgress(&FCIPPJobObject, pPrevDevicePrintJob, true);
							if (pPrevDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_CANCELLED)
							{
								pPrevReferenceDevicePrintJob = m_pDevicePrintJobCache->GetDevicePrintJobFromJLJobID(pPrevDevicePrintJob->m_strJLJobID);
								if (pPrevReferenceDevicePrintJob)
								{
									if (pPrevReferenceDevicePrintJob->m_iJobListPollCountSinceLastStatusChanged <
										pCurrReferenceDevicePrintJob->m_iJobListPollCountSinceLastStatusChanged)
									{
										bFound = true;
										pCurrReferenceDevicePrintJob->m_bRemoveJobFromJobList = true;
										strLogMsg = FormatString("CFCIPPCommandsBase::CompareDeviceJobListChanges: Device %s, believe job is no longer processing so Job is being removed from the IPP job list, JobName = %s, Job Status %d: %s", 
											GetDeviceID().c_str(), pCurrReferenceDevicePrintJob->m_strJobName.c_str(), pCurrReferenceDevicePrintJob->m_iJobStatusMode, pCurrReferenceDevicePrintJob->m_strJobStatus.c_str());
										CLogUtils::LOG_UTILS_DEBUG(strLogMsg);
									}

									m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(pPrevDevicePrintJob->m_strJLJobID);
									pPrevReferenceDevicePrintJob = NULL;
								}
							}
							// The GetJobProgress call above changes m_iJobStatusMode to CANCELLED or DONE_PRINTING but for
							//  correct downstream processing it needs to be set back to PRINTING
							pPrevDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_PRINTING;
						}

						if (bFound)
							break;
					}
				}
				else
				{
					strLogMsg = FormatString("CFCIPPCommandsBase::CompareDeviceJobListChanges: Device %s, Failed to find job in current job list, JobName = %s, Job Status %d: %s", 
							GetDeviceID().c_str(), pCurrReferenceDevicePrintJob->m_strJobName.c_str(), pCurrReferenceDevicePrintJob->m_iJobStatusMode, pCurrReferenceDevicePrintJob->m_strJobStatus.c_str());
					CLogUtils::LOG_UTILS_ERROR(strLogMsg);
				}
			}
		}

		AddErrorJobsNotVerifiedOnDevice(m_pPrevLocalDeviceJobList);

		for (int i=0; i<(int)m_pPrevLocalDeviceJobList->size(); i++)
		{
			if ((int)m_CurrLocalDeviceJobList.size() == 0)
				++iInterrupts;

			pPrevDevicePrintJob = m_pPrevLocalDeviceJobList->at(i);
			bool bDeleteJob = false;

			CDevicePrintJob* pReferenceDevicePrintJob = m_pDevicePrintJobCache->GetDevicePrintJobFromJLJobID(pPrevDevicePrintJob->m_strJLJobID);
			if (pReferenceDevicePrintJob)
			{
				int iReferenceJLPQMID = atoi(pReferenceDevicePrintJob->m_strJLPQMID.c_str());
				int iReferenceJLJobID = atoi(pReferenceDevicePrintJob->m_strJLJobID.c_str());

				if (bDelayPrevLocalDeviceJobListProcess)
				{
					m_CurrLocalDeviceJobList.insert(m_CurrLocalDeviceJobList.begin()+iCurrLocalDeviceJobListInsertIndex, pPrevDevicePrintJob);
					++iCurrLocalDeviceJobListInsertIndex;
				}
				else
				{
					pPrevDevicePrintJob->m_iEventType = HARMONY_JOBEVENTTYPE_CHANGED;
					strEventType = "IPP_JOBEVENTTYPE_CHANGED";

					if ((pPrevDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_DONE_PRINTING) &&
						(pPrevDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_CANCELLED) &&
						(pPrevDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_ERRORED) &&
						(pPrevDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_ABORTED))
					{
						bool bDelayStatus = false;

						if (!m_bDeviceSupportsStatusAfterRemovedFromJobList &&
							pPrevDevicePrintJob->m_strTimeStampPrinting.empty() &&
							(((iLowestJLPQMID != 0) && (iReferenceJLPQMID > iLowestJLPQMID)) ||
							 ((iReferenceJLPQMID == 0) && (iLowestJLJobID != 0) && (iReferenceJLJobID > iLowestJLJobID))))
						{
							bDelayStatus = true;
							pPrevDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_CANCELLED;
							if (!pReferenceDevicePrintJob->m_bJobCancelledByFieryCentral)
								pReferenceDevicePrintJob->m_bJobCancelledOnDevice = true;
						}
						else if (pReferenceDevicePrintJob->m_bJobCancelledByFieryCentral)
						{
							bDelayStatus = true;
							pPrevDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_CANCELLED;
						}
						else
						{
							switch(pPrevDevicePrintJob->m_iJobStatusMode)
							{
								case JOBLIST_STATUS_MODE_SPOOLING:
									bDelayStatus = true;
									pPrevDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_RIPPING;
									break;
								case JOBLIST_STATUS_MODE_RIPPING:
								case JOBLIST_STATUS_MODE_SUSPENDED:
								case JOBLIST_STATUS_MODE_WAITING_TO_PRINT:
									bDelayStatus = true;
									pPrevDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_PRINTING;
									break;
								case JOBLIST_STATUS_MODE_PRINTING:
								default:
									if (pPrevDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_PRINTING)
									{
										bDelayStatus = true;
										pPrevDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_PRINTING;
									}
									break;
							}
						}

						GetJobStatusStringFromJobStatusMode(pPrevDevicePrintJob->m_iJobStatusMode, pPrevDevicePrintJob->m_strJobStatus);
						if (bDelayStatus)
						{
							strLogMsg = FormatString("CFCIPPCommandsBase::CompareDeviceJobListChanges: Device %s, received IPP EventType = %s, JobName = %s, Job Status %d: %s", 
								GetDeviceID().c_str(), strEventType.c_str(), pPrevDevicePrintJob->m_strJobName.c_str(), pPrevDevicePrintJob->m_iJobStatusMode, pPrevDevicePrintJob->m_strJobStatus.c_str());
							CLogUtils::LOG_UTILS_DEBUG(strLogMsg);

							pReferenceDevicePrintJob->m_iJobStatusMode = pPrevDevicePrintJob->m_iJobStatusMode;

							if ((pPrevDevicePrintJob->m_iJobStatusMode == JOBLIST_STATUS_MODE_CANCELLED) ||
								(pPrevDevicePrintJob->m_iJobStatusMode == JOBLIST_STATUS_MODE_DONE_PRINTING))
							{
								if (pPrevDevicePrintJob->m_bJobVerifiedOnDevice && m_bDeviceSupportsStatusAfterRemovedFromJobList && !pReferenceDevicePrintJob->m_bRemoveJobFromJobList)
								{
									CFCIPPJobObject FCIPPJobObject(this, m_pFCIPPDeviceMonitorConnectionObject, pPrevDevicePrintJob);
									FCIPPJobObject.jobID = iReferenceJLPQMID;
									IPPLIB_RESULT uiIPPError = m_pFCIPPDeviceMonitorConnectionObject->GetJobProgress(&FCIPPJobObject, pPrevDevicePrintJob, true);
								}
							}

							GetJobStatusStringFromJobStatusMode(pReferenceDevicePrintJob->m_iJobStatusMode, pReferenceDevicePrintJob->m_strJobStatus);
							DeviceProtocolJobStatusCallback(pPrevDevicePrintJob, false);

							m_CurrLocalDeviceJobList.insert(m_CurrLocalDeviceJobList.begin()+iCurrLocalDeviceJobListInsertIndex, pPrevDevicePrintJob);
							++iCurrLocalDeviceJobListInsertIndex;
						}
						else
						{
							pPrevDevicePrintJob->m_strTimeStampPrinting.erase();

							if (pPrevDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_CANCELLED)
							{
								// check to see if job was cancelled by us.
								if (pReferenceDevicePrintJob->m_bJobCancelledByFieryCentral)
								{
									pPrevDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_CANCELLED;
									GetJobStatusStringFromJobStatusMode(pPrevDevicePrintJob->m_iJobStatusMode, pPrevDevicePrintJob->m_strJobStatus);
									if (pPrevDevicePrintJob->m_strTimeStampCanceled.empty())
										pPrevDevicePrintJob->SetCurrentTimeStamp(JOBLIST_STATUS_MODE_CANCELLED);
								}
							}

							if (!m_bDeviceJobListSupportsStatusPrintDone)
							{
								if (pPrevDevicePrintJob->m_bJobVerifiedOnDevice && m_bDeviceSupportsStatusAfterRemovedFromJobList && !pReferenceDevicePrintJob->m_bRemoveJobFromJobList)
								{
									CFCIPPJobObject FCIPPJobObject(this, m_pFCIPPDeviceMonitorConnectionObject, pPrevDevicePrintJob);
									FCIPPJobObject.jobID = iReferenceJLPQMID;
									IPPLIB_RESULT uiIPPError = m_pFCIPPDeviceMonitorConnectionObject->GetJobProgress(&FCIPPJobObject, pPrevDevicePrintJob, true);
								}

								if (pPrevDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_CANCELLED)
								{
									// Assume that it is done printing
									pPrevDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_DONE_PRINTING;
									pPrevDevicePrintJob->m_iPercentageComplete = 100;
									pPrevDevicePrintJob->SetCurrentTimeStamp(JOBLIST_STATUS_MODE_DONE_PRINTING);

									GetJobStatusStringFromJobStatusMode(pPrevDevicePrintJob->m_iJobStatusMode, pPrevDevicePrintJob->m_strJobStatus);
								}
								else
								{
									pPrevDevicePrintJob->SetCurrentTimeStamp(JOBLIST_STATUS_MODE_CANCELLED);
									if (!pReferenceDevicePrintJob->m_bJobCancelledByFieryCentral)
										pReferenceDevicePrintJob->m_bJobCancelledOnDevice = true;
								}

								strLogMsg = FormatString("CFCIPPCommandsBase::CompareDeviceJobListChanges: Device %s, received IPP EventType = %s, JobName = %s, Job Status %d: %s", 
									GetDeviceID().c_str(), strEventType.c_str(), pPrevDevicePrintJob->m_strJobName.c_str(), pPrevDevicePrintJob->m_iJobStatusMode, pPrevDevicePrintJob->m_strJobStatus.c_str());
								CLogUtils::LOG_UTILS_DEBUG(strLogMsg);

								pReferenceDevicePrintJob->m_iJobStatusMode = pPrevDevicePrintJob->m_iJobStatusMode;
								GetJobStatusStringFromJobStatusMode(pReferenceDevicePrintJob->m_iJobStatusMode, pReferenceDevicePrintJob->m_strJobStatus);
								DeviceProtocolJobStatusCallback(pPrevDevicePrintJob, false);

								if (pReferenceDevicePrintJob->m_bJobRequiresFakeSuspend && (m_iCheckJobProgessPrintingState == CHECK_JOB_PROGESS_AFTER_PRINTING_STATE))
								{
									pReferenceDevicePrintJob->m_bJobRequiresFakeSuspend = false;
									DecrementFakeJobsSuspendedOnDevice();
								}

								m_CurrLocalDeviceJobList.insert(m_CurrLocalDeviceJobList.begin()+iCurrLocalDeviceJobListInsertIndex, pPrevDevicePrintJob);
								++iCurrLocalDeviceJobListInsertIndex;
							}
							else
								bDeleteJob = true;
						}
					}
					else if(pPrevDevicePrintJob->m_iJobStatusMode == JOBLIST_STATUS_MODE_ERRORED)
					{
						ProcessJobsFailedSendingToDevice(pPrevDevicePrintJob);
						DeviceProtocolJobStatusCallback(pPrevDevicePrintJob, false);
					}
					else
						bDeleteJob = true;

					if (bDeleteJob)
					{
						pPrevDevicePrintJob->m_iEventType = HARMONY_JOBEVENTTYPE_DELETED;
						pPrevDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_DELETED;

						strEventType = "IPP_JOBEVENTTYPE_DELETED";
						GetJobStatusStringFromJobStatusMode(pPrevDevicePrintJob->m_iJobStatusMode, pPrevDevicePrintJob->m_strJobStatus);
						strLogMsg = FormatString("CFCIPPCommandsBase::CompareDeviceJobListChanges: Device %s, received IPP EventType = %s, JobName = %s, Job Status %d: %s", 
							GetDeviceID().c_str(), strEventType.c_str(), pPrevDevicePrintJob->m_strJobName.c_str(), pPrevDevicePrintJob->m_iJobStatusMode, pPrevDevicePrintJob->m_strJobStatus.c_str());
						CLogUtils::LOG_UTILS_DEBUG(strLogMsg);

						if (pReferenceDevicePrintJob->m_bJobRequiresFakeSuspend && (m_iCheckJobProgessPrintingState == CHECK_JOB_PROGESS_AFTER_PRINTING_STATE))
						{
							pReferenceDevicePrintJob->m_bJobRequiresFakeSuspend = false;
							DecrementFakeJobsSuspendedOnDevice();
						}

						pReferenceDevicePrintJob->m_iJobStatusMode = pPrevDevicePrintJob->m_iJobStatusMode;
						GetJobStatusStringFromJobStatusMode(pReferenceDevicePrintJob->m_iJobStatusMode, pReferenceDevicePrintJob->m_strJobStatus);
						m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(pPrevDevicePrintJob->m_strJLJobID);
						pReferenceDevicePrintJob = NULL;

						DeviceProtocolJobStatusCallback(pPrevDevicePrintJob, false);

						m_pDevicePrintJobCache->RemoveDevicePrintJobFromJLJobID(pPrevDevicePrintJob->m_strJLJobID);
						delete pPrevDevicePrintJob;
					}
				}
				
				m_pPrevLocalDeviceJobList->erase(m_pPrevLocalDeviceJobList->begin()+i);
				--i;
				bCopyJobListRequired = true;

				// need to reverify pReferenceDevicePrintJob since it could have been delete
				// if the job was deleted from the device.
				if (pReferenceDevicePrintJob)
				{
					m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(pPrevDevicePrintJob->m_strJLJobID);
					pReferenceDevicePrintJob = NULL;
				}
			}
		}
	}
	else
	{
		m_pPrevLocalDeviceJobList = new CJobList;
		if ((int)m_CurrLocalDeviceJobList.size() > 0)
		{
			CDeviceJobList::CopyJobList(&m_CurrLocalDeviceJobList, m_pPrevLocalDeviceJobList);
		}
	}

	if (bCopyJobListRequired)
	{
		CDeviceJobList::FreeJobList(m_pPrevLocalDeviceJobList);
		CDeviceJobList::CopyJobList(&m_CurrLocalDeviceJobList, m_pPrevLocalDeviceJobList);
	}

	CheckJobListForPossibleJobCancellations(&m_CurrLocalDeviceJobList);

	LeaveCriticalSection(&m_csDeviceJobList);
}

bool CFCIPPCommandsBase::DelayPrevLocalDeviceJobListProcess()
{
	CDevicePrintJob* pPrevDevicePrintJob = NULL;
	bool bDelayPrevLocalDeviceJobListProcess = false;

	// I had a case where the joblist was empty when jobs were suspended
	// this code should keep the data one more cycle just in case it was
	// an error in the joblist from the device.
	if ((int)m_CurrLocalDeviceJobList.size() == 0)
	{
		for (int i=0; i<(int)m_pPrevLocalDeviceJobList->size(); i++)
		{
			pPrevDevicePrintJob = m_pPrevLocalDeviceJobList->at(i);
			if (pPrevDevicePrintJob->m_iJobStatusMode == JOBLIST_STATUS_MODE_SUSPENDED)
			{
				pPrevDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_INTERRUPTED;
				GetJobStatusStringFromJobStatusMode(pPrevDevicePrintJob->m_iJobStatusMode, pPrevDevicePrintJob->m_strJobStatus);
				bDelayPrevLocalDeviceJobListProcess = true;
				break;
			}
		}
	}

	return bDelayPrevLocalDeviceJobListProcess;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets the last device job list identifier. </summary>
///
/// <remarks>	</remarks>
///
/// <returns>	The last device job list identifier. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

int CFCIPPCommandsBase::GetLastDeviceJobListID()
{
	EnterCriticalSection(&m_csLastDeviceJobListID);
	int iLastDeviceJobListID = m_iLastDeviceJobListID;
	LeaveCriticalSection(&m_csLastDeviceJobListID);
	return iLastDeviceJobListID;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets the next last device job list identifier. </summary>
///
/// <remarks>	 </remarks>
///
/// <returns>	The next last device job list identifier. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

int CFCIPPCommandsBase::GetNextLastDeviceJobListID()
{
	EnterCriticalSection(&m_csLastDeviceJobListID);
	int iLastDeviceJobListID = ++m_iLastDeviceJobListID;
	LeaveCriticalSection(&m_csLastDeviceJobListID);
	return iLastDeviceJobListID;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sets last device job list identifier. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="iLastDeviceJobListID">	Identifier for the last device job list. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CFCIPPCommandsBase::SetLastDeviceJobListID(int iLastDeviceJobListID)
{
	EnterCriticalSection(&m_csLastDeviceJobListID);
	m_iLastDeviceJobListID = iLastDeviceJobListID;
	LeaveCriticalSection(&m_csLastDeviceJobListID);
}

UINT CFCIPPCommandsBase::CheckJobListForPossibleJobCancellations(CJobList* pCurrLocalDeviceJobList)
{
	UINT uiError = NO_ERROR;
	CDevicePrintJob* pDevicePrintJob = NULL;
	CDevicePrintJob* pReferenceDevicePrintJob = NULL;
	CDevicePrintJobArray CancelPrintJobArray;

	for (int i=0; i<(int)pCurrLocalDeviceJobList->size(); i++)
	{
		pDevicePrintJob = pCurrLocalDeviceJobList->at(i);
		if (pDevicePrintJob)
		{
			pReferenceDevicePrintJob = m_pDevicePrintJobCache->GetDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
			if (pReferenceDevicePrintJob)
			{
				// Check for jobs we cannot or should not cancel
				if ((pReferenceDevicePrintJob->m_bJobCancelledOnDevice || pReferenceDevicePrintJob->m_bJobCancelledByFieryCentral) &&
					!pReferenceDevicePrintJob->m_bRemoveCancelledJobFromJobList &&
					(pReferenceDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_DONE_PRINTING) &&
					(pReferenceDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_CANCELLED) &&
					(pReferenceDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_ABORTED) &&
					(pReferenceDevicePrintJob->m_iJobStatusMode != JOBLIST_STATUS_MODE_DELETED))
				{
					if (pReferenceDevicePrintJob->m_bJobContainsProjectedJobID || (pReferenceDevicePrintJob->m_iJobCancelledByFieryCentralCount >= JOB_CANCEL_RETRY_LIMIT))
					{
						if (pReferenceDevicePrintJob->m_pSubJob)
						{
							CJob* pJob = pReferenceDevicePrintJob->m_pSubJob->GetParentJob();

							if (pJob)
								pJob->SetCancelStatus(CANCEL_JOB_FAILED);
						}

						// Setting this flag will trigger the removal of the job from the next job list from the printer
						//  which results in a status callback that results in the "CANCEL_JOB_FAILED" error set above.
						pReferenceDevicePrintJob->m_bRemoveCancelledJobFromJobList = true;
						CLogUtils::LOG_UTILS_EX(eERROR, "CheckJobListForPossibleJobCancellations: Device %s, Failed cancelling Job \"%s\", JLJobID %s, JLPQMID %s Three times Dropping with Error", 
							GetDeviceID().c_str(), pReferenceDevicePrintJob->m_strJobName.c_str(), pReferenceDevicePrintJob->m_strJLJobID.c_str(), pReferenceDevicePrintJob->m_strJLPQMID.c_str());
					}
					else
					{
						if (pReferenceDevicePrintJob->m_iJobCancelledByFieryCentralCount == 1)
						{
							// Skipping the cancel the first cycle after the inital cancel request
							// We have observed a quick second cancel to cause the printer to get
							//  into a non-responsive state for up to 5 minutes
							pReferenceDevicePrintJob->m_iJobCancelledByFieryCentralCount++;
						}
						else
						{
							// Add to the list of jobs to retry the cancel 
							CancelPrintJobArray.push_back(pReferenceDevicePrintJob);
						}
					}
				}

				m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
				pReferenceDevicePrintJob = NULL;
			}
		}
	}

	if ((int)CancelPrintJobArray.size() > 0)
	{
		CFCIPPConnectionObject* pFCIPPConnectionObject = GetIPPConnectionObject();

		if (pFCIPPConnectionObject)
		{
			uiError = pFCIPPConnectionObject->OpenIPPConnection();
			if (IPPLIB_SUCCESS == uiError)
			{
				for (int i=(int)CancelPrintJobArray.size()-1; i>=0; i--)
				{
					pDevicePrintJob = CancelPrintJobArray.at(i);
					++pDevicePrintJob->m_iJobCancelledByFieryCentralCount;

					uiError = pFCIPPConnectionObject->CancelIPPJob(pDevicePrintJob);

					if (IPPLIB_SUCCESS != uiError)
					{
						// Still need to handle this case - Don - I think this is now handled by checking the retry count above
						CLogUtils::LOG_UTILS_EX(eERROR, "CheckJobListForPossibleJobCancellations:: Device %s, Failed cancelling Job \"%s\", JLJobID %s, JLPQMID %s", 
							GetDeviceID().c_str(), pDevicePrintJob->m_strJobName.c_str(), pDevicePrintJob->m_strJLJobID.c_str(), pDevicePrintJob->m_strJLPQMID.c_str());
					}
				}

				pFCIPPConnectionObject->CloseIPPConnection();
			}

			delete pFCIPPConnectionObject;
		}
		else
		{
			uiError = IPPLIB_CONNECT_FAILED;
			CLogUtils::LOG_UTILS_EX(eERROR, "CFCIPPCommands::CancelJobForReason: Device %s, IPP Connection failure.", GetDeviceID().c_str());
		}
	}

	return uiError;
}

UINT CFCIPPCommandsBase::CancelJobListEx(CDevicePrintJobArray* pCancelPrintJobArray)
{
	UINT uiError = NO_ERROR;
	CDevicePrintJob* pDevicePrintJob = NULL;
	bool bCancelMoreThanOneJob = false;

	if (pCancelPrintJobArray == NULL)
		return ERROR_INVALID_DATA;

	if ((int)pCancelPrintJobArray->size() > 1)
		bCancelMoreThanOneJob = true;

	if ((int)pCancelPrintJobArray->size() > 0)
	{
		CFCIPPConnectionObject* pFCIPPConnectionObject = GetIPPConnectionObject();

		if (pFCIPPConnectionObject)
		{
			uiError = pFCIPPConnectionObject->OpenIPPConnection();
			if (IPPLIB_SUCCESS == uiError)
			{
				for (int i=(int)pCancelPrintJobArray->size()-1; i>=0; i--)
				{
					pDevicePrintJob = pCancelPrintJobArray->at(i);
					++pDevicePrintJob->m_iJobCancelledByFieryCentralCount;

					// if we have more than 1 subjob to cancel let's
					// delay to make sure the device has time to clean up 
					// before killing any suspended job. I am trying to stop job
					// from going into the "Press button to continue" job on the
					// engine. We cannot cancel a job if it is in that state (Paused at the engine).
					if (bCancelMoreThanOneJob && (pDevicePrintJob->m_iJobStatusMode == JOBLIST_STATUS_MODE_SUSPENDED))
						Sleep(2000);

					uiError = pFCIPPConnectionObject->CancelIPPJob(pDevicePrintJob);

					if (IPPLIB_SUCCESS != uiError)
					{
						// Still need to handle this case - Don
						CLogUtils::LOG_UTILS_EX(eERROR, "CFCIPPCommands::CancelJobForReason: Device %s, Failed cancelling Job \"%s\", JLJobID %s, JLPQMID %s", 
							GetDeviceID().c_str(), pDevicePrintJob->m_strJobName.c_str(), pDevicePrintJob->m_strJLJobID.c_str(), pDevicePrintJob->m_strJLPQMID.c_str());
					}
				}

				pFCIPPConnectionObject->CloseIPPConnection();
			}

			delete pFCIPPConnectionObject;
		}
		else
		{
			uiError = IPPLIB_CONNECT_FAILED;
			CLogUtils::LOG_UTILS_EX(eERROR, "CFCIPPCommands::CancelJobForReason: Device %s, IPP Connection failure.", GetDeviceID().c_str());
		}

		pCancelPrintJobArray->clear();

		// now lets sleep to allow the device to update it's internal job list
		// before releasing the "CancelJobInProgress".
		Sleep(2000);
	}

	return uiError;
}

void CFCIPPCommandsBase::SetSpecialJobProcessing(bool bRequiresSpecialLargeJobProcessing, bool bRequiresSpecialJobIDProcessing)
{
	if (bRequiresSpecialJobIDProcessing && m_bStopConnectionsForSpecialJobProcessing)
		return;

	EnterCriticalSection(&m_csSpecialJobProcessing);
	CheckIfSpecialJobProcessing();

	// Make sure all jobs sent to the device have actually
	// showed up in the job list
	if (bRequiresSpecialLargeJobProcessing)
		m_pDevicePrintJobCache->VerifyAllJobsWereSentToTheDevice();

	m_bStopConnectionsForSpecialJobProcessing = (bRequiresSpecialLargeJobProcessing || bRequiresSpecialJobIDProcessing) ? true:false;
	SetEvent(m_hSpecialJobProcessingEvent);
	LeaveCriticalSection(&m_csSpecialJobProcessing);
}

void CFCIPPCommandsBase::CheckIfSpecialJobProcessing()
{
	while (m_bStopConnectionsForSpecialJobProcessing && !m_bShuttingdown)
		WaitForSingleObject(m_hSpecialJobProcessingEvent, 2000);
}

void CFCIPPCommandsBase::ResetSpecialJobProcessing()
{
	m_bStopConnectionsForSpecialJobProcessing = false;
	SetEvent(m_hSpecialJobProcessingEvent);
}

void CFCIPPCommandsBase::ProcessCancelledAndDonePrintedJobs(CDevicePrintJob* pDevicePrintJob)
{
	if (m_bDeviceJobListSupportsStatusPrintDone)
	{
		CDevicePrintJob* pReferenceDevicePrintJob = NULL;

		switch(pDevicePrintJob->m_iJobStatusMode)
		{
			case JOBLIST_STATUS_MODE_DONE_PRINTING:
			case JOBLIST_STATUS_MODE_CANCELLED:
			case JOBLIST_STATUS_MODE_ABORTED:
				switch(pDevicePrintJob->m_iJobStatusMode)
				{
					case JOBLIST_STATUS_MODE_DONE_PRINTING:
						pDevicePrintJob->m_iPercentageComplete = 100;
						pDevicePrintJob->SetCurrentTimeStamp(JOBLIST_STATUS_MODE_DONE_PRINTING);
						break;
					case JOBLIST_STATUS_MODE_CANCELLED:
					case JOBLIST_STATUS_MODE_ABORTED:
						if (pDevicePrintJob->m_strTimeStampCanceled.empty())
							pDevicePrintJob->SetCurrentTimeStamp(JOBLIST_STATUS_MODE_CANCELLED);
						break;
				}

				pReferenceDevicePrintJob = m_pDevicePrintJobCache->GetDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
				if (pReferenceDevicePrintJob)
				{
					pReferenceDevicePrintJob->m_iJobStatusMode = pDevicePrintJob->m_iJobStatusMode;
					GetJobStatusStringFromJobStatusMode(pReferenceDevicePrintJob->m_iJobStatusMode, pReferenceDevicePrintJob->m_strJobStatus);
					DeviceProtocolJobStatusCallback(pDevicePrintJob, false);

					if (pReferenceDevicePrintJob->m_bJobRequiresFakeSuspend && (m_iCheckJobProgessPrintingState == CHECK_JOB_PROGESS_AFTER_PRINTING_STATE))
					{
						pReferenceDevicePrintJob->m_bJobRequiresFakeSuspend = false;
						DecrementFakeJobsSuspendedOnDevice();
					}

					m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
					pReferenceDevicePrintJob = NULL;
				}
				break;
			default:
				DeviceProtocolJobStatusCallback(pDevicePrintJob, false);
				break;
		}
	}
}
