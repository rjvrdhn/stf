// CFCIPPCommandsBase.h: interface for the CFCIPPCommandsBase class.
/********************************************************************
*
*  (c) Copyright 2013  
*      Electronics for Imaging, Inc. ("EFI").
*      All Rights Reserved
*
*  EFI products contain certain trade secrets and confidential and
*  proprietary information of EFI.  Use, reproduction, disclosure,
*  distribution by any means are prohibited, except pursuant to
*  a written license from EFI. Modification, translation, reverse
*  engineering, decompiling, disassembling, and creating derivative
*  works based on this software are prohibited, except pursuant to
*  a written license from EFI. Use of copyright notice does not imply
*  publication or disclosure.
*
*  Restricted Rights Legend:
*  Use, duplication, or disclosure by the Government is subject to
*  restrictions as set forth in subparagraph (c)(1)(ii) of The
*  Rights in Technical Data and Computer Software clause in DFARS
*  252.227-7013 or subparagraphs (c)(1) and (2) of the Commercial
*  Computer Software--Restricted Rights at 48 CFR 52.227-19, as
*  applicable.
*
**********************************************************************
*/
#pragma once

#include "FCProtocolBase.h"
#include "FCIPPConnectionObject.h"
#include "FCPaperTypeUtilities.h"

#pragma warning (push)
#pragma warning (disable:4251)

class CFCIPPCommandsBase;
class CJobBase;


class __declspec(dllexport) CFCIPPCommandsBase : public CFCProtocolBase
{
private:
	int		m_iFakeJobsSuspendedOnDevice;

protected:
	CFCIPPConnectionObjectMap	m_FCIPPConnectionObjectMap;
	CFCIPPConnectionObject*		m_pFCIPPDeviceMonitorConnectionObject;
	CMediaUtilities*			m_pMediaTypeUtilities;
	CPaperTypeUtilities*		m_pPaperTypeUtilities;
	CRITICAL_SECTION			m_csIPPRequestID;
	CRITICAL_SECTION			m_csIPPConnection;
	CRITICAL_SECTION			m_csIPPCheckConnections;
	CRITICAL_SECTION			m_csLastDeviceJobListID;
	CRITICAL_SECTION			m_csSpecialJobProcessing;
	HANDLE						m_hIPPJobMappedEvent;
	HANDLE						m_hSpecialJobProcessingEvent;
	
	string	m_strDeviceIPPVersion;
	int		m_iIPPMaxThreads;
	int		m_iIPPMaxThreadsDelay;
	int		m_iIPPPrintThreadDelay;
	int		m_iIPPPrintThreadSubsetDelay;
	int		m_iIPPWaitForJobDelayLimit;
	bool	m_bIPPRecoverFromBadJobID;
	bool	m_bIPPErrorOnJobID0;
	bool	m_bRequiresSpecialLargeJobSupport;
	int		m_iSpecialLargeJobSupportSize;
	int		m_iCheckJobProgessPrintingState;

	int		m_iLastDeviceJobListID;
	int		m_iNumJobsInJobList;
	bool	m_bJobsSuspendedOnDevice;
	bool	m_bStopConnectionsForSpecialJobProcessing;

public:
	CFCIPPCommandsBase(CDevice* pDevice);
	virtual ~CFCIPPCommandsBase();

	bool m_bUseJobNameToGetJobID;

	CMediaUtilities* GetMediaTypeUtilities() { return m_pMediaTypeUtilities; }
	CPaperTypeUtilities* GetPaperTypeUtilities() { return m_pPaperTypeUtilities; }

	string GetDeviceIPPVersion() { return m_strDeviceIPPVersion; }
	int GetCheckJobProgessPrintingState() { return m_iCheckJobProgessPrintingState; }

	int GetLastDeviceJobListID();
	int GetNextLastDeviceJobListID();
	void SetLastDeviceJobListID(int iLastDeviceJobListID);

	void IncrementFakeJobsSuspendedOnDevice();
	void DecrementFakeJobsSuspendedOnDevice();

	bool AreJobsSuspended() { return (m_bJobsSuspendedOnDevice || (m_iFakeJobsSuspendedOnDevice > 0)); }
	void SetJobsSuspended(bool bJobsSuspendedOnDevice) { m_bJobsSuspendedOnDevice = bJobsSuspendedOnDevice; }

	int GetNumJobsInJobList() { return m_iNumJobsInJobList; }
	void SetNumJobsInJobList(int iNumJobsInJobList);

	CRITICAL_SECTION* GetIPPConnectionCritialSection() { return &m_csIPPConnection; }
	void RemoveIPPConnectionID(UINT uiConnectionID);

	HANDLE GetIPPJobMappedEventHandle() { return m_hIPPJobMappedEvent; }
	void SetIPPJobMappedEventHandle() { SetEvent(m_hIPPJobMappedEvent); }

	UINT GetNextIPPRequestID();
	UINT GetNextIPPConnectionID();

	bool DoesDeviceIPPRecoverFromBadJobID() { return m_bIPPRecoverFromBadJobID; }
	bool DoesDeviceRequireSpecialLargeJobSupport() { return m_bRequiresSpecialLargeJobSupport; }

protected:
	void SetSpecialJobProcessing(bool bRequiresSpecialLargeJobProcessing, bool bRequiresSpecialJobIDProcessing);
	void CheckIfSpecialJobProcessing();
	void ResetSpecialJobProcessing();
	void ProcessCancelledAndDonePrintedJobs(CDevicePrintJob* pDevicePrintJob);

	virtual UINT OpenProtocolConnection();
	virtual UINT CloseProtocolConnection();
	virtual UINT InitialDeviceMonitoringServices(){ return NO_ERROR; }
	virtual UINT GetDeviceStatusEx(CDeviceStatus* pDeviceStatus, bool bInitialStatus);
	virtual UINT GetDeviceTrayInfoEx(CDeviceTrayInfo* pDeviceTrayInfo, bool bInitialTrayInfo){ return NO_ERROR; }
	virtual UINT GetDevicePrintCounterInfoEx(CDevicePrintCounterInfo* pDevicePrintCounterInfo, bool bInitialPrintCounterInfo){ return NO_ERROR; }
	virtual UINT GetDeviceJobListEx(CJobList* pJobList, bool bInitialJobList);
	virtual UINT GetNumberOfJobsOnDeviceEx(int& iNumberOfJobsOnDevice);
	virtual UINT AreJobsSuspendedOnDeviceEx(bool& bJobSuspended);
	virtual UINT GetDeviceAccountingLogEx(CDeviceAccountingLog* pDeviceAccountingLog, bool bInitialAccountingLog){ return NO_ERROR; }
	virtual UINT GetDeviceMediaCatalogEx(string* pstrMediaCatalog, bool bInitialMediaCatalog);
	virtual UINT GetDevicePaperCatalogEx(string* pstrPaperCatalog, bool bInitialPaperCatalog){ return NO_ERROR; }
	virtual UINT GetDeviceInstallableOptionsEx(stringMap* pDeviceInstallableOptionsMap, bool bInitialInstallableOptions);

	virtual UINT PrintJob(CSubJob* pSubJob){ return NO_ERROR; }
	virtual UINT SuspendJobList(CJobList* pJobList){ return NO_ERROR; }
	virtual UINT ResumeJobList(CJobList* pJobList){ return NO_ERROR; }
	virtual UINT DeleteJobList(CJobList* pJobList){ return NO_ERROR; }
	virtual UINT CancelJobListEx(CDevicePrintJobArray* pCancelPrintJobArray);
	virtual UINT SetDeviceMediaCatalog(string strMediaCatalog, bool bMergeDeviceCatalogData){ return NO_ERROR; }

	virtual void ShutDownDeviceMonitoringServices() { ShutDownMonitoringServices(); }
	virtual void CompareDeviceStatusChanges();
	virtual void CompareDeviceJobListChanges();
	virtual void CompareDeviceAccountingLogChanges() {;}
	virtual void CompareDeviceMediaCatalogChanges() {;}
	virtual bool _EnableEnginePrintingStatus() { return true; };
	virtual UINT GetDeviceUnfilteredJobList(CJobList* pJobList) = 0;

	UINT CheckJobListForPossibleJobCancellations(CJobList* pCurrLocalDeviceJobList);

	CFCIPPConnectionObject* GetIPPConnectionObject();
	void FreeIPPConnectionObjectMap();
	bool DelayPrevLocalDeviceJobListProcess();
};

#pragma warning (pop)
