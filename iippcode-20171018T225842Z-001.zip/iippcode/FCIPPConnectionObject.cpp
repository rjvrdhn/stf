// FCIPPConnectionObject.cpp: implementation of the CFCIPPConnectionObject class.

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	A macro that defines window 32 lean and mean. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers, Needed with CUPS

#include <windows.h>
#include "http-private.h"   // Cups external library
#include <map>
using namespace std;

#include "DeviceJobList.h"

#include "FCIPPConnectionObject.h"
#include "FCIPPConnectionObjectBaseMisc.h"
#include "FCIPPCommandsBase.h"
#include "FCIPPDefines.h"
#include "http.h"
#include "FCIPPJobObject.h"

/// <summary>	The debug trace level. </summary>
int g_DebugTraceLevel = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Constructor. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPCommandsBase">	[in,out] If non-null, the fcipp commands base. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

CFCIPPConnectionObject::CFCIPPConnectionObject(CFCIPPCommandsBase* pFCIPPCommandsBase) : CFCIPPConnectionObjectBase(pFCIPPCommandsBase)
{
	string strDeviceIPAddress = pFCIPPCommandsBase->GetDeviceIPAddress();
	string strDeviceQueueName = pFCIPPCommandsBase->GetDeviceQueueName();
	string strDeviceIPPVersion = pFCIPPCommandsBase->GetDeviceIPPVersion();
	port = pFCIPPCommandsBase->GetDevicePortNumber();
	m_uiConnectionID = -1;

	if (!strDeviceIPPVersion.empty())
		memcpy(ippversion, strDeviceIPPVersion.c_str(), sizeof(ippversion));

	sprintf_s(url, HTTP_MAX_URI, "http://%s:%d/%s", strDeviceIPAddress.c_str(), port, strDeviceQueueName.c_str());
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Destructor. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

CFCIPPConnectionObject::~CFCIPPConnectionObject()
{
	CloseIPPConnection();

	m_pFCIPPCommandsBase->RemoveIPPConnectionID(m_uiConnectionID);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Open ipp connection. </summary>
///
/// <remarks>	</remarks>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::OpenIPPConnection()
{
	IPPLIB_RESULT uiError = IPPLIB_CONNECT_FAILED;

	httpSeparate(url, method, username, hostname, &port, resource);
	setConnectionAuthInfo();

	http = httpConnect(hostname, port);
	if (http != NULL)
	{
		sprintf_s(HTTP_uri, HTTP_MAX_URI, "http://%s:%d%s", hostname, port, resource);
		sprintf_s(IPP_uri, HTTP_MAX_URI, "ipp://%s:%d%s", hostname, port, resource);
		uiError = IPPLIB_SUCCESS;
		do_reconnect = 0;

		InitHashTables();
		strcpy(charset, "utf-8");

		//cupsLangGet() is causing a crash for us when we import 196 small jobs for a KM via a Hot Folder.  We have
		//yet to experience language not being "en_US" (never saw the FC_ASSERT that used to check for this)
		//so we will just hard-code this.
		if (NULL == language[0])
			language = "en_us";

		if (NULL == username[0])
			strcpy(username, DEFAULT_USERNAME);
	}
	else
	{
		InitConnectionInfo();
		CLogUtils::LOG_UTILS_ERROR("CFCIPPCommandsBase::OpenIPPConnection: unable to do a httpConnect.");
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Close ipp connection. </summary>
///
/// <remarks>	</remarks>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::CloseIPPConnection()
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	InitConnectionInfo();

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Starts ipp print job. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::StartIPPPrintJob(CFCIPPJobObject* pFCIPPJobObject)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (pFCIPPJobObject == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::StartIPPPrintJob: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (do_reconnect)
	{
		//		if (httpReconnect2(http, 30000, NULL))
		if (httpReconnect(http))
			do_reconnect = 0;
		else
			return IPPLIB_CONNECT_FAILED;
	}

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = StartJobRequest(pFCIPPJobObject);

		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "StartIPPPrintJob: StartJobRequest failed uiError = %d", uiError);
		}
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sends an ipp print data. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pBuffer">		  	The buffer. </param>
/// <param name="numBytes">		  	Number of bytes. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::SendIPPPrintData(CFCIPPJobObject* pFCIPPJobObject, const char* pBuffer, int numBytes)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (pFCIPPJobObject == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::SendIPPPrintData: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	uiError = SendJobData(pFCIPPJobObject, pBuffer, numBytes);
	if (uiError != IPPLIB_SUCCESS)
	{
		CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObject::SendIPPPrintData: SendJobData failed uiError = %d", uiError);
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Ends ipp print job. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::EndIPPPrintJob(CFCIPPJobObject* pFCIPPJobObject)
{
	IPPLIB_RESULT uiError = IPPLIB_ERROR;

	if (pFCIPPJobObject == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::EndIPPPrintJob: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject->pIPPRequest && http && !pFCIPPJobObject->error)
	{
		uiError = EndJobRequest(pFCIPPJobObject);

		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObject::EndIPPPrintJob: EndJobRequest failed uiError = %d", uiError);
		}
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets ipp job list. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pJobList">				[in,out] If non-null, list of jobs. </param>
/// <param name="bMyJobsOnly">			true to my jobs only. </param>
/// <param name="bJobCompleted">		true if job completed. </param>
/// <param name="bMonitorJobStatus">	true to monitor job status. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::GetIPPJobList(CJobList* pJobList, bool bMyJobsOnly, bool bJobCompleted, bool bMonitorJobStatus)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (pJobList == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::GetIPPJobList: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	CDeviceJobList::FreeJobList(pJobList);

	uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
		int iNumJobsInJobList = 0;
		uiError = GetJobList(pJobList, bMyJobsOnly, bJobCompleted, username, &iNumJobsInJobList, bMonitorJobStatus);
		if (uiError != IPPLIB_SUCCESS)
			CLogUtils::LOG_UTILS_EX(eERROR, "CFCIPPConnectionObject::GetIPPJobList: GetJobList failed uiError = %d", uiError);
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sets ipp debug trace level. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="level">	The level. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::setIPPDebugTraceLevel(int level)
{
	if (level > 0)
	{
		g_DebugTraceLevel = level;
	}

	return IPPLIB_SUCCESS;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets ipp printer state. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pState"> 	[in,out] If non-null, the state. </param>
/// <param name="pReason">	[in,out] If non-null, the reason. </param>
/// <param name="pMsg">   	[in,out] If non-null, the message. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::GetIPPPrinterState(IPPPRINTERSTATE *pState, 
														 IPPPRINTERSTATEREASONSTRUCT *pReason, PRTIPPDETAILEDMSG *pMsg)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if ((NULL == pState) || (NULL == pReason))
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::GetIPPPrinterState: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	uiError = VerifyHttpConnection(http);

	if (pMsg)
	{
		*pMsg = NULL;
	}

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = GetPrinterState(pState, pReason, pMsg);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObject::GetIPPPrinterState: GetPrinterState failed uiError = %d", uiError);
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Free ipp detailed message. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pMsg">	[in,out] If non-null, the message. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::FreeIPPDetailedMsg(PRTIPPDETAILEDMSG *pMsg)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	FreeDetailedMsgStruct(pMsg);

	return IPPLIB_SUCCESS;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets ipp printer information. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="prtInfo">	[in,out] If non-null, information describing the prt. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::GetIPPPrinterInfo(IPPPRINTERINFO *prtInfo)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (prtInfo == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::GetIPPPrinterInfo: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = GetPrinterInformation(prtInfo);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObject::GetIPPPrinterInfo: GetPrinterInformation failed uiError = %d", uiError);
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets ipp job progress. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">  	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pDevicePrintJob">				[in,out] If non-null, the job base. </param>
/// <param name="bFinalStatusCheck">	true to final status check. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::GetIPPJobProgress(CFCIPPJobObject* pFCIPPJobObject, CDevicePrintJob* pDevicePrintJob, bool bFinalStatusCheck)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (pFCIPPJobObject == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::GetIPPJobProgress: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = GetJobProgress(pFCIPPJobObject, pDevicePrintJob, bFinalStatusCheck);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObject::GetIPPJobProgress: GetJobProgress failed uiError = %d", uiError);
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets ipp job attributes. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="nJobID">  	Identifier for the job. </param>
/// <param name="pJobInfo">	Information describing the job. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::GetIPPJobAttributes(int nJobID, PTRIPPJOBINFO_3 pJobInfo)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (nJobID <=0 || pJobInfo == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::GetIPPJobAttributes: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = GetJobAttributes(nJobID, pJobInfo);
		if (uiError != IPPLIB_SUCCESS){
			CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObject::GetIPPJobAttributes: GetJobAttributes failed uiError = %d", uiError);
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Creates ipp print job. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pDevicePrintJob">    [in,out] If non-null, the sub job. </param>
/// <param name="ppFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pJobName">		   	Name of the job. </param>
/// <param name="pUserName">	   	Name of the user. </param>
/// <param name="pTemplate">	   	[in,out] If non-null, the template. </param>
/// <param name="pJobInfo">		   	Information describing the job. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::CreateIPPPrintJob(CDevicePrintJob* pDevicePrintJob, CFCIPPJobObject** ppFCIPPJobObject, 
														const char * pJobName, const char *pUserName,
														IPP_JOB_TEMPLATE *pTemplate, PTRIPPJOBINFO_1 pJobInfo)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if ((pDevicePrintJob == NULL) || (ppFCIPPJobObject == NULL))
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::CreateIPPPrintJob: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	CFCIPPJobObject* pFCIPPJobObject = new CFCIPPJobObject(m_pFCIPPCommandsBase, this, pDevicePrintJob);

	if (pFCIPPJobObject)
	{
		uiError = VerifyHttpConnection(http);

		if (uiError == IPPLIB_SUCCESS)
		{
			uiError = CreateJobRequest(pFCIPPJobObject, pTemplate, pJobInfo);
			if (uiError == IPPLIB_SUCCESS)
			{
				*ppFCIPPJobObject = pFCIPPJobObject;
			}
			else
			{
				CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObject::CreateIPPPrintJob: StartJobRequest failed uiError = %d", uiError);
			}
		}

		if (uiError != IPPLIB_SUCCESS)
		{
			delete pFCIPPJobObject;
			pFCIPPJobObject = NULL;
		}
	}
	else
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::CreateIPPPrintJob: unable to allocate memory for job handle");
		uiError = IPPLIB_MEM_ERROR;
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Starts ipp document. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pDocName">		  	Name of the document. </param>
/// <param name="lastDoc">		  	The last document. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::StartIPPDocument(CFCIPPJobObject* pFCIPPJobObject, const char *pDocName, int lastDoc)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	char docName[IPPLIB_MAX_NAME_LEN];

	if (pFCIPPJobObject == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::StartIPPDocument: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject->error)
	{
		return IPPLIB_ERROR;
	}

	if (pDocName)
	{
		strcpy(docName, pDocName);
	}
	else
	{
		strcpy(docName, DEFAULT_DOCUMENTNAME);
	}

	uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = StartDocument(pFCIPPJobObject, docName, lastDoc);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "SendIPPPrintData: StartDocument failed uiError = %d", uiError);
		}
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Cancel ipp job. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pDevicePrintJob">	[in,out] If non-null, the job base. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::CancelIPPJob(CDevicePrintJob* pDevicePrintJob)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (pDevicePrintJob == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::CancelIPPJob: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = CancelJob(atoi(pDevicePrintJob->m_strJLPQMID.c_str()), pDevicePrintJob->m_strActualUserNameSentToDevice.c_str());
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "CancelIPPJob: CancelJob failed uiError = %d", uiError);
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Purge ipp jobs. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="userName">	Name of the user. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::PurgeIPPJobs(const char *userName)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	char user[IPPLIB_MAX_NAME_LEN];

	if (userName == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::PurgeIPPJobs: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (userName)
	{
		strcpy(user, userName);
	}
	else
	{
		strcpy(user, DEFAULT_USERNAME);
	}

	uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = PurgeJobs(user);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "PurgeIPPJobs: PurgeJobs failed uiError = %d", uiError);
		}
	}
	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets ipp media ready. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="list">	[in,out] If non-null, the list. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::GetIPPMediaReady(IPPMEDIAREADY **list)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (list == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::GetIPPMediaReady: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = GetMediaReady(list);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "GetIPPMediaReady: GetMediaReady failed uiError = %d", uiError);
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Free media ready list. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="list">	[in,out] If non-null, the list. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::FreeMediaReadyList(IPPMEDIAREADY **list)
{
	if (list)
	{
		if (*list)
		{
			if ((*list)->mInfo)
			{
				free((*list)->mInfo);
				(*list)->mInfo = NULL;
			}
			free((*list));
			(*list) = NULL;
		}
	}

	return IPPLIB_SUCCESS;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets ipp media list. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pstrMediaCatalog">	[in,out] If non-null, the pstr media catalog. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::GetIPPMediaList(string* pstrMediaCatalog)
{
	IPPLIB_RESULT uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = GetMediaList(pstrMediaCatalog);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "GetIPPMediaList: GetMediaList failed uiError = %d", uiError);
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Starts ipp chunk data. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="chunkLength">	  	Length of the chunk. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::StartIPPChunkData(CFCIPPJobObject* pFCIPPJobObject, long chunkLength)
{
	IPPLIB_RESULT uiError = IPPLIB_ERROR;

	if ((NULL == pFCIPPJobObject) || (chunkLength <= 0))
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::StartIPPChunkData: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (!pFCIPPJobObject->error)
	{
		uiError = StartChunkData(pFCIPPJobObject, chunkLength);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "StartIPPChunkData: StartChunkData failed uiError = %d", uiError);
		}
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sends an ipp chunk data. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pBuffer">		  	The buffer. </param>
/// <param name="numBytes">		  	Number of bytes. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::SendIPPChunkData(CFCIPPJobObject* pFCIPPJobObject, const char *pBuffer, long numBytes)
{
	IPPLIB_RESULT uiError = IPPLIB_ERROR;

	if ((NULL == pFCIPPJobObject) || (pBuffer == NULL) || (numBytes <= 0))
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::SendIPPChunkData: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (!pFCIPPJobObject->error)
	{
		uiError = SendChunkData(pFCIPPJobObject, pBuffer, numBytes);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "SendIPPChunkData: SendChunkData failed uiError = %d", uiError);
		}
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sets ipp job attribute. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="key">			  	The key. </param>
/// <param name="value">		  	The value. </param>
/// <param name="tag_type">		  	Type of the tag. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::SetIPPJobAttribute(CFCIPPJobObject* pFCIPPJobObject, const char *key, const char *value, int tag_type)
{
	IPPLIB_RESULT uiError = IPPLIB_ERROR;

	if ((NULL == pFCIPPJobObject) || (key == NULL) || (value == NULL))
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::SetIPPJobAttribute: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (!pFCIPPJobObject->error)
	{
		uiError = SetJobAttribute(pFCIPPJobObject, key, value, tag_type);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "SetIPPJobAttribute: SetJobAttribute failed uiError = %d", uiError);
		}
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Adds an ipp page override. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pPageOverride">  	[in,out] If non-null, the page override. </param>
/// <param name="count">		  	Number of. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::AddIPPPageOverride(CFCIPPJobObject* pFCIPPJobObject, 
														 PTRIPPPAGEOVERRIDE** pPageOverride, int count)
{
	IPPLIB_RESULT uiError = IPPLIB_ERROR;

	if ((NULL == pFCIPPJobObject) || (pPageOverride == NULL))
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::AddIPPPageOverride: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (!pFCIPPJobObject->error)
	{
		uiError = AddPageOverride(pFCIPPJobObject, pPageOverride, count);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "AddIPPPageOverride: AddPageOverride failed uiError = %d", uiError);
		}
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Adds an ipp body media to 'pBodyMedia'. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pBodyMedia">	  	The body media. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::AddIPPBodyMedia(CFCIPPJobObject* pFCIPPJobObject, PTRIPPBODYMEDIA pBodyMedia)
{
	IPPLIB_RESULT uiError = IPPLIB_ERROR;

	if ((NULL == pFCIPPJobObject) || (pBodyMedia == NULL))
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::AddIPPBodyMedia: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (!pFCIPPJobObject->error)
	{
		uiError = AddBodyMedia(pFCIPPJobObject, pBodyMedia);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "AddIPPBodyMedia: AddBodyMedia failed uiError = %d", uiError);
		}
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Adds an ipp page insert. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pPageInsert">	  	[in,out] If non-null, the page insert. </param>
/// <param name="count">		  	Number of. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::AddIPPPageInsert(CFCIPPJobObject* pFCIPPJobObject, 
													   PTRIPPPAGEINSERT** pPageInsert, int count)
{
	IPPLIB_RESULT uiError = IPPLIB_ERROR;

	if ((NULL == pFCIPPJobObject) || (pPageInsert == NULL))
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::AddIPPPageInsert: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (!pFCIPPJobObject->error)
	{
		uiError = AddPageInsert(pFCIPPJobObject, pPageInsert, count);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "AddIPPPageInsert: AddPageInsert failed uiError = %d", uiError);
		}
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sends an ipp header data. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::SendIPPHeaderData(CFCIPPJobObject* pFCIPPJobObject)
{
	IPPLIB_RESULT uiError = IPPLIB_ERROR;

	if (NULL == pFCIPPJobObject)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::SendIPPHeaderData: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (!pFCIPPJobObject->error)
	{
		uiError = SendIPPHeaderChunk(pFCIPPJobObject);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "SendIPPHeaderData: SetJobAttribute failed uiError = %d", uiError);
		}
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Ends ipp chunk data. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::EndIPPChunkData(CFCIPPJobObject* pFCIPPJobObject)
{
	IPPLIB_RESULT uiError = IPPLIB_ERROR;

	if (NULL == pFCIPPJobObject)
	{
		CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObject::EndIPPChunkData: Invalid param.");
		return IPPLIB_INVALID_PARAM;
	}

	if (!pFCIPPJobObject->error)
	{
		uiError = EndChunkData(pFCIPPJobObject);
		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "EndIPPChunkData: EndChunkData failed uiError = %d", uiError);
		}
	}

	return  uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets the device's ppd. </summary>
///
/// <remarks>	The ppd gets stored as a file on the server. </remarks>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObject::GetPPD()
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
/*
    //ostringstream srcPPD;
    ostringstream destPPD;
    ostringstream devPath;
    ostringstream ppdBase;
    char throughput[256];
    char manufacturer[256];
    char actualFilePath[S_PATH_MAX];
    char instoptions_path[S_PATH_MAX];


    //srcPPD.str(m_sPPDSource);
    destPPD << "/scsi0/ppdfiles/" << m_sDevName << "_" << m_sIpAddress 
        << ".ppd";

    if(S_OK == S_FileCopy(destPPD.str().c_str(), m_sPPDSource.c_str()))
    {
        ppdBase << m_sDevName << "_" << m_sIpAddress  << ".ppd";
        m_sPPDBase = ppdBase.str();
        devPath << "/scsi0/ppdfiles\\" << ppdBase.str().c_str();
	    SI_TranslateRoot(actualFilePath, devPath.str().c_str());

        if(S_OK == ValidatePPD(actualFilePath, instoptions_path, 
            sizeof(instoptions_path), &m_structMixedMedia, 0))
        {
            returnVal = 1;
        }
        
        m_sPPDInstPath = instoptions_path;
        
        if(-1 == m_iPPMRate)
        {
            if(S_OK == GetRequiredKeyStringFromPPD(
                (char *)devPath.str().c_str(), "*Throughput", throughput, 256))
            {
                sscanf(throughput, "%d", &m_iPPMRate);
            }
        }

        if(S_OK == GetRequiredKeyStringFromPPD((char*)devPath.str().c_str(), 
            "*Manufacturer", manufacturer, 256))
        {
            m_sOEM = manufacturer;
        }
    }
*/
    return uiError;
}
