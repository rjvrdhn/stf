// FCIPPConnectionObject.h: interface for the CFCIPPCommandsBase class.
/********************************************************************
*
*  (c) Copyright 2013  
*      Electronics for Imaging, Inc. ("EFI").
*      All Rights Reserved
*
*  EFI products contain certain trade secrets and confidential and
*  proprietary information of EFI.  Use, reproduction, disclosure,
*  distribution by any means are prohibited, except pursuant to
*  a written license from EFI. Modification, translation, reverse
*  engineering, decompiling, disassembling, and creating derivative
*  works based on this software are prohibited, except pursuant to
*  a written license from EFI. Use of copyright notice does not imply
*  publication or disclosure.
*
*  Restricted Rights Legend:
*  Use, duplication, or disclosure by the Government is subject to
*  restrictions as set forth in subparagraph (c)(1)(ii) of The
*  Rights in Technical Data and Computer Software clause in DFARS
*  252.227-7013 or subparagraphs (c)(1) and (2) of the Commercial
*  Computer Software--Restricted Rights at 48 CFR 52.227-19, as
*  applicable.
*
**********************************************************************
*/
#pragma once

#include "FCIPPConnectionObjectBase.h"

#pragma warning (push)
#pragma warning (disable:4251)

class CFCIPPJobObject;


class CFCIPPConnectionObject : public CFCIPPConnectionObjectBase
{
	UINT m_uiConnectionID;

public:
	CFCIPPConnectionObject(CFCIPPCommandsBase* pFCIPPCommandsBase);
	virtual ~CFCIPPConnectionObject();

	UINT GetConnectionID() { return m_uiConnectionID; }
	void SetConnectionID(int uiConnectionID) { m_uiConnectionID = uiConnectionID; }

	IPPLIB_RESULT OpenIPPConnection();
	IPPLIB_RESULT CloseIPPConnection();

	IPPLIB_RESULT GetPPD();
	IPPLIB_RESULT StartIPPPrintJob(CFCIPPJobObject* pFCIPPJobObject);
	IPPLIB_RESULT SendIPPPrintData(CFCIPPJobObject* pFCIPPJobObject, const char* pBuffer, int numBytes);
	IPPLIB_RESULT EndIPPPrintJob(CFCIPPJobObject* pFCIPPJobObject);
	IPPLIB_RESULT GetIPPJobList(CJobList* pJobList, bool bMyJobsOnly, bool bJobCompleted, bool bMonitorJobStatus);
	IPPLIB_RESULT setIPPDebugTraceLevel(int level);
	IPPLIB_RESULT GetIPPPrinterState(IPPPRINTERSTATE *pState, IPPPRINTERSTATEREASONSTRUCT *pReason, PRTIPPDETAILEDMSG *pMsg);
	IPPLIB_RESULT FreeIPPDetailedMsg(PRTIPPDETAILEDMSG *pMsg);
	IPPLIB_RESULT GetIPPPrinterInfo(IPPPRINTERINFO *prtInfo);
	IPPLIB_RESULT GetIPPJobProgress(CFCIPPJobObject* pFCIPPJobObject, CDevicePrintJob* pDevicePrintJob, bool bFinalStatusCheck);
	IPPLIB_RESULT GetIPPJobAttributes(int nJobID, PTRIPPJOBINFO_3 pJobInfo);
	IPPLIB_RESULT CreateIPPPrintJob(CDevicePrintJob* pDevicePrintJob, CFCIPPJobObject** pFCIPPJobObject, const char* pJobName, const char* pUserName, IPP_JOB_TEMPLATE *pTemplate, PTRIPPJOBINFO_1 pJobInfo);
	IPPLIB_RESULT StartIPPDocument(CFCIPPJobObject* pFCIPPJobObject, const char *pDocName, int lastDoc);
	IPPLIB_RESULT CancelIPPJob(CDevicePrintJob* pDevicePrintJob);
	IPPLIB_RESULT PurgeIPPJobs(const char *userName);
	IPPLIB_RESULT GetIPPMediaReady(IPPMEDIAREADY **list);
	IPPLIB_RESULT FreeMediaReadyList(IPPMEDIAREADY **list);
	IPPLIB_RESULT GetIPPMediaList(string* pstrMediaCatalog);
	IPPLIB_RESULT StartIPPChunkData(CFCIPPJobObject* pFCIPPJobObject, long chunkLength);
	IPPLIB_RESULT SendIPPChunkData(CFCIPPJobObject* pFCIPPJobObject, const char *pBuffer, long numBytes);
	IPPLIB_RESULT SetIPPJobAttribute(CFCIPPJobObject* pFCIPPJobObject, const char *key, const char *value, int tag_type);
	IPPLIB_RESULT AddIPPPageOverride(CFCIPPJobObject* pFCIPPJobObject, PTRIPPPAGEOVERRIDE ** pPageOverride, int count);
	IPPLIB_RESULT AddIPPBodyMedia(CFCIPPJobObject* pFCIPPJobObject, PTRIPPBODYMEDIA pBodyMedia);
	IPPLIB_RESULT AddIPPPageInsert(CFCIPPJobObject* pFCIPPJobObject, PTRIPPPAGEINSERT** pPageInsert, int count);
	IPPLIB_RESULT SendIPPHeaderData(CFCIPPJobObject* pFCIPPJobObject);
	IPPLIB_RESULT EndIPPChunkData(CFCIPPJobObject* pFCIPPJobObject);

protected:

};

typedef map<int, CFCIPPConnectionObject*> CFCIPPConnectionObjectMap;

#pragma warning (pop)
