// FCIPPConnectionObjectBase.cpp: implementation of the CFCIPPConnectionObjectBase class.

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	A macro that defines window 32 lean and mean. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers, Needed with CUPS

#include <windows.h>

#if __cplusplus
extern "C" {
#endif
#include "http-private.h"   // Cups external library
#if __cplusplus
}
#endif

#include "DeviceJobList.h"
#include "FCIPPConnectionObjectBase.h"
#include "FCIPPCommandsBase.h"
#include "FCIPPConnectionObjectBaseMisc.h"
#include "FCIPPJobObject.h"
#include "harmony10.h"
#include "DevicePrintJobCache.h"

/// <summary>	The password. </summary>
char* g_password;

// 'password_cb()' - Disable the password prompt for cupsDoFileRequest().

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Password cb. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="prompt">	The prompt. </param>
///
/// <returns>	null if it fails, else a char*. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

const char* password_cb(const char* prompt)	/* I - Prompt (not used) */
{
	(void)prompt;

	return (g_password);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Constructor. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPCommandsBase">	[in,out] If non-null, the fcipp commands base. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

CFCIPPConnectionObjectBase::CFCIPPConnectionObjectBase(CFCIPPCommandsBase* pFCIPPCommandsBase)
{
	m_pFCIPPCommandsBase = pFCIPPCommandsBase;
	m_pMediaTypeUtilities = m_pFCIPPCommandsBase->GetMediaTypeUtilities();
	m_pPaperTypeUtilities = m_pFCIPPCommandsBase->GetPaperTypeUtilities();
	m_pDevice = m_pFCIPPCommandsBase->GetDevice();
	m_bDeviceSupportsStatusAfterRemovedFromJobList = m_pDevice->DoesDeviceSupportStatusAfterRemovedFromJobList();
	m_bRequiresPrintedJobNotVerifiedOnDeviceJobList = m_pDevice->DoesRequirePrintedJobNotVerifiedOnDeviceJobList();
	m_bRequiresLostJobNotVerifiedOnDeviceJobList = m_pDevice->DoesRequireLostJobNotVerifiedOnDeviceJobList();
	m_iPrintedJobNotVerifiedOnDeviceJobListCountLimit = m_pDevice->GetPrintedJobNotVerifiedOnDeviceJobListCountLimit();
	m_iPrintedJobNotVerifiedOnDeviceJobListMinimumPagesExpected = m_pDevice->GetPrintedJobNotVerifiedOnDeviceJobListMinimumPagesExpected();
	m_bAddIDToUserNameForJobMappingID = m_pFCIPPCommandsBase->DoesDeviceAddIDToUserNameForJobMappingID();
	m_bIPPJobListJobIDIsValid = m_pDevice->IsDeviceIPPJobListJobIDIsValid();
	m_bGetJobProgressOnceWhenJobFinished = m_pDevice->GetJobProgressOnceWhenJobFinished();
	m_pDevicePrintJobCache = m_pFCIPPCommandsBase->GetDevicePrintJobCache();
	m_strDeviceID = m_pFCIPPCommandsBase->GetDeviceID();
	m_bUseJobNameToGetJobID = m_pFCIPPCommandsBase->m_bUseJobNameToGetJobID;
	m_iCheckJobProgessPrintingState = m_pFCIPPCommandsBase->GetCheckJobProgessPrintingState();
	g_password = password;
	m_nRetries = 3;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Destructor. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

CFCIPPConnectionObjectBase::~CFCIPPConnectionObjectBase()
{

}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sets connection authentication information. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CFCIPPConnectionObjectBase::setConnectionAuthInfo()
{
	cupsSetPasswordCB(password_cb);

	if (NULL != username[0])
	{
		password = (char* )strchr(username, ':');
		if (password != NULL)
			*password++ = '\0';

		cupsSetUser(username);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Chttp printf. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="http">  	[in,out] If non-null, the HTTP. </param>
/// <param name="format">	Describes the format to use. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::FChttpPrintf(http_t *http, const char *format, ...)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	char buffer[HTTP_MAX_BUFFER] = {0};
	va_list pArg;
	va_start(pArg, format);
	int numBytes = vsprintf_s(buffer, HTTP_MAX_BUFFER, format, pArg);
	va_end(pArg);

	uiError = FChttpWrite(http, buffer, numBytes);

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Chttp write. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="http">  	[in,out] If non-null, the HTTP. </param>
/// <param name="buffer">	The buffer. </param>
/// <param name="length">	The length. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::FChttpWrite(http_t *http, const char *buffer, int length)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	for (int i=0; i<m_nRetries; i++)
	{
		if (httpWrite(http, buffer, length) < length)
		{
			do_reconnect = 1;
			CLogUtils::LOG_UTILS_DEBUG("SendJobData: Error Writing Data");
			http_encoding_t data_encoding = http->data_encoding;
			uiError = VerifyHttpConnection(http);
			http->data_encoding = data_encoding;

			if (uiError != IPPLIB_SUCCESS)
				return uiError;
		}
		else
		{
			uiError = IPPLIB_SUCCESS;
			break;
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Verify HTTP connection. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="http">	[in,out] If non-null, the HTTP. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::VerifyHttpConnection(http_t *http)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (do_reconnect)
	{
		if (httpReconnect(http) == 0)
		{
			CLogUtils::LOG_UTILS_DEBUG("VerifyHttpConnection: httpReconnect successful.");
			do_reconnect = 0;
		}
		else
		{
			CLogUtils::LOG_UTILS_ERROR("VerifyHttpConnection: httpReconnect failed.");
			uiError = IPPLIB_CONNECT_FAILED;
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Starts job request. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::StartJobRequest(CFCIPPJobObject* pFCIPPJobObject)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("PrintJobRequest: invalid parameter");
		return IPPLIB_INTERNAL_ERROR;
	}

	ipp_t* pRequest = ippNew();

	if (pRequest != NULL)
	{
		memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
		pRequest->request.op.operation_id = IPP_PRINT_JOB;
		pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET, "attributes-charset", NULL, charset);
		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE, "attributes-natural-language", NULL, language != NULL ? language : "C");
		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, IPP_uri);
		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_NAME, "requesting-user-name", NULL, pFCIPPJobObject->userName);

		if (pFCIPPJobObject->jobName)
			ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_NAME, "job-name", NULL, pFCIPPJobObject->jobName);

		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_MIMETYPE, "document-format", NULL, "application/octet-stream");

		pFCIPPJobObject->pIPPRequest = pRequest;
	}
	else
	{
		CLogUtils::LOG_UTILS_DEBUG("PrintJobRequest: unable to allocate memory for ipp request");
		uiError = IPPLIB_MEM_ERROR;
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		pFCIPPJobObject->error = 1;
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sends an ipp header chunk. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::SendIPPHeaderChunk(CFCIPPJobObject* pFCIPPJobObject)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("SendIPPHeaderChunk: invalid parameter");
		return IPPLIB_INTERNAL_ERROR;
	}

	ipp_t* pRequest = pFCIPPJobObject->pIPPRequest;
	int requestLen = (int)ippLength(pRequest);
	ipp_state_t status;

	while (true)
	{
		httpClearFields(http);
		httpSetField(http, HTTP_FIELD_TRANSFER_ENCODING, "chunked");
		httpSetField(http, HTTP_FIELD_CONTENT_TYPE, "application/ipp");
		httpSetField(http, HTTP_FIELD_CONNECTION, "Keep-Alive");
		httpSetField(http, HTTP_FIELD_KEEP_ALIVE, "timeout=60");
		httpSetField(http, HTTP_FIELD_AUTHORIZATION, "");

		// Try the request...
		if (httpPost(http, resource))
		{
			if (httpReconnect(http))
			{
				status = IPP_ERROR;
				break;
			}
			else
				continue;
		}

		pRequest->state = IPP_IDLE;
		status = ippWrite(http, pRequest);

		if (status == IPP_ERROR)
			uiError = IPPLIB_HTTP_ERROR;

		break;
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		CLogUtils::LOG_UTILS_DEBUG("SendIPPHeaderChunked: Error Writing IPP Data chunk xfer request.");
		return IPPLIB_HTTP_ERROR;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sends a job data. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pBuffer">		  	The buffer. </param>
/// <param name="numBytes">		  	Number of bytes. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::SendJobData(CFCIPPJobObject* pFCIPPJobObject, const char* pBuffer, int numBytes)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject == NULL || pBuffer == NULL || numBytes <= 0)
	{
		CLogUtils::LOG_UTILS_DEBUG("SendJobData: invalid parameter");
		uiError = IPPLIB_INTERNAL_ERROR;
	}

	if (uiError == IPPLIB_SUCCESS)
	{
//		uiError = FChttpPrintf(http, "%x\r\n", numBytes);
//Don
		if (uiError == IPPLIB_SUCCESS)
		{
			uiError = FChttpWrite(http, pBuffer, numBytes);

			if (uiError == IPPLIB_SUCCESS)
			{
//				uiError = FChttpPrintf(http, "\r\n");

				if (uiError != IPPLIB_SUCCESS)
					CLogUtils::LOG_UTILS_DEBUG("SendJobData: Error FChttpPrintf chunk beginning");
			}
			else
				CLogUtils::LOG_UTILS_DEBUG("SendJobData: Error Writing Data");
		}
		else
			CLogUtils::LOG_UTILS_DEBUG("SendJobData: Error FChttpPrintf chunk beginning");
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		pFCIPPJobObject->error = 1;
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Starts chunk data. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="chunkLength">	  	Length of the chunk. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::StartChunkData(CFCIPPJobObject* pFCIPPJobObject, long chunkLength)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject == NULL || chunkLength <= 0)
	{
		CLogUtils::LOG_UTILS_DEBUG("StartChunkData: invalid parameter");
		return IPPLIB_INTERNAL_ERROR;
	}

	uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
//		uiError = FChttpPrintf(http, "%x\r\n", chunkLength);

		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_DEBUG("StartChunkData: Error FChttpPrintf chunk beginning");
			uiError = IPPLIB_HTTP_ERROR;
		}
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		pFCIPPJobObject->error = 1;
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sends a chunk data. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pBuffer">		  	The buffer. </param>
/// <param name="numBytes">		  	Number of bytes. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::SendChunkData(CFCIPPJobObject* pFCIPPJobObject, const char* pBuffer, long numBytes)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject == NULL || pBuffer == NULL || numBytes <= 0)
	{
		CLogUtils::LOG_UTILS_DEBUG("SendChunkData: invalid parameter");
		return IPPLIB_INTERNAL_ERROR;
	}

	uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = FChttpWrite(http, pBuffer, numBytes);

		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_DEBUG("SendChunkData: Error Writing Data");
		}
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		pFCIPPJobObject->error = 1;
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sets job attribute. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="key">			  	The key. </param>
/// <param name="value">		  	The value. </param>
/// <param name="tag_type">		  	Type of the tag. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::SetJobAttribute(CFCIPPJobObject* pFCIPPJobObject, const char* key, const char* value, int tag_type)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (pFCIPPJobObject == NULL || key == NULL || value == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("SetJobAttribute: invalid parameter");
		uiError = IPPLIB_INTERNAL_ERROR;
	}

	// set job attribute via ipp here
	if (uiError == IPPLIB_SUCCESS)
	{    
		// key/value pair add as string?
		ippAddString(pFCIPPJobObject->pIPPRequest, IPP_TAG_OPERATION, (ipp_tag_t)tag_type, key, NULL, value);
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		pFCIPPJobObject->error = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Adds a page override. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pPageOverride">  	[in,out] If non-null, the page override. </param>
/// <param name="numOverrides">   	Number of overrides. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::AddPageOverride(CFCIPPJobObject* pFCIPPJobObject, 
														  PTRIPPPAGEOVERRIDE** pPageOverride, int numOverrides)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	ipp_t** col = NULL;
	ipp_t* mediaCol = NULL;
	ipp_t* mediaSizeCol = NULL;

	if (pFCIPPJobObject == NULL || pPageOverride == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("AddPageOverride: invalid parameter");
		uiError = IPPLIB_INTERNAL_ERROR;
	}

	// set job attribute via ipp here
	if (uiError == IPPLIB_SUCCESS)
	{      
		col = (ipp_t**)malloc(sizeof(ipp_t*) *numOverrides);
		if (NULL == col)
		{
			uiError = IPPLIB_MEM_ERROR;
			return uiError;
		}

		for (int i=0;i<numOverrides;i++)
		{
			col[i] = ippNew();
			mediaCol = ippNew();
			mediaSizeCol = ippNew();

			if (NULL != col[i] && NULL != mediaCol)
			{
				ippAddRange(col[i], IPP_TAG_OPERATION, "input-documents", 1, 1);

				ippAddRange(col[i], IPP_TAG_OPERATION, "pages", 
					(*pPageOverride)[i]->startPage, (*pPageOverride)[i]->endPage);

				if (0 != (*pPageOverride)[i]->xImageShift)
				{
					ippAddInteger(col[i], IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"x-image-shift", (*pPageOverride)[i]->xImageShift);
				}

				if (0 != (*pPageOverride)[i]->yImageShift)
				{
					ippAddInteger(col[i], IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"y-image-shift", (*pPageOverride)[i]->yImageShift);
				}

				if (0 != (*pPageOverride)[i]->xSide1ImageShift)
				{
					ippAddInteger(col[i], IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"x-side1-image-shift", (*pPageOverride)[i]->xSide1ImageShift);
				}

				if (0 != (*pPageOverride)[i]->xSide2ImageShift)
				{
					ippAddInteger(col[i], IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"x-side2-image-shift", (*pPageOverride)[i]->xSide2ImageShift);
				}

				if (0 != (*pPageOverride)[i]->ySide1ImageShift)
				{
					ippAddInteger(col[i], IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"y-side1-image-shift", (*pPageOverride)[i]->ySide1ImageShift);
				}

				if (0 != (*pPageOverride)[i]->ySide2ImageShift)
				{
					ippAddInteger(col[i], IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"y-side2-image-shift", (*pPageOverride)[i]->ySide2ImageShift);
				}

				if (0 != strcmp("", (*pPageOverride)[i]->sides))
				{
					ippAddString(col[i], IPP_TAG_OPERATION, IPP_TAG_KEYWORD, "sides", 
						NULL, (*pPageOverride)[i]->sides);
				}

				// media-col attributes
				// only set the attribute if we have a valid value, not -1 or ""
				if (0 != strcmp("", (*pPageOverride)[i]->media_col.key))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-key", NULL, (*pPageOverride)[i]->media_col.key);
				}

				if (0 != strcmp("", (*pPageOverride)[i]->media_col.description))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-description", NULL, 
						(*pPageOverride)[i]->media_col.description);
				}

				if (0 != strcmp("", (*pPageOverride)[i]->media_col.type))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-type", NULL, 
						(*pPageOverride)[i]->media_col.type);
				}

				if (0 != strcmp("", (*pPageOverride)[i]->media_col.pre_printed))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-pre-printed", NULL, 
						(*pPageOverride)[i]->media_col.pre_printed);
				}

				if (0 != strcmp("", (*pPageOverride)[i]->media_col.color))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-color", NULL, 
						(*pPageOverride)[i]->media_col.color);
				}

				if (0 != strcmp("", (*pPageOverride)[i]->media_col.info))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-info", NULL, 
						(*pPageOverride)[i]->media_col.info);
				}

				if (0 != strcmp("", (*pPageOverride)[i]->media_col.recycled))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-recycled", NULL, 
						(*pPageOverride)[i]->media_col.recycled);
				}

				if (-1 != (*pPageOverride)[i]->media_col.hole_count)
				{
					ippAddInteger(mediaCol, IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"media-hole-count", 
						(*pPageOverride)[i]->media_col.hole_count);
				}

				if (-1 != (*pPageOverride)[i]->media_col.order_count)
				{
					ippAddInteger(mediaCol, IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"media-order-count", 
						(*pPageOverride)[i]->media_col.order_count);
				}

				if (-1 != (*pPageOverride)[i]->media_col.size.x_dim &&
					-1 != (*pPageOverride)[i]->media_col.size.y_dim)
				{
					// media size is a collection
					// conversion needed? __ to __?
					ippAddInteger(mediaSizeCol, IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"x-dimension", 
						((*pPageOverride)[i]->media_col.size.x_dim * 100));

					ippAddInteger(mediaSizeCol, IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"y-dimension", 
						((*pPageOverride)[i]->media_col.size.y_dim * 100));

					ippAddCollection(mediaCol, IPP_TAG_OPERATION, "media-size", mediaSizeCol);
				}

				if (-1 != (*pPageOverride)[i]->media_col.weight_metric)
				{
					ippAddInteger(mediaCol, IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"media-weight-metric", 
						(*pPageOverride)[i]->media_col.weight_metric);
				}

				ippAddCollection(col[i], IPP_TAG_OPERATION, "media-col", mediaCol);
			}
		}
	}

	ippAddCollections(pFCIPPJobObject->pIPPRequest, IPP_TAG_OPERATION, "page-overrides", numOverrides, (const ipp_t**)col);

	if (uiError != IPPLIB_SUCCESS)
	{
		pFCIPPJobObject->error = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Adds a body media to 'pBodyMedia'. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pBodyMedia">	  	The body media. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::AddBodyMedia(CFCIPPJobObject* pFCIPPJobObject, PTRIPPBODYMEDIA pBodyMedia)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (pFCIPPJobObject == NULL || pBodyMedia == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("AddBodyMedia: invalid parameter");
		uiError = IPPLIB_INTERNAL_ERROR;
	}

	// set body media as media-col via ipp here
	if (uiError == IPPLIB_SUCCESS)
	{          
		ipp_t* mediaCol = ippNew();

		if (NULL != mediaCol)
		{      
			ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
				"media-key", NULL, pBodyMedia->mediaKey);

			ippAddCollection(pFCIPPJobObject->pIPPRequest, IPP_TAG_OPERATION, "media-col", mediaCol);
		}
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		pFCIPPJobObject->error = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Adds a page insert. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pPageInsert">	  	[in,out] If non-null, the page insert. </param>
/// <param name="numInsertions">  	Number of insertions. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::AddPageInsert(CFCIPPJobObject* pFCIPPJobObject, 
														PTRIPPPAGEINSERT ** pPageInsert, int numInsertions)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	ipp_t** col = NULL;
	ipp_t* mediaCol = NULL;
	ipp_t* mediaSizeCol = NULL;

	if (pFCIPPJobObject == NULL || pPageInsert == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("AddPageInsert: invalid parameter");
		uiError = IPPLIB_INTERNAL_ERROR;
	}

	// set job attribute via ipp here
	if (uiError == IPPLIB_SUCCESS)
	{  
		// if can't find "insert-sheet"
		col = (ipp_t**)malloc(sizeof(ipp_t *) * numInsertions);
		if (NULL == col)
		{
			uiError = IPPLIB_MEM_ERROR;
			return uiError;
		}

		for (int i=0;i<numInsertions;i++)
		{    
			col[i] = ippNew();
			mediaCol = ippNew();
			mediaSizeCol = ippNew();

			if (NULL != col[i] && NULL != mediaCol)
			{
				ippAddInteger(col[i], IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
					"insert-after-page-number", (*pPageInsert)[i]->afterPage);

				ippAddInteger(col[i], IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
					"insert-count", (*pPageInsert)[i]->count);

				// media-col attributes
				// only set the attribute if we have a valid value, not -1 or ""
				if (0 != strcmp("", (*pPageInsert)[i]->media_col.key))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-key", NULL, (*pPageInsert)[i]->media_col.key);
				}

				if (0 != strcmp("", (*pPageInsert)[i]->media_col.description))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-description", NULL, 
						(*pPageInsert)[i]->media_col.description);
				}

				if (0 != strcmp("", (*pPageInsert)[i]->media_col.type))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-type", NULL, 
						(*pPageInsert)[i]->media_col.type);
				}

				if (0 != strcmp("", (*pPageInsert)[i]->media_col.pre_printed))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-pre-printed", NULL, 
						(*pPageInsert)[i]->media_col.pre_printed);
				}

				if (0 != strcmp("", (*pPageInsert)[i]->media_col.color))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-color", NULL, 
						(*pPageInsert)[i]->media_col.color);
				}

				if (0 != strcmp("", (*pPageInsert)[i]->media_col.info))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-info", NULL, 
						(*pPageInsert)[i]->media_col.info);
				}

				if (0 != strcmp("", (*pPageInsert)[i]->media_col.recycled))
				{
					ippAddString(mediaCol, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, 
						"media-recycled", NULL, 
						(*pPageInsert)[i]->media_col.recycled);
				}

				if (-1 != (*pPageInsert)[i]->media_col.hole_count)
				{
					ippAddInteger(mediaCol, IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"media-hole-count", 
						(*pPageInsert)[i]->media_col.hole_count);
				}

				if (-1 != (*pPageInsert)[i]->media_col.order_count)
				{
					ippAddInteger(mediaCol, IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"media-order-count", 
						(*pPageInsert)[i]->media_col.order_count);
				}

				if (-1 != (*pPageInsert)[i]->media_col.size.x_dim &&
					-1 != (*pPageInsert)[i]->media_col.size.y_dim)
				{
					// media size is a collection
					// conversion needed? __ to __?
					ippAddInteger(mediaSizeCol, IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"x-dimension", 
						((*pPageInsert)[i]->media_col.size.x_dim * 100));

					ippAddInteger(mediaSizeCol, IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"y-dimension", 
						((*pPageInsert)[i]->media_col.size.y_dim * 100));

					ippAddCollection(mediaCol, IPP_TAG_OPERATION, "media-size", mediaSizeCol);
				}

				if (-1 != (*pPageInsert)[i]->media_col.weight_metric)
				{
					ippAddInteger(mediaCol, IPP_TAG_OPERATION, IPP_TAG_INTEGER, 
						"media-weight-metric", 
						(*pPageInsert)[i]->media_col.weight_metric);
				}

				ippAddCollection(col[i], IPP_TAG_OPERATION, "media-col", mediaCol);
			}
		}

		ippAddCollections(pFCIPPJobObject->pIPPRequest, IPP_TAG_OPERATION, "insert-sheet", numInsertions, (const ipp_t**)col);
	}

	if (NULL != col)
	{
		free(col);
		col = NULL;
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		pFCIPPJobObject->error = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Ends chunk data. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::EndChunkData(CFCIPPJobObject* pFCIPPJobObject)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("EndChunkData: invalid parameter");
		return IPPLIB_INTERNAL_ERROR;
	}

	uiError = VerifyHttpConnection(http);

	if (uiError == IPPLIB_SUCCESS)
	{
		uiError = FChttpPrintf(http, "\r\n");

		if (uiError != IPPLIB_SUCCESS)
		{
			CLogUtils::LOG_UTILS_DEBUG("EndChunkData: Error FChttpPrintf chunk end");
			uiError = IPPLIB_HTTP_ERROR;
		}
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		pFCIPPJobObject->error = 1;
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Ends job request. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::EndJobRequest(CFCIPPJobObject* pFCIPPJobObject)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("EndJobRequest: invalid parameter");
		return IPPLIB_INTERNAL_ERROR;
	}

	pFCIPPJobObject->jobID = 0;
	pFCIPPJobObject->jobUri[0] = '\0';
	pFCIPPJobObject->jobState = IPP_JOB_STATE_PENDING;

	// we are done with request
	if (pFCIPPJobObject->pIPPRequest)
	{
		ippDelete(pFCIPPJobObject->pIPPRequest);
		pFCIPPJobObject->pIPPRequest = NULL;
	}

	// Send last Empty Chunk - indicating End of chunks
//	uiError = FChttpPrintf(http, "%x\r\n", 0);
//Don	uiError = FChttpPrintf(http, "%x\r\n\r\n", 0);

	if (uiError != IPPLIB_SUCCESS)
	{
		CLogUtils::LOG_UTILS_DEBUG("EndJobRequest: Error FChttpPrintf last chunk");
		return uiError;
	}

	// Wait for response
	int retryCount = 0;
	int status;

	while (((status = httpUpdate(http)) == HTTP_CONTINUE) && (retryCount < 10))
	{
		Sleep(100);
		retryCount++;
	}

	if (retryCount >= 10)
	{
		CLogUtils::LOG_UTILS_DEBUG("EndJobRequest: httpUpdate retry count exceeded");
	}

	if (status != HTTP_OK)
	{
		CLogUtils::LOG_UTILS_EX(eDEBUG, "EndJobRequest: HTTP Error = %d", status);
		return IPPLIB_HTTP_ERROR;
	}

	ipp_t* pResponse = ippNew();

	if (ippRead(http, pResponse) == IPP_ERROR)
	{
		CLogUtils::LOG_UTILS_DEBUG("EndJobRequest: IPP Read Error");
		return IPPLIB_IPP_ERROR;
	}

	if (pResponse->request.status.status_code > IPP_OK_CONFLICT)
	{
		CLogUtils::LOG_UTILS_EX(eDEBUG, "EndJobRequest: failed: %s", ippErrorString(pResponse->request.status.status_code));
		uiError = IPPLIB_ERROR;
	}
	else
	{
		ipp_attribute_t* attr = ippFindAttribute(pResponse, "job-id", IPP_TAG_INTEGER);

		if (attr)
		{
			pFCIPPJobObject->jobID = attr->values[0].integer;
			CLogUtils::LOG_UTILS_EX(eDEBUG, "EndJobRequest: job-id = %d", pFCIPPJobObject->jobID);
		}
		else
		{
			CLogUtils::LOG_UTILS_DEBUG("EndJobRequest: IPP Error did not find job-id attribute");
			uiError = IPPLIB_ERROR;
		}

		attr = ippFindAttribute(pResponse, "job-uri", IPP_TAG_URI);

		if (attr)
		{
			strncpy(pFCIPPJobObject->jobUri, attr->values[0].string.text, sizeof(pFCIPPJobObject->jobUri)-1);
			pFCIPPJobObject->jobUri[sizeof(pFCIPPJobObject->jobUri)-1] = 0;
			CLogUtils::LOG_UTILS_EX(eDEBUG, "EndJobRequest: job-uri = %s", pFCIPPJobObject->jobUri);
		}
		else
		{
			CLogUtils::LOG_UTILS_DEBUG("EndJobRequest: IPP Error did not find job-uri attribute");
			uiError = IPPLIB_ERROR;
		}

		attr = ippFindAttribute(pResponse, "job-state", IPP_TAG_ENUM);
		if (attr)
		{
			pFCIPPJobObject->jobState = (int)attr->values[0].integer;
			CLogUtils::LOG_UTILS_EX(eDEBUG, "EndJobRequest: job-state = %d", pFCIPPJobObject->jobState);
		}
		else
		{
			CLogUtils::LOG_UTILS_DEBUG("EndJobRequest: IPP Error did not find job-state attribute");
			uiError = IPPLIB_ERROR;
		}
	}

	ippDelete(pResponse);
	pFCIPPJobObject->pIPPResponse = pResponse = NULL;

	if (uiError != IPPLIB_SUCCESS)
	{
		pFCIPPJobObject->error = 1;
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets job list. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pJobList">				[in,out] If non-null, list of jobs. </param>
/// <param name="bMyJobsOnly">			true to my jobs only. </param>
/// <param name="bJobCompleted">		true if job completed. </param>
/// <param name="pUserName">			[in,out] If non-null, name of the user. </param>
/// <param name="pNumJobs">				[in,out] If non-null, number of jobs. </param>
/// <param name="bMonitorJobStatus">	true to monitor job status. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::GetJobList(CJobList *pJobList, bool bMyJobsOnly, bool bJobCompleted, char* pUserName, int* pNumJobs, bool bMonitorJobStatus)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	ipp_t* pResponse = NULL;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	ipp_t* pRequest = ippNew();
	if (pRequest == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("GetJobList: unable to allocate memory for ipp request");
		return IPPLIB_MEM_ERROR;
	}

	memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
	pRequest->request.op.operation_id = IPP_GET_JOBS;
	pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET, "attributes-charset", NULL, charset);
	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE, "attributes-natural-language", NULL, language != NULL ? language : "C");
	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, IPP_uri);
//	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, HTTP_uri);
	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_NAME, "requesting-user-name", NULL, pUserName);
	ippAddStrings(pRequest, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, "requested-attributes", sizeof(jobDescription11) / sizeof(jobDescription11[0]), NULL, jobDescription11);

	if (bJobCompleted)
	{
		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, "which-jobs", NULL, "completed");
	}
	else
	{
		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, "which-jobs", NULL, "not-completed");
	}
//  "all" is not suported by KM	
//	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_KEYWORD, "which-jobs", NULL, "all");

//  Don't remember if this was not supported by KM "bMyJobsOnly" or I decided to get everything and filter
//  it in the CreateJobList function.  Don.
	bool bMyJobsOnlyForceFalse = false;
	ippAddBoolean(pRequest, IPP_TAG_OPERATION, "my-jobs", bMyJobsOnlyForceFalse);

	if ((pResponse = cupsDoRequest(http, pRequest, resource)) != NULL)
	{
		const char* pHttpField = NULL;
		if ((pHttpField = httpGetField(http, HTTP_FIELD_CONNECTION)) != NULL)
		{
			if (strcmpi(pHttpField, "close") == 0)
			{
				CLogUtils::LOG_UTILS_INFO("GetJobList: HTTP_FIELD_CONNECTION == close");
				do_reconnect = 1;
			}
		}
		else
		{
			CLogUtils::LOG_UTILS_ERROR("GetJobList: function httpGetField returned NULL");
			uiError = IPPLIB_ERROR;
		}

		if (pResponse->request.status.status_code > IPP_OK_CONFLICT)
		{
			CLogUtils::LOG_UTILS_EX(eERROR, "GetJobList: failed: %s", ippErrorString(pResponse->request.status.status_code));
			uiError = IPPLIB_ERROR;
		}
		else
		{
			uiError = CreateJobList(pJobList, pResponse, pNumJobs, bMyJobsOnly, bMonitorJobStatus);
		}

		// pRequest is deleted in cupsDoRequest
		ippDelete(pResponse);
	}
	else
	{
		CLogUtils::LOG_UTILS_ERROR("GetJobList: cupsDoRequest failed- pResponse == NULL.");
		uiError = IPPLIB_ERROR;
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Creates job list. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pJobList">				[in,out] If non-null, list of jobs. </param>
/// <param name="pResponse">			[in,out] If non-null, the response. </param>
/// <param name="pNumJobs">				[in,out] If non-null, number of jobs. </param>
/// <param name="bMyJobsOnly">			true to my jobs only. </param>
/// <param name="bMonitorJobStatus">	true to monitor job status. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::CreateJobList(CJobList *pJobList, ipp_t* pResponse, int* pNumJobs, bool bMyJobsOnly, bool bMonitorJobStatus)
{
	static int iJobNotFoundInCacheLogCount = -1;
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	ipp_attribute_t* attr = NULL;
	CDevicePrintJob* pDevicePrintJob = NULL;
	bool bSuspended = false;
	bool bJobInLocalCache = false;
	bool bPossibleFCJob = false;
	bool bSaveJob = false;
	bool bValidDeviceJobID = true;

	__time64_t tDateTime;
	struct tm tmLocalTime;
	int             id;			    // job-id
	int             priority;		// job-priority
	int             size;			// job-k-octets
	ipp_jstate_t	state;			// job-state
	time_t	        completed_time;	// time-at-completed
	time_t	        creation_time;	// time-at-creation
	time_t	        processing_time;// time-at-processing
	char*			dest;			// job-printer-uri
	char*			format;			// document-format
	char*			title;			// job-name
	char*			user;			// job-originating-user-name
	char*			joburi;			// job-uri
	int				copies;			// job-copies


	// Reduce the frequency of log messages for jobs from the engine that are not found in the device cache.
	// When the count is 0 the log messages will be generated below.
	if (iJobNotFoundInCacheLogCount < 12)
		iJobNotFoundInCacheLogCount++;
	else
		iJobNotFoundInCacheLogCount = 0;

	int iNumJobsInJobList = GetNumJobsInList(pResponse, m_strDeviceID);
	m_pFCIPPCommandsBase->SetNumJobsInJobList(iNumJobsInJobList);

	if (iNumJobsInJobList > 0)
	{
		for (attr=pResponse->attrs; attr!=NULL; attr=attr->next)
		{
			//Skip leading attributes until we hit a job...
			if (attr->group_tag == IPP_TAG_JOB)
			{
				pDevicePrintJob = new CDevicePrintJob(NULL);
				bJobInLocalCache = false;
				bPossibleFCJob = false;
				bSaveJob = false;
				bValidDeviceJobID = true;

				if (pDevicePrintJob)
				{
					id              = 0;
					copies			= 0;
					size            = 0;
					priority        = 50;
					state           = IPP_JOB_PENDING;
					user            = NULL;
					dest            = NULL;
					format          = "application/octet-stream";
					title           = NULL;
					creation_time   = 0;
					completed_time  = 0;
					processing_time = 0;
					joburi			= NULL;

					while ((attr != NULL) && (attr->group_tag == IPP_TAG_JOB))
					{
						if (strcmp(attr->name, "job-id") == 0 && attr->value_tag == IPP_TAG_INTEGER)
						{
							id = attr->values[0].integer;

							// the id here is the job list id not necessarily the id for getting job printing status
							pDevicePrintJob->m_strJLPQMID = FormatString("%d", id);

							if (!m_bAddIDToUserNameForJobMappingID)
							{
								pDevicePrintJob->m_strJLJobID = m_pDevicePrintJobCache->GetJLJobIDFromDeviceJobID(pDevicePrintJob->m_strJLPQMID);

								if (pDevicePrintJob->m_strJLJobID.empty())
									bValidDeviceJobID = false;
							}
						}
						else if (strcmp(attr->name, "copies") == 0 && attr->value_tag == IPP_TAG_INTEGER)
						{
							copies = attr->values[0].integer;
						}
						else if (strcmp(attr->name, "job-uri") == 0 && attr->value_tag == IPP_TAG_URI)
						{
							joburi = attr->values[0].string.text;
						}
						else if (strcmp(attr->name, "job-state") == 0 && attr->value_tag == IPP_TAG_ENUM)
						{
							state = (ipp_jstate_t)attr->values[0].integer;
						}
						else if (strcmp(attr->name, "job-priority") == 0 && attr->value_tag == IPP_TAG_INTEGER)
						{
							priority = attr->values[0].integer;
						}
						else if (strcmp(attr->name, "job-k-octets") == 0 && attr->value_tag == IPP_TAG_INTEGER)
						{
							size = attr->values[0].integer;
						}
						else if (strcmp(attr->name, "time-at-completed") == 0 && attr->value_tag == IPP_TAG_INTEGER)
						{
							completed_time = attr->values[0].integer;
						}
						else if (strcmp(attr->name, "time-at-creation") == 0 && attr->value_tag == IPP_TAG_INTEGER)
						{
							creation_time = attr->values[0].integer;
						}
						else if (strcmp(attr->name, "time-at-processing") == 0 && attr->value_tag == IPP_TAG_INTEGER)
						{
							processing_time = attr->values[0].integer;
						}
						else if (strcmp(attr->name, "job-printer-uri") == 0 && attr->value_tag == IPP_TAG_URI)
						{
							if ((dest = (char* )strrchr(attr->values[0].string.text, '/')) != NULL)
							{
								dest++;
							}
						}
						else if (strcmp(attr->name, "job-originating-user-name") == 0 && attr->value_tag == IPP_TAG_NAME)
						{
							user = attr->values[0].string.text;
							string strUser = user;

							if (strUser != "PRINT")
							{
								pDevicePrintJob->m_strJobUserName = strUser;

								if (m_bAddIDToUserNameForJobMappingID)
								{
									int iIndex = (int)strUser.find_last_of('_');
									if (iIndex != string::npos)
									{
										pDevicePrintJob->m_strActualUserNameSentToDevice = strUser;
										pDevicePrintJob->m_strJobUserName = strUser.substr(0, iIndex);
										pDevicePrintJob->m_strJLJobID = strUser.substr(iIndex+1);

										if (!pDevicePrintJob->m_strJLJobID.empty())
											pDevicePrintJob->m_uiJobPrintNumber = atoi(pDevicePrintJob->m_strJLJobID.c_str());
									}
								}
							}
						}
						else if (strcmp(attr->name, "document-format") == 0 && attr->value_tag == IPP_TAG_MIMETYPE)
						{
							format = attr->values[0].string.text;
						}
						else if ((strcmp(attr->name, "job-name") == 0) &&
							((attr->value_tag == IPP_TAG_TEXT) ||
							 (attr->value_tag == IPP_TAG_NAME) ||
							 (attr->value_tag == IPP_TAG_TEXTLANG) ||
							 (attr->value_tag == IPP_TAG_NAMELANG)))
						{
							title = attr->values[0].string.text;
						}

						attr = attr->next;
					}

					if (NULL != title)
					{
						pDevicePrintJob->m_strJobName = title;

						if (m_bUseJobNameToGetJobID)
						{
							string strTitle = title;
							int iIndex = (int)strTitle.find_last_of('_');
							if (iIndex != string::npos)
							{
								pDevicePrintJob->m_strJobName = strTitle.substr(0, iIndex);
								pDevicePrintJob->m_strJLJobID = strTitle.substr(iIndex+1);

								if (!pDevicePrintJob->m_strJLJobID.empty())
									pDevicePrintJob->m_uiJobPrintNumber = atoi(pDevicePrintJob->m_strJLJobID.c_str());
							}
						}
					}

					if (!bValidDeviceJobID && pDevicePrintJob->m_strJLJobID.empty())
					{
						// To keep from filling up the log we only want to do this perodically
						if (iJobNotFoundInCacheLogCount == 0)
							CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::CreateJobList: The Device Job ID %d, for job %s, was not found in the DevicePrintJobCache.", id, title);
					}

					pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_NOT_VERIFIED;

					bJobInLocalCache = IsJobInLocalCache(pDevicePrintJob);
					if (bJobInLocalCache)
						bPossibleFCJob = true;
					else
						bPossibleFCJob = IsPossibleFCJob(pDevicePrintJob);

					if (bJobInLocalCache || 
						(m_pFCIPPCommandsBase->IsDeviceErrorRecoveryEnabled() && bPossibleFCJob && m_pFCIPPCommandsBase->DoesDeviceSupportErrorRecovery()))
					{
						switch ((IPPLIB_JOBSTATE)state)
						{
							case IPP_JOB_STATE_PENDING:
								pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_WAITING_TO_PRINT;
								pDevicePrintJob->m_iCurrJobListStatusMode = JOBLIST_STATUS_MODE_WAITING_TO_PRINT;
								if (bMonitorJobStatus)
									UpdateJobBase(pDevicePrintJob);
								break;
							case IPP_JOB_STATE_PENDING_HELD:
								pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_HOLD;
								pDevicePrintJob->m_iCurrJobListStatusMode = JOBLIST_STATUS_MODE_HOLD;
								if (bMonitorJobStatus)
									UpdateJobBase(pDevicePrintJob);
								break;
							case IPP_JOB_STATE_PROCESSING:
								pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_PRINTING;
								pDevicePrintJob->m_iCurrJobListStatusMode = JOBLIST_STATUS_MODE_PRINTING;
								if (bMonitorJobStatus)
									CheckForJobProgress(pDevicePrintJob);
								break;
							case IPP_JOB_STATE_STOPPED:
								pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_SUSPENDED;
								pDevicePrintJob->m_iCurrJobListStatusMode = JOBLIST_STATUS_MODE_SUSPENDED;
								bSuspended = true;
								if (bMonitorJobStatus)
									CheckForJobProgress(pDevicePrintJob);
								break;
							case IPP_JOB_STATE_CANCELLED:
								pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_CANCELLED;
								pDevicePrintJob->m_iCurrJobListStatusMode = JOBLIST_STATUS_MODE_CANCELLED;
								if (bMonitorJobStatus)
									CheckForJobProgress(pDevicePrintJob);
								break;
							case IPP_JOB_STATE_ABORTED:
								pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_ABORTED;
								pDevicePrintJob->m_iCurrJobListStatusMode = JOBLIST_STATUS_MODE_ABORTED;
								if (bMonitorJobStatus)
									CheckForJobProgress(pDevicePrintJob);
								break;
							case IPP_JOB_STATE_COMPLETED:
								pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_DONE_PRINTING;
								pDevicePrintJob->m_iCurrJobListStatusMode = JOBLIST_STATUS_MODE_DONE_PRINTING;
								pDevicePrintJob->m_iPercentageComplete = 100;
								pDevicePrintJob->SetCurrentTimeStamp(JOBLIST_STATUS_MODE_DONE_PRINTING);
								if (bMonitorJobStatus)
									CheckForJobProgress(pDevicePrintJob);
								break;
							default:
								CLogUtils::LOG_UTILS_ERROR("CFCIPPConnectionObjectBase::CreateJobList: Undefined (IPPLIB_JOBSTATE)state.");
								break;
						}

						bSaveJob = true;
					}

					GetJobStatusStringFromJobStatusMode(pDevicePrintJob->m_iJobStatusMode, pDevicePrintJob->m_strJobStatus);

					if (pDevicePrintJob->m_strJobName.empty())
						pDevicePrintJob->m_strJobName = "untitled";

					if (pDevicePrintJob->m_strJobUserName.empty())
						pDevicePrintJob->m_strJobUserName = "unknown";

					if (bMyJobsOnly && !bSaveJob)
					{
						delete pDevicePrintJob;
						pDevicePrintJob = NULL;
					}
					else
						pJobList->push_back(pDevicePrintJob);

				}
				else
				{
					CLogUtils::LOG_UTILS_ERROR("CFCIPPConnectionObjectBase::CreateJobList: Cannot Allocate CDevicePrintJob.");
					uiError = IPPLIB_MEM_ERROR;
					break;
				}
			}

			if (attr == NULL)
			{
				break;
			}
		}
	}

	AddDevicePossiblePrintedJobsToJobList(pJobList, bMonitorJobStatus);
	AddDevicePossibleLostJobsToJobList(pJobList, bMonitorJobStatus);

	m_pFCIPPCommandsBase->SetJobsSuspended(bSuspended);
	*pNumJobs = (int)pJobList->size();

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Query if 'pDevicePrintJob' is job in local cache. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pDevicePrintJob">	[in,out] If non-null, the job base. </param>
///
/// <returns>	true if job in local cache, false if not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

bool CFCIPPConnectionObjectBase::IsJobInLocalCache(CDevicePrintJob* pDevicePrintJob)
{
	bool bJobInLocalCache = false;

	if (!pDevicePrintJob->m_strJLJobID.empty())
	{
		CDevicePrintJob* pReferenceDevicePrintJob = m_pDevicePrintJobCache->GetDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
		if (pReferenceDevicePrintJob)
		{
			bJobInLocalCache = true;

			pDevicePrintJob->m_pParentJob = pReferenceDevicePrintJob->m_pParentJob;
			pDevicePrintJob->m_pSubJob = pReferenceDevicePrintJob->m_pSubJob;
			pDevicePrintJob->m_pDeviceAccountingBase = pReferenceDevicePrintJob->m_pDeviceAccountingBase;
			pDevicePrintJob->m_bJobVerifiedOnDevice = true;
			pDevicePrintJob->m_uiMasterJobPrintNumber = pReferenceDevicePrintJob->m_uiMasterJobPrintNumber;
			pDevicePrintJob->m_uiDeviceClickTotalPagesPrinted = pReferenceDevicePrintJob->m_uiDeviceClickTotalPagesPrinted;
			pDevicePrintJob->m_uiDeviceClickTotalSheetsPrinted = pReferenceDevicePrintJob->m_uiDeviceClickTotalSheetsPrinted;
			pDevicePrintJob->m_uiDeviceClickTotalCopiesPrinted = pReferenceDevicePrintJob->m_uiDeviceClickTotalCopiesPrinted;
			pDevicePrintJob->m_uiDeviceClickTotalInsertSheetsPrinted = pReferenceDevicePrintJob->m_uiDeviceClickTotalInsertSheetsPrinted;
			pDevicePrintJob->m_uiTotalPagesExpected = pReferenceDevicePrintJob->m_uiTotalPagesExpected;
			pDevicePrintJob->m_uiTotalSheetsExpected = pReferenceDevicePrintJob->m_uiTotalSheetsExpected;

			if (pDevicePrintJob->m_strActualUserNameSentToDevice.empty())
				pDevicePrintJob->m_strActualUserNameSentToDevice = pReferenceDevicePrintJob->m_strActualUserNameSentToDevice;

			if (pDevicePrintJob->m_strActualUserNameSentToDevice != pReferenceDevicePrintJob->m_strActualUserNameSentToDevice)
			{
				pDevicePrintJob->m_strActualUserNameSentToDevice = pReferenceDevicePrintJob->m_strActualUserNameSentToDevice;
				CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::IsJobInLocalCache: ActualUserNameSentToDevice does not match Job ID %s for job %s", pDevicePrintJob->m_strJLJobID.c_str(), pDevicePrintJob->m_strJobName.c_str());
			}

			// If job was cancelled and it contained a job with ID 0 then we don't want to add it to our job list unless it
			// was never verified on the device because we need to run at least 1 cycle before removing it.
			if (pReferenceDevicePrintJob->m_bJobCancelledByFieryCentral && pReferenceDevicePrintJob->m_bJobVerifiedOnDevice)
			{
				if (pReferenceDevicePrintJob->m_bJobContainsProjectedJobID || pReferenceDevicePrintJob->m_bRemoveCancelledJobFromJobList)
					bJobInLocalCache = false;

				++pReferenceDevicePrintJob->m_iJobListCountSinceCancelledByFieryCentral;
			}

			if (pReferenceDevicePrintJob->m_bJobVerifiedOnDevice && pReferenceDevicePrintJob->m_bRemoveJobFromJobList)
				bJobInLocalCache = false;

			// the code "pReferenceDevicePrintJob->m_bJobVerifiedOnDevice = true;" must be after the 
			// update of "pDevicePrintJob" above.
			pReferenceDevicePrintJob->m_bJobVerifiedOnDevice = true;
			m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
		}
	}

	return bJobInLocalCache;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Query if 'pDevicePrintJob' is possible fc job. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pDevicePrintJob">	[in,out] If non-null, the job base. </param>
///
/// <returns>	true if possible fc job, false if not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

bool CFCIPPConnectionObjectBase::IsPossibleFCJob(CDevicePrintJob* pDevicePrintJob)
{
	bool bPossibleFCJob = false;

	if (!pDevicePrintJob->m_strJLJobID.empty())
		bPossibleFCJob = true;

	return bPossibleFCJob;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Updates the job base. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pDevicePrintJob">	[in,out] If non-null, the job base. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::UpdateJobBase(CDevicePrintJob* pDevicePrintJob)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (!pDevicePrintJob->m_strJLJobID.empty())
	{
		CDevicePrintJob* pReferenceDevicePrintJob = m_pDevicePrintJobCache->GetDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
		if (pReferenceDevicePrintJob)
		{
			if (m_pFCIPPCommandsBase->DoesDeviceSupportPagesPrinted())
			{
				bool bUpdatePrintingTimeStamp = false;
				if (pReferenceDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_START)
					CheckForJobProgress(pDevicePrintJob, bUpdatePrintingTimeStamp);
				
				if (pReferenceDevicePrintJob->m_bJobRequiresFakeSuspend && (m_iCheckJobProgessPrintingState == CHECK_JOB_PROGESS_BEFORE_PRINTING_STATE))
				{
					pReferenceDevicePrintJob->m_bJobRequiresFakeSuspend = false;
					m_pFCIPPCommandsBase->DecrementFakeJobsSuspendedOnDevice();
				}
			}

			int iJobID = atoi(pReferenceDevicePrintJob->m_strJLPQMID.c_str());
			if (m_bIPPJobListJobIDIsValid && (pReferenceDevicePrintJob->m_strJLPQMID.empty() || (iJobID < 1)))
			{
				pReferenceDevicePrintJob->m_strJLPQMID = pDevicePrintJob->m_strJLPQMID;
				iJobID = atoi(pReferenceDevicePrintJob->m_strJLPQMID.c_str());
			}
			else
				pDevicePrintJob->m_strJLPQMID = pReferenceDevicePrintJob->m_strJLPQMID;

			pReferenceDevicePrintJob->m_iJobStatusMode = pDevicePrintJob->m_iJobStatusMode;
			pReferenceDevicePrintJob->m_iCurrJobListStatusMode = pDevicePrintJob->m_iCurrJobListStatusMode;
			GetJobStatusStringFromJobStatusMode(pReferenceDevicePrintJob->m_iJobStatusMode, pReferenceDevicePrintJob->m_strJobStatus);
			m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Check for job progress. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pDevicePrintJob">				   	[in,out] If non-null, the job base. </param>
/// <param name="bUpdatePrintingTimeStamp">	true to update printing time stamp. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::CheckForJobProgress(CDevicePrintJob* pDevicePrintJob, bool bUpdatePrintingTimeStamp)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (!pDevicePrintJob->m_strJLJobID.empty())
	{
		CDevicePrintJob* pReferenceDevicePrintJob = m_pDevicePrintJobCache->GetDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
		if (pReferenceDevicePrintJob)
		{
			int iJobID = atoi(pReferenceDevicePrintJob->m_strJLPQMID.c_str());
			if (m_bIPPJobListJobIDIsValid && (pReferenceDevicePrintJob->m_strJLPQMID.empty() || (iJobID < 1)))
			{
				pReferenceDevicePrintJob->m_strJLPQMID = pDevicePrintJob->m_strJLPQMID;
				iJobID = atoi(pReferenceDevicePrintJob->m_strJLPQMID.c_str());
			}
			else
				pDevicePrintJob->m_strJLPQMID = pReferenceDevicePrintJob->m_strJLPQMID;

			pReferenceDevicePrintJob->m_iJobStatusMode = pDevicePrintJob->m_iJobStatusMode;
			pReferenceDevicePrintJob->m_iCurrJobListStatusMode = pDevicePrintJob->m_iCurrJobListStatusMode;
			GetJobStatusStringFromJobStatusMode(pReferenceDevicePrintJob->m_iJobStatusMode, pReferenceDevicePrintJob->m_strJobStatus);

			if (bUpdatePrintingTimeStamp)
				pDevicePrintJob->m_strTimeStampPrinting = CStringUtils::GetCurrentTimeStamp();

			if (m_pFCIPPCommandsBase->DoesDeviceSupportPagesPrinted())
			{
				if (!pReferenceDevicePrintJob->m_strJLPQMID.empty() && (iJobID > 0))
				{
					CFCIPPJobObject FCIPPJobObject(m_pFCIPPCommandsBase, (CFCIPPConnectionObject*)this, pReferenceDevicePrintJob);
					FCIPPJobObject.jobID = iJobID;

					if (pReferenceDevicePrintJob->m_bJobContainsProjectedJobID)
					{
						if (m_pFCIPPCommandsBase->DoesDeviceIPPRecoverFromBadJobID())
						{
							bool bForwardFirst = true;
							pDevicePrintJob->m_iEventType = pReferenceDevicePrintJob->m_iEventType;

							if (bUpdatePrintingTimeStamp)
								CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::CheckForJobProgress: Processing Job check for projected ID = %d, job ID %s, job name %s, user name %s,",
								FCIPPJobObject.jobID, pDevicePrintJob->m_strJLJobID.c_str(), pDevicePrintJob->m_strJobName.c_str(), pDevicePrintJob->m_strJobUserName.c_str());
							else
								CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::CheckForJobProgress: Update Job check for projected ID = %d, job ID %s, job name %s, user name %s,",
								FCIPPJobObject.jobID, pDevicePrintJob->m_strJLJobID.c_str(), pDevicePrintJob->m_strJobName.c_str(), pDevicePrintJob->m_strJobUserName.c_str());

							uiError = GetJobProgress(&FCIPPJobObject, pDevicePrintJob, false);

//							if ((pDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_START) ||
//								(pDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_END))
							if (pReferenceDevicePrintJob->m_bJobContainsProjectedJobID)
							{
								intIntMap JobIDMap;
								JobIDMap.insert(intIntMap::value_type(FCIPPJobObject.jobID, FCIPPJobObject.jobID));
								uiError = GetJobsJLPQMID(&FCIPPJobObject, &JobIDMap, pReferenceDevicePrintJob, pDevicePrintJob, bForwardFirst);

								if ((pDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_START) ||
									(pDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_END))
									uiError = GetJobsJLPQMID(&FCIPPJobObject, &JobIDMap, pReferenceDevicePrintJob, pDevicePrintJob, !bForwardFirst);

								if (pDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_START)
									pDevicePrintJob->m_iEventType = HARMONY_JOBEVENTTYPE_REDIRECT_END;

								pReferenceDevicePrintJob->m_iEventType = pDevicePrintJob->m_iEventType;
								m_pFCIPPCommandsBase->SetIPPJobMappedEventHandle();
								JobIDMap.clear();
								CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::CheckForJobProgress: GetJobProgress with Job List ID %s, Job ID %d for job %s failed to auto map", pDevicePrintJob->m_strJLJobID.c_str(), FCIPPJobObject.jobID, pDevicePrintJob->m_strJobName.c_str());
							}
							else
							{
								pReferenceDevicePrintJob->m_iEventType = HARMONY_JOBEVENTTYPE_INITIAL;
								m_pFCIPPCommandsBase->SetIPPJobMappedEventHandle();
							}
						}
						else
						{
							pDevicePrintJob->m_iEventType = HARMONY_JOBEVENTTYPE_REDIRECT_END;
							pReferenceDevicePrintJob->m_iEventType = pDevicePrintJob->m_iEventType;
							m_pFCIPPCommandsBase->SetIPPJobMappedEventHandle();
						}

						string strProjectedRemotePQMID = pReferenceDevicePrintJob->m_strProjectedRemotePQMID;
						if (!strProjectedRemotePQMID.empty())
						{
							int iWaitCounter = 0;

							while (!m_pFCIPPCommandsBase->IsShuttingDown() && !strProjectedRemotePQMID.empty() && (iWaitCounter<6))
							{
								strProjectedRemotePQMID = pReferenceDevicePrintJob->m_strProjectedRemotePQMID;
								++iWaitCounter;
								Sleep(1000);
							}

							if (!strProjectedRemotePQMID.empty())
								CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::CheckForJobProgress: m_strProjectedRemotePQMID still not empty for Job List ID %s, Job ID %d for job %s", pDevicePrintJob->m_strJLJobID.c_str(), FCIPPJobObject.jobID, pDevicePrintJob->m_strJobName.c_str());
						}
					}
					else
						uiError = GetJobProgress(&FCIPPJobObject, pDevicePrintJob, false);

					if (uiError != IPPLIB_SUCCESS)
						CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::CheckForJobProgress: GetJobProgress failed with Job List ID %s, Job ID %d for job %s", pDevicePrintJob->m_strJLJobID.c_str(), FCIPPJobObject.jobID, pDevicePrintJob->m_strJobName.c_str());
				}

				if (bUpdatePrintingTimeStamp && pReferenceDevicePrintJob->m_bJobRequiresFakeSuspend && (m_iCheckJobProgessPrintingState == CHECK_JOB_PROGESS_DURING_PRINTING_STATE))
				{
					pReferenceDevicePrintJob->m_bJobRequiresFakeSuspend = false;
					m_pFCIPPCommandsBase->DecrementFakeJobsSuspendedOnDevice();
				}
			}

			m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(pDevicePrintJob->m_strJLJobID);
		}
	}

	return uiError;
}

/*
IPPLIB_RESULT CFCIPPConnectionObjectBase::CloseConnection()
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	if (http)
	{
		if (http->fd)
		{
			#ifdef WIN32
				closesocket(http->fd);
			#else
				close(http->fd);
			#endif // WIN32
			http->fd = 0;
		}

		//cupsLangFlush() is causing a crash for us when we import 196 small jobs for a KM via a Hot Folder. We
		//looked into this and the corresponding cupsLangGet() (see ippapi.c) and determined we don't need these.
		free(http);
		http = NULL;
	}

	return uiError;
}
*/

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets printer state. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pState"> 	[in,out] If non-null, the state. </param>
/// <param name="pReason">	[in,out] If non-null, the reason. </param>
/// <param name="pMsg">   	[in,out] If non-null, the message. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::GetPrinterState(IPPPRINTERSTATE *pState, IPPPRINTERSTATEREASONSTRUCT *pReason, PRTIPPDETAILEDMSG *pMsg)
{
	IPPLIB_RESULT   uiError = IPPLIB_SUCCESS;
	ipp_t           *pResponse = NULL;
	ipp_attribute_t *attr = NULL;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	ipp_t* pRequest = ippNew();
	if (pRequest == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("GetPrinterAttribute: unable to allocate memory for ipp request");
		return IPPLIB_MEM_ERROR;
	}

	memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
	pRequest->request.op.operation_id = IPP_GET_PRINTER_ATTRIBUTES;
	pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET, "attributes-charset", NULL, charset);
	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE,
		"attributes-natural-language", NULL,
		language != NULL ? language : "C");

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, HTTP_uri);
	ippAddStrings(pRequest, IPP_TAG_OPERATION, IPP_TAG_KEYWORD,
		"requested-attributes", sizeof(gpa_state_requested) / sizeof(gpa_state_requested[0]),
		NULL, gpa_state_requested);

	if ((pResponse = cupsDoRequest(http, pRequest, resource)) != NULL)
	{
		const char* pHttpField = NULL;
		if ((pHttpField = httpGetField(http, HTTP_FIELD_CONNECTION)) != NULL)
		{
			if (strcmpi(pHttpField, "close") == 0)
			{
				CLogUtils::LOG_UTILS_INFO("GetPrinterState: HTTP_FIELD_CONNECTION == close");
				do_reconnect = 1;
			}
		}
		else
		{
			CLogUtils::LOG_UTILS_ERROR("GetPrinterState: function httpGetField return NULL");
			uiError = IPPLIB_ERROR;
		}

		if (pResponse->request.status.status_code > IPP_OK_CONFLICT)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "GetPrinterState: failed: %s", ippErrorString(pResponse->request.status.status_code));
			uiError = IPPLIB_ERROR;
		}
		else
		{
			if (pState)
			{
				if ((attr = ippFindAttribute(pResponse, "printer-state",
					IPP_TAG_ENUM)) != NULL)
				{
					SetIPPPrinterState(attr, pState);
				}
				else
				{
					//If printer-state is not returned.
					//Assume it is stopped
					*pState = IPP_PRT_STATE_STOPPED;
				}
			}

			if (pReason)
			{
				pReason->nCount = 0;

				if ((attr = ippFindAttribute(pResponse, "printer-state-reasons",
					IPP_TAG_KEYWORD)) != NULL)
				{
					SetIPPPrinterStateReason(attr, pReason);
				}
				else
				{
					// If printer-state-reasons is not returned.
					pReason->Reasons[0] = PRT_STATE_REASON_NONE;
					pReason->nCount = 1;
				}

				if ((attr = ippFindAttribute(pResponse, "printer-detailed-status-messages",   
					IPP_TAG_TEXT)) != NULL)
				{
					if (attr->num_values > 0 && pMsg)
					{
						*pMsg = CreateDetailedMsgStruct(attr->num_values);
						if (*pMsg)
						{
							for (int i=0;i<attr->num_values;i++)
							{
								(*pMsg)->msg[i] = strdup(attr->values[i].string.text);
								(*pMsg)->count++;
								EnumeratePrinterStateReasonFromMsg(attr->values[i].string.text, pReason);
							}						    
						}
					}
				}

				if ((attr = ippFindAttribute(pResponse, "printer-state-message", 
					IPP_TAG_TEXT)) != NULL)
				{
					// set printer state message

					if (pMsg && !*pMsg)
					{
						*pMsg = CreateDetailedMsgStruct(1);
					}

					if ((*pMsg) && (attr->values[0].string.text != NULL))
					{
						if (0 == (*pMsg)->count)
						{
							(*pMsg)->msg[0] = strdup(attr->values[0].string.text);
							(*pMsg)->count = 1;
						}
						(*pMsg)->state_msg = strdup(attr->values[0].string.text);
					}
				}
			}
		}

		// pRequest is deleted in cupsDoRequest
		ippDelete(pResponse);
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets printer information. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="prtInfo">	[in,out] If non-null, information describing the prt. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::GetPrinterInformation(IPPPRINTERINFO *prtInfo)
{
	IPPLIB_RESULT   uiError = IPPLIB_SUCCESS;
	ipp_t           *pResponse = NULL;
	ipp_attribute_t	*attr = NULL;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	ipp_t* pRequest = ippNew();
	if (pRequest == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("GetPrinterInformation: unable to allocate memory for ipp request");
		return IPPLIB_MEM_ERROR;
	}

	memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
	pRequest->request.op.operation_id = IPP_GET_PRINTER_ATTRIBUTES;
	pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET, "attributes-charset", NULL, charset);
	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE,
		"attributes-natural-language", NULL,
		language != NULL ? language : "C");

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, HTTP_uri);
	ippAddStrings(pRequest, IPP_TAG_OPERATION, IPP_TAG_KEYWORD,
		"requested-attributes", sizeof(gpa_info_requested) / sizeof(gpa_info_requested[0]),
		NULL, gpa_info_requested);

	if ((pResponse = cupsDoRequest(http, pRequest, resource)) != NULL)
	{
		const char* pHttpField = NULL;
		if ((pHttpField = httpGetField(http, HTTP_FIELD_CONNECTION)) != NULL)
		{
			if (strcmpi(pHttpField, "close") == 0)
			{
				CLogUtils::LOG_UTILS_INFO("GetPrinterInformation: HTTP_FIELD_CONNECTION == close");
				do_reconnect = 1;
			}
		}
		else
		{
			CLogUtils::LOG_UTILS_ERROR("GetPrinterInformation: function httpGetField return NULL");
			uiError = IPPLIB_ERROR;
		}

		if (pResponse->request.status.status_code > IPP_OK_CONFLICT)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "GetPrinterInformation: failed: %s", ippErrorString(pResponse->request.status.status_code));
			uiError = IPPLIB_ERROR;
		}
		else
		{
			if ((attr = ippFindAttribute(pResponse, "printer-make-and-model",
				IPP_TAG_TEXT)) != NULL)
			{
				strncpy(prtInfo->model, attr->values[0].string.text, sizeof(prtInfo->model)-1);
				prtInfo->model[sizeof(prtInfo->model)-1] = 0;
			}
			else
			{
				prtInfo->model[0] = '\0';
				CLogUtils::LOG_UTILS_DEBUG("GetPrinterInformation: Attr not found job-uri");
			}

			if ((attr = ippFindAttribute(pResponse, "printer-info",
				IPP_TAG_TEXT)) != NULL)
			{
				strncpy(prtInfo->info, attr->values[0].string.text, sizeof(prtInfo->info)-1);
				prtInfo->info[sizeof(prtInfo->info)-1] = 0;
			}
			else
			{
				prtInfo->info[0] = '\0';
				CLogUtils::LOG_UTILS_DEBUG("GetPrinterInformation: Attr not found printer-info");
			}

			if ((attr = ippFindAttribute(pResponse, "printer-location",
				IPP_TAG_TEXT)) != NULL)
			{
				strncpy(prtInfo->location, attr->values[0].string.text, sizeof(prtInfo->location)-1);
				prtInfo->location[sizeof(prtInfo->location)-1] = 0;
			}
			else
			{
				prtInfo->location[0] = '\0';
				CLogUtils::LOG_UTILS_DEBUG("GetPrinterInformation: Attr not found printer-location");
			}

			if ((attr = ippFindAttribute(pResponse, "printer-name",
				IPP_TAG_NAME)) != NULL)
			{
				strncpy(prtInfo->name, attr->values[0].string.text, sizeof(prtInfo->name)-1);
				prtInfo->name[sizeof(prtInfo->name)-1] = 0;
			}
			else
			{
				prtInfo->name[0] = '\0';
				CLogUtils::LOG_UTILS_DEBUG("GetPrinterInformation: Attr not found printer-name");
			}
		}

		ippDelete(pResponse);
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		do_reconnect = 1;
	}

	return uiError;
}


////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets job progress. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">  	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pDevicePrintJob">				[in,out] If non-null, the job base. </param>
/// <param name="bFinalStatusCheck">	true to final status check. </param>
///
/// <returns>	The job progress ex. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::GetJobProgress(CFCIPPJobObject* pFCIPPJobObject, CDevicePrintJob* pDevicePrintJob, bool bFinalStatusCheck)
{
	IPPLIB_RESULT   uiError = IPPLIB_SUCCESS;
	ipp_t           *pResponse = NULL;
	ipp_attribute_t *attr = NULL;
	IPPJOBINFO_2 JobInfo;
	PTRIPPJOBINFO_2 pJobInfo = &JobInfo;

	if ((pFCIPPJobObject == NULL) || !ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_ERROR("CFCIPPConnectionObjectBase::GetJobProgress - ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject->jobID == 0)
	{
		CLogUtils::LOG_UTILS_ERROR("CFCIPPConnectionObjectBase::GetJobProgress - jobID = 0.");
		return IPPLIB_INVALID_PARAM;
	}

	if (!bFinalStatusCheck && m_bGetJobProgressOnceWhenJobFinished)
	{
		// Only need to ask the device on the Final Status Check.
		// Some engines don't provide progress information while the job is printing.
		return uiError;
	}

	ipp_t* pRequest = ippNew();
	if (pRequest == NULL)
	{
		CLogUtils::LOG_UTILS_ERROR("CFCIPPConnectionObjectBase::GetJobProgress - GetPrinterAttribute: unable to allocate memory for ipp request");
		return IPPLIB_MEM_ERROR;
	}

	memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
	pRequest->request.op.operation_id = IPP_GET_JOB_ATTRIBUTES;
	pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET, "attributes-charset", NULL, charset);
	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE,
		"attributes-natural-language", NULL,
		language != NULL ? language : "C");

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, HTTP_uri);
	ippAddInteger(pRequest, IPP_TAG_OPERATION, IPP_TAG_INTEGER, "job-id", pFCIPPJobObject->jobID);
	ippAddStrings(pRequest, IPP_TAG_OPERATION, IPP_TAG_KEYWORD,
		"requested-attributes", 
		sizeof(gja_requested) / sizeof(gja_requested[0]),
		NULL, gja_requested);

	if ((pResponse = cupsDoRequest(http, pRequest, resource)) != NULL)
	{
		const char* pHttpField = NULL;
		if ((pHttpField = httpGetField(http, HTTP_FIELD_CONNECTION)) != NULL)
		{
			if (strcmpi(pHttpField, "close") == 0)
			{
				CLogUtils::LOG_UTILS_INFO("GetJobProgress: HTTP_FIELD_CONNECTION == close");
				do_reconnect = 1;
			}
		}
		else
		{
			CLogUtils::LOG_UTILS_ERROR("CFCIPPConnectionObjectBase::GetJobProgress: function httpGetField return NULL");
			uiError = IPPLIB_ERROR;
		}

		if (pResponse->request.status.status_code > IPP_OK_CONFLICT)
		{
			if (bFinalStatusCheck)
				CLogUtils::LOG_UTILS_EX(eERROR, "CFCIPPConnectionObjectBase::GetJobProgress: Job final status check failed: %s, IPP job object ID: %d, user-name: %s, job: %s", ippErrorString(pResponse->request.status.status_code), pFCIPPJobObject->jobID, pDevicePrintJob->m_strActualUserNameSentToDevice.c_str(), pDevicePrintJob->m_strJobName.c_str());
			else
				CLogUtils::LOG_UTILS_EX(eERROR, "CFCIPPConnectionObjectBase::GetJobProgress: Job progress status check failed: %s, IPP job object ID: %d, user-name: %s, job: %s", ippErrorString(pResponse->request.status.status_code), pFCIPPJobObject->jobID, pDevicePrintJob->m_strActualUserNameSentToDevice.c_str(), pDevicePrintJob->m_strJobName.c_str());

			uiError = IPPLIB_ERROR;
		}
		else
		{
			if ((attr = ippFindAttribute(pResponse, "job-id", 
				IPP_TAG_INTEGER)) != NULL)
			{
				int jobID =  attr->values[0].integer;
			}
			else
			{
				CLogUtils::LOG_UTILS_TRACE("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found job-id");
			}

			if ((attr = ippFindAttribute(pResponse, "job-uri", IPP_TAG_URI)) != NULL)
			{
				strncpy(pJobInfo->jobUrl, attr->values[0].string.text, 
					sizeof(pJobInfo->jobUrl)-1);
				pJobInfo->jobUrl[sizeof(pJobInfo->jobUrl)-1] = 0;
			}
			else
			{
				CLogUtils::LOG_UTILS_TRACE("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found job-uri");
			}

			if ((attr = ippFindAttribute(pResponse, "job-name", IPP_TAG_NAME)) != NULL)
			{
				strncpy(pJobInfo->jobName, attr->values[0].string.text, sizeof(pJobInfo->jobName)-1);
				pJobInfo->jobName[sizeof(pJobInfo->jobName)-1] = 0;
			}
			else
			{
				CLogUtils::LOG_UTILS_TRACE("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found job-name");
			}

			if ((pDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_START) ||
				(pDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_END))
			{
				if ((attr = ippFindAttribute(pResponse, "job-originating-user-name", IPP_TAG_NAME)) != NULL)
				{
					string strUser = attr->values[0].string.text;

					if (!strUser.empty())
					{
						if (pDevicePrintJob->m_strActualUserNameSentToDevice == strUser)
						{
							pDevicePrintJob->m_iEventType = HARMONY_JOBEVENTTYPE_INITIAL;
							CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::GetJobProgress: GetJobProgress with Job List ID: %s, Job ID: %d for job: %s, user: %s  correctly auto mapped", pDevicePrintJob->m_strJLJobID.c_str(), pFCIPPJobObject->jobID, pDevicePrintJob->m_strJobName.c_str(), strUser.c_str());
						}
						else
						{
							CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::GetJobProgress: IPP job object ID: %d, with job-originating-user-name: %s versus SubJob projected id: %s and user-name: %s", pFCIPPJobObject->jobID, strUser.c_str(), pDevicePrintJob->m_strJLJobID.c_str(), pDevicePrintJob->m_strActualUserNameSentToDevice.c_str());
						}
					}
							
					CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::GetJobProgress: IPP job-originating-user-name: %s versus SubJob user-name: %s", strUser.c_str(), pDevicePrintJob->m_strActualUserNameSentToDevice.c_str());
				}
				else
				{
					CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found job-originating-user-name");
				}
			}

			if ((attr = ippFindAttribute(pResponse, "job-state", IPP_TAG_ENUM)) != NULL)
			{
				if (bFinalStatusCheck)
				{
					SetIPPJobState(attr, &pJobInfo->state);
					switch (pJobInfo->state)
					{
						case IPP_JOB_STATE_PENDING:
							pFCIPPJobObject->jobState = JOBLIST_STATUS_MODE_WAITING_TO_PRINT;
							break;
						case IPP_JOB_STATE_PENDING_HELD:
							pFCIPPJobObject->jobState = JOBLIST_STATUS_MODE_HOLD;
							break;
						case IPP_JOB_STATE_PROCESSING:
							pFCIPPJobObject->jobState = JOBLIST_STATUS_MODE_PRINTING;
							break;
						case IPP_JOB_STATE_STOPPED:
							pFCIPPJobObject->jobState = JOBLIST_STATUS_MODE_SUSPENDED;
							break;
						case IPP_JOB_STATE_CANCELLED:
						case IPP_JOB_STATE_ABORTED:
							pFCIPPJobObject->jobState = JOBLIST_STATUS_MODE_CANCELLED;
							pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_CANCELLED;
							GetJobStatusStringFromJobStatusMode(pDevicePrintJob->m_iJobStatusMode, pDevicePrintJob->m_strJobStatus);
							CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::GetJobProgress: Job %s Cancelled Detected", pDevicePrintJob->m_strJobName.c_str());
							break;
						case IPP_JOB_STATE_COMPLETED:
							pFCIPPJobObject->jobState = JOBLIST_STATUS_MODE_DONE_PRINTING;
							pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_DONE_PRINTING;
							GetJobStatusStringFromJobStatusMode(pDevicePrintJob->m_iJobStatusMode, pDevicePrintJob->m_strJobStatus);
							CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::GetJobProgress: Job %s Done Printing Detected", pDevicePrintJob->m_strJobName.c_str());
							break;
						default:
							break;
					}
				}
			}
			else
			{
				CLogUtils::LOG_UTILS_TRACE("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found job-state");
			}

			if ((attr = ippFindAttribute(pResponse, "job-state-reasons", IPP_TAG_KEYWORD)) != NULL)
			{
				SetIPPJobStateReason(attr, &pJobInfo->reasons);
			}
			else
			{
				CLogUtils::LOG_UTILS_TRACE("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found job-state-reasons");
			}

			if ((attr = ippFindAttribute(pResponse, "job-detailed-status-messages", IPP_TAG_TEXT)) != NULL)
			{                       
				strncpy((char* )(pJobInfo->detailedStatusMessage), 
					attr->values[0].string.text, 2047);
				pJobInfo->detailedStatusMessage[2047] = 0;
			}
			else
			{
				CLogUtils::LOG_UTILS_TRACE("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found job-detailed-status-messages");
				pJobInfo->detailedStatusMessage[0] = 0;
			}

			if ((attr = ippFindAttribute(pResponse, "job-k-octets", IPP_TAG_INTEGER)) != NULL)
			{
				pJobInfo->bytesProcessed = attr->values[0].integer;
			}
			else
			{
				CLogUtils::LOG_UTILS_TRACE("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found job-k-octets");
			}

			if ((attr = ippFindAttribute(pResponse, "job-impressions-completed", IPP_TAG_INTEGER)) != NULL)
			{
				pJobInfo->impressionsCompleded = attr->values[0].integer;
				pDevicePrintJob->m_uiTotalPagesPrinted = attr->values[0].integer;
				pDevicePrintJob->m_uiDeviceClickTotalPagesPrinted = attr->values[0].integer;
				CLogUtils::LOG_UTILS_EX(eTRACE, "CFCIPPConnectionObjectBase::GetJobProgress: job-impressions-completed = %d", pDevicePrintJob->m_uiDeviceClickTotalPagesPrinted);
			}
			else
			{
				CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found job-impressions-completed");
			}

			if ((attr = ippFindAttribute(pResponse, "job-media-sheets-completed", IPP_TAG_INTEGER)) != NULL)
			{
				pJobInfo->mediaSheetsCompleded = attr->values[0].integer;
				pDevicePrintJob->m_uiTotalSheetsPrinted = attr->values[0].integer;
				pDevicePrintJob->m_uiDeviceClickTotalSheetsPrinted = attr->values[0].integer;

				CLogUtils::LOG_UTILS_EX(eTRACE, "CFCIPPConnectionObjectBase::GetJobProgress: job-media-sheets-completed = %d", pDevicePrintJob->m_uiDeviceClickTotalSheetsPrinted);

				// KM apparently did not initialize their "job-impressions-completed" so if their is no sheets output
				// we need to make sure no pages were output
				if (pDevicePrintJob->m_uiDeviceClickTotalSheetsPrinted == 0)
				{
					pJobInfo->impressionsCompleded = 0;
					pDevicePrintJob->m_uiTotalPagesPrinted = 0;
					pDevicePrintJob->m_uiDeviceClickTotalPagesPrinted = 0;
				}
			}
			else
			{
				CLogUtils::LOG_UTILS_DEBUG("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found job-media-sheets-completed");
			}

			if ((attr = ippFindAttribute(pResponse, "date-time-at-creation", IPP_TAG_DATE)) != NULL)
			{
				pJobInfo->dateTimeAtCreation = ippDateToTime(attr->values[0].date);
			}
			else
			{
				CLogUtils::LOG_UTILS_TRACE("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found date-time-at-creation");
			}

			if ((attr = ippFindAttribute(pResponse, "date-time-at-processing", IPP_TAG_DATE)) != NULL)
			{
				pJobInfo->dateTimeAtProcessing = ippDateToTime(attr->values[0].date);
			}
			else
			{
				CLogUtils::LOG_UTILS_TRACE("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found date-time-at-processing");
			}

			if ((attr = ippFindAttribute(pResponse, "date-time-at-completed", IPP_TAG_DATE)) != NULL)
			{                
				pJobInfo->dateTimeAtCompleted = ippDateToTime(attr->values[0].date);
			}
			else
			{
				CLogUtils::LOG_UTILS_TRACE("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found date-time-at-completed");
			}

			//if ((attr = ippFindAttribute(pResponse, "page-overrides", IPP_TAG_BEGIN_COLLECTION)) != NULL)
			//{                
			//	SetIPPPageOverrides(attr, &pJobInfo->pageOverrides);
			//}
			//else
			//{
			//	CLogUtils::LOG_UTILS_TRACE("CFCIPPConnectionObjectBase::GetJobProgress: Attr not found page-overrides");
			//}
		}

		// pRequest is deleted in cupsDoRequest
		ippDelete(pResponse);
	}
	else
	{
		uiError = IPPLIB_IPP_ERROR;
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets job attributes. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="nJobID">  	Identifier for the job. </param>
/// <param name="pJobInfo">	Information describing the job. </param>
///
/// <returns>	The job attributes. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::GetJobAttributes(int nJobID, PTRIPPJOBINFO_3 pJobInfo)
{
	IPPLIB_RESULT   uiError = IPPLIB_SUCCESS;
	ipp_t           *pResponse = NULL;
	ipp_attribute_t *attr = NULL;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	memset(pJobInfo, '\0', sizeof(IPPJOBINFO_3));

	ipp_t* pRequest = ippNew();
	if (pRequest == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("GetJobAttributes: unable to allocate memory for ipp request");
		return IPPLIB_MEM_ERROR;
	}

	memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
	pRequest->request.op.operation_id = IPP_GET_JOB_ATTRIBUTES;
	pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET, "attributes-charset", NULL, charset);
	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE,
		"attributes-natural-language", NULL,
		language != NULL ? language : "C");

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, HTTP_uri);
	ippAddInteger(pRequest, IPP_TAG_OPERATION, IPP_TAG_INTEGER, "job-id", nJobID);
	ippAddStrings(pRequest, IPP_TAG_OPERATION, IPP_TAG_KEYWORD,
		"requested-attributes", 
		sizeof(gja2_requested) / sizeof(gja2_requested[0]),
		NULL, gja2_requested);

	if ((pResponse = cupsDoRequest(http, pRequest, resource)) != NULL)
	{
		const char* pHttpField = NULL;
		if ((pHttpField = httpGetField(http, HTTP_FIELD_CONNECTION)) != NULL)
		{
			if (strcmpi(pHttpField, "close") == 0)
			{
				CLogUtils::LOG_UTILS_INFO("GetJobAttributes: HTTP_FIELD_CONNECTION == close");
				do_reconnect = 1;
			}
		}
		else
		{
			CLogUtils::LOG_UTILS_ERROR("GetJobAttributes: function httpGetField return NULL");
			uiError = IPPLIB_ERROR;
		}

		if (pResponse->request.status.status_code > IPP_OK_CONFLICT)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "GetJobAttributes: failed: %s", ippErrorString(pResponse->request.status.status_code));
			uiError = IPPLIB_ERROR;
		}
		else
		{
			//todo get new attributes.

			if ((attr = ippFindAttribute(pResponse, "job-id", 
				IPP_TAG_INTEGER)) != NULL)
			{
				pJobInfo->jobID =  attr->values[0].integer;
			}
			else
			{
				CLogUtils::LOG_UTILS_DEBUG("GetJobAttributes: Attr not found job-id");
			}

			if ((attr = ippFindAttribute(pResponse, "job-uri", 
				IPP_TAG_URI)) != NULL)
			{
				strncpy(pJobInfo->jobUrl, attr->values[0].string.text, 
					sizeof(pJobInfo->jobUrl)-1);
				pJobInfo->jobUrl[sizeof(pJobInfo->jobUrl)-1] = 0;
			}
			else
			{
				CLogUtils::LOG_UTILS_DEBUG("GetJobAttributes: Attr not found job-uri");
			}

			if ((attr = ippFindAttribute(pResponse, "job-name",
				IPP_TAG_NAME)) != NULL)
			{
				strncpy(pJobInfo->jobName, attr->values[0].string.text, 
					sizeof(pJobInfo->jobName)-1);
				pJobInfo->jobName[sizeof(pJobInfo->jobName)-1] = 0;
			}
			else
			{
				CLogUtils::LOG_UTILS_DEBUG("GetJobAttributes: Attr not found job-uri");
			}

			if ((attr = ippFindAttribute(pResponse, "copies",
				IPP_TAG_INTEGER)) != NULL)
			{
				pJobInfo->num_copies = attr->values[0].integer;
			}
			else
			{
				CLogUtils::LOG_UTILS_DEBUG("GetJobAttributes: Attr not found copies");
			}

			// first look for detailed accounting structure (originated by Oce)
			if ((attr = ippFindAttribute(pResponse, "job-sheets-col-actual",
				IPP_TAG_BEGIN_COLLECTION)) != NULL)
			{
				ExtractMixedMediaInfo(attr, pJobInfo);
			}// if not found, fall back to basic single media-col (body only)
			else if ((attr = ippFindAttribute(pResponse, "media-col",
				IPP_TAG_BEGIN_COLLECTION)) != NULL)
			{
				ExtractMediaInfo(attr->values[0].collection, &pJobInfo->media[0].info, 0);
				pJobInfo->num_media = 1;
			}
			else
			{
				CLogUtils::LOG_UTILS_DEBUG("GetJobAttributes: Attr not found media-col");
			}

			DumpJobInfo3(pJobInfo);
		}

		// pRequest is deleted in cupsDoRequest
		ippDelete(pResponse);
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Creates job request. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pTemplate">	  	[in,out] If non-null, the template. </param>
/// <param name="pJobInfo">		  	Information describing the job. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::CreateJobRequest(CFCIPPJobObject* pFCIPPJobObject, IPP_JOB_TEMPLATE *pTemplate, PTRIPPJOBINFO_1  pJobInfo)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	ipp_t           *pResponse = NULL;
	ipp_attribute_t *attr = NULL;
	ipp_t *col = NULL;
	ipp_t *mediacol = NULL;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CreateJobRequest: invalid parameter");
		return IPPLIB_INTERNAL_ERROR;
	}

	ipp_t* pRequest = ippNew();
	if (pRequest == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CreateJobRequest: unable to allocate memory for ipp request");
		return IPPLIB_MEM_ERROR;
	}

	memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
	pRequest->request.op.operation_id = IPP_CREATE_JOB;
	pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET,  "attributes-charset", NULL, charset);
	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE,
		"attributes-natural-language", NULL,
		language != NULL ? language : "C");

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, IPP_uri);
	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_NAME, "requesting-user-name", NULL, pFCIPPJobObject->userName);

	if (pFCIPPJobObject->jobName)
	{
		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_NAME, "job-name", NULL, pFCIPPJobObject->jobName);
	}

	if (pTemplate)
	{
		if (pTemplate->copies && *pTemplate->copies > 0)
			ippAddInteger(pRequest, IPP_TAG_JOB, IPP_TAG_INTEGER, "copies", *pTemplate->copies);

		if (pTemplate->outputBin)
			ippAddString(pRequest, IPP_TAG_JOB, IPP_TAG_KEYWORD, "output-bin", NULL, pTemplate->outputBin);

		if (pTemplate->pageDelivery)
			ippAddString(pRequest, IPP_TAG_JOB, IPP_TAG_KEYWORD, "page-delivery", NULL, pTemplate->pageDelivery);

		if (pTemplate->sides)
			ippAddString(pRequest, IPP_TAG_JOB, IPP_TAG_KEYWORD, "sides", NULL, pTemplate->sides);

		if (pTemplate->collate)
			ippAddString(pRequest, IPP_TAG_JOB, IPP_TAG_KEYWORD, "sheet-collate", NULL, pTemplate->collate);

		if (pTemplate->slipSheet)
		{
			col = ippNew();
			ippAddString(col, IPP_TAG_JOB, IPP_TAG_KEYWORD, "separator-sheets-type", NULL, pTemplate->slipSheet);
			//ipp_collection_add_string(col, IPP_TAG_JOB, IPP_TAG_KEYWORD, 
			// "separator-sheets-type", NULL, pTemplate->slipSheet);

			if (pTemplate->slipSheetStock)
			{
				//mediacol = 	ipp_create_collection_tree("media-col");
				mediacol = ippNew();
				ippAddString(col, IPP_TAG_JOB, IPP_TAG_KEYWORD, "media-key", NULL, pTemplate->slipSheetStock);
				ippAddCollection(col, IPP_TAG_JOB, "media-col", mediacol);
				//ipp_collection_add_string(mediacol, IPP_TAG_JOB, 
				// IPP_TAG_KEYWORD, "media-key", NULL, 
				// pTemplate->slipSheetStock);
				//ipp_collection_add_collection(col, IPP_TAG_JOB, 
				// "media-col", mediacol);
			}

			ippAddCollection(pRequest, IPP_TAG_JOB, "separator-sheets", col);
		}
	}

	if ((pResponse = cupsDoRequest(http, pRequest, resource)) != NULL)
	{
		const char* pHttpField = NULL;
		if ((pHttpField = httpGetField(http, HTTP_FIELD_CONNECTION)) != NULL)
		{
			if (strcmpi(pHttpField, "close") == 0)
			{
				CLogUtils::LOG_UTILS_INFO("CreateJobRequest: HTTP_FIELD_CONNECTION == close");
				do_reconnect = 1;
			}
		}
		else
		{
			CLogUtils::LOG_UTILS_ERROR("CreateJobRequest: function httpGetField return NULL");
			uiError = IPPLIB_ERROR;
		}

		if (pResponse->request.status.status_code > IPP_OK_CONFLICT)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "CreateJobRequest: failed: %s", ippErrorString(pResponse->request.status.status_code));
			uiError = IPPLIB_ERROR;
		}
		else
		{
			if ((attr = ippFindAttribute(pResponse, "job-id", 
				IPP_TAG_INTEGER)) != NULL)
			{
				pJobInfo->jobID = attr->values[0].integer;
				pFCIPPJobObject->jobID = pJobInfo->jobID;
			}
			else
			{
				CLogUtils::LOG_UTILS_DEBUG("CreateJobRequest: Attr not found job-id");
			}

			if ((attr = ippFindAttribute(pResponse, "job-uri", 
				IPP_TAG_URI)) != NULL)
			{
				strncpy(pJobInfo->jobUrl, attr->values[0].string.text, sizeof(pJobInfo->jobUrl)-1);
				pJobInfo->jobUrl[sizeof(pJobInfo->jobUrl)-1] = 0;
				strcpy(pFCIPPJobObject->jobUri, pJobInfo->jobUrl);
			}
			else
			{
				CLogUtils::LOG_UTILS_DEBUG("CreateJobRequest: Attr not found job-uri");
			}

			if ((attr = ippFindAttribute(pResponse, "job-state",
				IPP_TAG_ENUM)) != NULL)
			{
				SetIPPJobState(attr, &pJobInfo->state);
			}
			else
			{
				CLogUtils::LOG_UTILS_DEBUG("CreateJobRequest: Attr not found job-state");
			}

			if ((attr = ippFindAttribute(pResponse, "job-state-reasons",
				IPP_TAG_KEYWORD)) != NULL)
			{
				SetIPPJobStateReason(attr, &pJobInfo->reasons);
			}
			else
			{
				// This is option attribute.
				CLogUtils::LOG_UTILS_DEBUG("CreateJobRequest: Attr not found job-state-reasons");
			}
		}

		// pRequest is deleted in cupsDoRequest
		ippDelete(pResponse);
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		pFCIPPJobObject->error = 1;
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Starts a document. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pDocName">		  	Name of the document. </param>
/// <param name="lastDoc">		  	The last document. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::StartDocument(CFCIPPJobObject* pFCIPPJobObject, const char* pDocName, int lastDoc)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	if (pFCIPPJobObject == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("StartDocument: invalid parameter");
		return IPPLIB_INTERNAL_ERROR;
	}

	ipp_t* pRequest = ippNew();
	if (pRequest == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("StartDocument: unable to allocate memory for ipp request");
		uiError = IPPLIB_MEM_ERROR;
	}

	if (uiError == IPPLIB_SUCCESS)
	{
		memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
		pRequest->request.op.operation_id = IPP_SEND_DOCUMENT;
		pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET, "attributes-charset", NULL, charset);
		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE,
			"attributes-natural-language", NULL,
			language != NULL ? language : "C");

		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, IPP_uri);
		ippAddInteger(pRequest, IPP_TAG_OPERATION, IPP_TAG_INTEGER, "job-id", pFCIPPJobObject->jobID);
		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_NAME, "requesting-user-name", NULL, pFCIPPJobObject->userName);
		ippAddInteger(pRequest, IPP_TAG_OPERATION, IPP_TAG_BOOLEAN, "last-document", lastDoc);

		pFCIPPJobObject->pIPPRequest = pRequest;

		uiError= SendIPPHeaderChunk(pFCIPPJobObject);
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		ippDelete(pFCIPPJobObject->pIPPRequest);
		pFCIPPJobObject->pIPPRequest = NULL;

		pFCIPPJobObject->error = 1;
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Cancel job. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="jobID">   	Identifier for the job. </param>
/// <param name="userName">	Name of the user. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::CancelJob(int jobID, const char* userName)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	ipp_t	*pResponse = NULL;
	char	uri[1024];

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	ipp_t* pRequest = ippNew();
	if (pRequest == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("CancelJob: unable to allocate memory for ipp request");
		uiError = IPPLIB_MEM_ERROR;
	}

	if (uiError == IPPLIB_SUCCESS)
	{
		memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
		pRequest->request.op.operation_id = IPP_CANCEL_JOB;
//  Don  want to add a generic cancel, hold, restart, etc... IPP command where you pass in the command
//  IPP_HOLD_JOB,
 // IPP_RESTART_JOB,
		pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET, "attributes-charset", NULL, charset);
		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE,
			"attributes-natural-language", NULL,
			language != NULL ? language : "C");

		if (m_pFCIPPCommandsBase->GetDeviceType() == FT_KONICAMINOLTA)
		{
			sprintf(uri, "%s?%d", IPP_uri, jobID);
			ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "job-uri", NULL, uri);
		}
		else
		{
			ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, IPP_uri);
			ippAddInteger(pRequest, IPP_TAG_OPERATION, IPP_TAG_INTEGER, "job-id", jobID);
		}

		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_NAME, "requesting-user-name", NULL, userName);

		if ((pResponse = cupsDoRequest(http, pRequest, resource)) != NULL)
		{
			const char* pHttpField = NULL;
			if ((pHttpField = httpGetField(http, HTTP_FIELD_CONNECTION)) != NULL)
			{
				if (strcmpi(pHttpField, "close") == 0)
				{
					CLogUtils::LOG_UTILS_INFO("CancelJob: HTTP_FIELD_CONNECTION == close.");
					do_reconnect = 1;
				}
			}
			else
			{
				CLogUtils::LOG_UTILS_ERROR("CancelJob: function httpGetField return NULL");
				uiError = IPPLIB_ERROR;
			}

			if (pResponse->request.status.status_code > IPP_OK_CONFLICT)
			{
				CLogUtils::LOG_UTILS_EX(eERROR, "CancelJob: failed: %s", ippErrorString(pResponse->request.status.status_code));
				uiError = IPPLIB_ERROR;
			}

			// pRequest is deleted in cupsDoRequest
			ippDelete(pResponse);
		}
		else
		{
			CLogUtils::LOG_UTILS_ERROR("CancelJob: cupsDoRequest failed- pResponse == NULL.");
			uiError = IPPLIB_ERROR;
		}
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Purge jobs. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="userName">	Name of the user. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::PurgeJobs(const char* userName)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	ipp_t           *pResponse = NULL;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	ipp_t* pRequest = ippNew();
	if (pRequest == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("PurgeJobs: unable to allocate memory for ipp request");
		uiError = IPPLIB_MEM_ERROR;
	}

	if (uiError == IPPLIB_SUCCESS)
	{
		memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
		pRequest->request.op.operation_id = IPP_PURGE_JOBS;
		pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET, "attributes-charset", NULL, charset);
		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE,
			"attributes-natural-language", NULL,
			language != NULL ? language : "C");

		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, IPP_uri);
		ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_NAME, "requesting-user-name", NULL, userName);

		if ((pResponse = cupsDoRequest(http, pRequest, resource)) != NULL)
		{
			const char* pHttpField = NULL;
			if ((pHttpField = httpGetField(http, HTTP_FIELD_CONNECTION)) != NULL)
			{
				if (strcmpi(pHttpField, "close") == 0)
				{
					CLogUtils::LOG_UTILS_INFO("PurgeJobs: HTTP_FIELD_CONNECTION == close");
					do_reconnect = 1;
				}
			}
			else
			{
				CLogUtils::LOG_UTILS_ERROR("PurgeJobs: function httpGetField return NULL");
				uiError = IPPLIB_ERROR;
			}

			if (pResponse->request.status.status_code > IPP_OK_CONFLICT)
			{
				CLogUtils::LOG_UTILS_EX(eDEBUG, "PurgeJobs: failed: %s", ippErrorString(pResponse->request.status.status_code));
				uiError = IPPLIB_ERROR;
			}

			// pRequest is deleted in cupsDoRequest
			ippDelete(pResponse);
		}
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets media ready. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="mediaReadyList">	[in,out] If non-null, list of media readies. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::GetMediaReady(IPPMEDIAREADY **mediaReadyList)
{
	IPPLIB_RESULT   uiError = IPPLIB_SUCCESS;
	ipp_t           *pResponse = NULL;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	ipp_t* pRequest = ippNew();
	if (pRequest == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("GetMediaReady: unable to allocate memory for ipp request");
		return IPPLIB_MEM_ERROR;
	}

	memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
	pRequest->request.op.operation_id = IPP_GET_PRINTER_ATTRIBUTES;
	pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET, "attributes-charset", NULL, charset);
	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE,
		"attributes-natural-language", NULL,
		language != NULL ? language : "C");

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, HTTP_uri);
	ippAddStrings(pRequest, IPP_TAG_OPERATION, IPP_TAG_KEYWORD,
		"requested-attributes", sizeof(gpa_ready_requested) / sizeof(gpa_ready_requested[0]),
		NULL, gpa_ready_requested);

	if ((pResponse = cupsDoRequest(http, pRequest, resource)) != NULL)
	{
		const char* pHttpField = NULL;
		if ((pHttpField = httpGetField(http, HTTP_FIELD_CONNECTION)) != NULL)
		{
			if (strcmpi(pHttpField, "close") == 0)
			{
				CLogUtils::LOG_UTILS_INFO("GetMediaReady: HTTP_FIELD_CONNECTION == close");
				do_reconnect = 1;
			}
		}
		else
		{
			CLogUtils::LOG_UTILS_ERROR("GetMediaReady: function httpGetField return NULL");
			uiError = IPPLIB_ERROR;
		}

		if (pResponse->request.status.status_code > IPP_OK_CONFLICT)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "GetMediaReady: failed: %s", ippErrorString(pResponse->request.status.status_code));
			uiError = IPPLIB_ERROR;
		}
		else
		{
			uiError = CreateMediaReadyList(pResponse, mediaReadyList);
		}

		// pRequest is deleted in cupsDoRequest
		ippDelete(pResponse);
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets media list. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pstrMediaCatalog">	[in,out] If non-null, the pstr media catalog. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::GetMediaList(string* pstrMediaCatalog)
{
	IPPLIB_RESULT   uiError = IPPLIB_SUCCESS;
	ipp_t           *pResponse = NULL;

	if (!ValidateConnectionInfo())
	{
		CLogUtils::LOG_UTILS_DEBUG("ValidateConnectionInfo: Connection data not complete.");
		return IPPLIB_INVALID_PARAM;
	}

	ipp_t* pRequest = ippNew();
	if (pRequest == NULL)
	{
		CLogUtils::LOG_UTILS_DEBUG("GetMediaList: unable to allocate memory for ipp request");
		return IPPLIB_MEM_ERROR;
	}

	memcpy(pRequest->request.op.version, ippversion, sizeof(ippversion));
	pRequest->request.op.operation_id = IPP_GET_PRINTER_ATTRIBUTES;
	pRequest->request.op.request_id = m_pFCIPPCommandsBase->GetNextIPPRequestID();

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_CHARSET, "attributes-charset", NULL, charset);
	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_LANGUAGE,
		"attributes-natural-language", NULL,
		language != NULL ? language : "C");

	ippAddString(pRequest, IPP_TAG_OPERATION, IPP_TAG_URI, "printer-uri", NULL, HTTP_uri);
	ippAddStrings(pRequest, IPP_TAG_OPERATION, IPP_TAG_KEYWORD,
		"requested-attributes", sizeof(gpa_media_list_requested) / sizeof(gpa_media_list_requested[0]),
		NULL, gpa_media_list_requested);

	if ((pResponse = cupsDoRequest(http, pRequest, resource)) != NULL)
	{
		const char* pHttpField = NULL;
		if ((pHttpField = httpGetField(http, HTTP_FIELD_CONNECTION)) != NULL)
		{
			if (strcmpi(pHttpField, "close") == 0)
			{
				CLogUtils::LOG_UTILS_INFO("GetMediaList: HTTP_FIELD_CONNECTION == close");
				do_reconnect = 1;
			}
		}
		else
		{
			CLogUtils::LOG_UTILS_ERROR("GetMediaList: function httpGetField return NULL");
			uiError = IPPLIB_ERROR;
		}

		if (pResponse->request.status.status_code > IPP_OK_CONFLICT)
		{
			CLogUtils::LOG_UTILS_EX(eDEBUG, "GetMediaList: failed: %s", ippErrorString(pResponse->request.status.status_code));
			uiError = IPPLIB_ERROR;
		}
		else
		{
			uiError = DoUpdateMediaList(pResponse, pstrMediaCatalog, m_pMediaTypeUtilities, m_pPaperTypeUtilities);
		}

		//pRequest is deleted in cupsDoRequest
		ippDelete(pResponse);
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		do_reconnect = 1;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Trys to get the jobs jlpqmid. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPJobObject">  	[in,out] If non-null, the fcipp job object. </param>
/// <param name="pJobIDMap">			[in,out] If non-null, the job identifier map. </param>
/// <param name="pReferenceDevicePrintJob">	[in,out] If non-null, the reference job base. </param>
/// <param name="pDevicePrintJob">				[in,out] If non-null, the job base. </param>
/// <param name="bForwardOrder">		true for forward order. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPConnectionObjectBase::GetJobsJLPQMID(CFCIPPJobObject* pFCIPPJobObject, intIntMap* pJobIDMap, CDevicePrintJob* pReferenceDevicePrintJob, CDevicePrintJob* pDevicePrintJob, bool bForwardOrder)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	string strOrgJobListID = pReferenceDevicePrintJob->m_strJLJobID;
	string strPossibleJobListID = strOrgJobListID;

	int iOrgJLPQMID = pFCIPPJobObject->jobID;
	int iStartPossibleJLPQMID = iOrgJLPQMID;
	int iEndPossibleJLPQMID = iOrgJLPQMID;
	int iReferenceJobBaseJLPQMID = 0;
	intIntMap::iterator iter;

	string strQueryReferenceJobID;
	CDevicePrintJob* pQueryReferenceJobBase = NULL;

	bool bStopLooking = false;

	// Checking forward for the device's Job ID
//	while (!bStopLooking && ((pDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_START) ||
//		(pDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_END)))
	while (!bStopLooking && pDevicePrintJob->m_bJobContainsProjectedJobID)
	{
		if (bForwardOrder)
			strQueryReferenceJobID = m_pDevicePrintJobCache->GetNextJLJobID(strPossibleJobListID);
		else
			strQueryReferenceJobID = m_pDevicePrintJobCache->GetPrevJLJobID(strPossibleJobListID);

		if (strQueryReferenceJobID.empty())
		{
			bStopLooking = true;
			pQueryReferenceJobBase = NULL;
			break;
		}

		strPossibleJobListID = strQueryReferenceJobID;
		pQueryReferenceJobBase = m_pDevicePrintJobCache->GetDevicePrintJobFromJLJobID(strQueryReferenceJobID);

		if (pQueryReferenceJobBase)
		{
			iReferenceJobBaseJLPQMID = atoi(pQueryReferenceJobBase->m_strJLPQMID.c_str());

//			if ((pQueryReferenceJobBase->m_iEventType != HARMONY_JOBEVENTTYPE_REDIRECT_START) &&
//				(pQueryReferenceJobBase->m_iEventType != HARMONY_JOBEVENTTYPE_REDIRECT_END))
			if (!pQueryReferenceJobBase->m_bJobContainsProjectedJobID)
			{
				bStopLooking = true;
				if (iOrgJLPQMID > iReferenceJobBaseJLPQMID)
					++iReferenceJobBaseJLPQMID;
				else
					--iReferenceJobBaseJLPQMID;
			}

			if (iOrgJLPQMID > iReferenceJobBaseJLPQMID)
			{
				iStartPossibleJLPQMID = iReferenceJobBaseJLPQMID;
				iEndPossibleJLPQMID = iOrgJLPQMID-1;
			}
			else
			{
				iStartPossibleJLPQMID = iOrgJLPQMID+1;
				iEndPossibleJLPQMID = iReferenceJobBaseJLPQMID;
			}

			for (int i=iStartPossibleJLPQMID; i<=iEndPossibleJLPQMID; i++)
			{
				iter = pJobIDMap->find(i);
				if (iter == pJobIDMap->end())
					pJobIDMap->insert(intIntMap::value_type(i, i));
				else
					continue;

				pFCIPPJobObject->jobID = i;
				pDevicePrintJob->m_strJLPQMID = FormatString("%d", i);

				uiError = GetJobProgress(pFCIPPJobObject, pDevicePrintJob, false);

//				if ((pDevicePrintJob->m_iEventType != HARMONY_JOBEVENTTYPE_REDIRECT_START) &&
//					(pDevicePrintJob->m_iEventType != HARMONY_JOBEVENTTYPE_REDIRECT_END))
				if (!pDevicePrintJob->m_bJobContainsProjectedJobID)
				{
					pReferenceDevicePrintJob->m_iEventType = pDevicePrintJob->m_iEventType;
					break;
				}
			}

//			if ((pDevicePrintJob->m_iEventType != HARMONY_JOBEVENTTYPE_REDIRECT_START) &&
//				(pDevicePrintJob->m_iEventType != HARMONY_JOBEVENTTYPE_REDIRECT_END))
			if (!pDevicePrintJob->m_bJobContainsProjectedJobID)
			{
				// if the pQueryReferenceJobBase has the JLPQMID for this job then lets swap and hope
				// it fixes both.
				if (pQueryReferenceJobBase && !bStopLooking)
					pQueryReferenceJobBase->m_strJLPQMID = pReferenceDevicePrintJob->m_strJLPQMID;

				pReferenceDevicePrintJob->m_strJLPQMID = pDevicePrintJob->m_strJLPQMID;
			}

			m_pDevicePrintJobCache->ReleaseDevicePrintJobFromJLJobID(strQueryReferenceJobID);
		}
		else
			bStopLooking = true;
	}

//	if ((pDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_START) ||
//		(pDevicePrintJob->m_iEventType == HARMONY_JOBEVENTTYPE_REDIRECT_END))
	if (pDevicePrintJob->m_bJobContainsProjectedJobID)
	{
		pDevicePrintJob->m_strJLPQMID = pReferenceDevicePrintJob->m_strJLPQMID;
	}

	return uiError;
}

void CFCIPPConnectionObjectBase::AddDevicePossiblePrintedJobsToJobList(CJobList* pJobList, bool bMonitorJobStatus)
{
	// Check to see if any jobs not verified in the job cache are actually cancelled or printed.
	if (m_bRequiresPrintedJobNotVerifiedOnDeviceJobList && m_bDeviceSupportsStatusAfterRemovedFromJobList && bMonitorJobStatus)
	{
		CJobList DevicePossiblePrintedJobList;
		CDevicePrintJob* pDevicePrintJob = NULL;
		CDevicePrintJob* pReferenceDevicePrintJob = NULL;
		UINT uiError = NO_ERROR;

		m_pDevicePrintJobCache->GetPossiblePrintedJobsNotVerifiedOnDevice(&DevicePossiblePrintedJobList, m_iPrintedJobNotVerifiedOnDeviceJobListCountLimit, m_iPrintedJobNotVerifiedOnDeviceJobListMinimumPagesExpected);

		for (int i=0; i<(int)DevicePossiblePrintedJobList.size(); i++)
		{
			pReferenceDevicePrintJob = DevicePossiblePrintedJobList.at(i);

			if (pReferenceDevicePrintJob)
			{
				CFCIPPJobObject FCIPPJobObject(m_pFCIPPCommandsBase, (CFCIPPConnectionObject*)this, pReferenceDevicePrintJob);
				FCIPPJobObject.jobID = atoi(pReferenceDevicePrintJob->m_strJLPQMID.c_str());
				int iOrgJobStatusMode = pReferenceDevicePrintJob->m_iJobStatusMode;
				uiError = GetJobProgress(&FCIPPJobObject, pReferenceDevicePrintJob, true);
				if (uiError == NO_ERROR)
				{
					if ((pReferenceDevicePrintJob->m_iJobStatusMode == JOBLIST_STATUS_MODE_DONE_PRINTING) ||
						(pReferenceDevicePrintJob->m_iJobStatusMode == JOBLIST_STATUS_MODE_CANCELLED))
					{
						pReferenceDevicePrintJob->m_iJobStatusMode = iOrgJobStatusMode;
						pDevicePrintJob = new CDevicePrintJob(pReferenceDevicePrintJob->m_pSubJob);
						pDevicePrintJob->CopyDevicePrintJob(pReferenceDevicePrintJob);

						IsJobInLocalCache(pDevicePrintJob);
						pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_PRINTING;
						pDevicePrintJob->m_iCurrJobListStatusMode = JOBLIST_STATUS_MODE_PRINTING;
						if (bMonitorJobStatus)
							CheckForJobProgress(pDevicePrintJob);

						pJobList->push_back(pDevicePrintJob);
						CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::AddDevicePossiblePrintedJobList: Added Job name %s, JobPrintNumber = %d", pDevicePrintJob->m_strJobName.c_str(), pDevicePrintJob->m_uiJobPrintNumber);
					}
					else
						pReferenceDevicePrintJob->m_iJobStatusMode = iOrgJobStatusMode;
				}
			}
		}
	}
}

void CFCIPPConnectionObjectBase::AddDevicePossibleLostJobsToJobList(CJobList* pJobList, bool bMonitorJobStatus)
{
	// Check to see if any jobs not verified in the job cache are actually still there.
	if (m_bRequiresLostJobNotVerifiedOnDeviceJobList && bMonitorJobStatus)
	{
		int iPrintedJobNotVerifiedOnDeviceJobListMaxCountLimit = 12;
		CJobList DevicePossibleLostJobList;
		CDevicePrintJob* pDevicePrintJob = NULL;
		CDevicePrintJob* pReferenceDevicePrintJob = NULL;
		UINT uiError = NO_ERROR;
		bool bAddLostJob = false;
		bool bJobVerified = false;
		bool bExtendMaxCountLimit = false;
		int iOrgJobStatusMode = 0;
		int iJobMaxCountLimit = 0;

		m_pDevicePrintJobCache->GetPossibleLostJobsNotVerifiedOnDevice(&DevicePossibleLostJobList, iPrintedJobNotVerifiedOnDeviceJobListMaxCountLimit);

		for (int i=0; i<(int)DevicePossibleLostJobList.size(); i++)
		{
			bAddLostJob = false;
			bJobVerified = false;
			bExtendMaxCountLimit = false;
			iJobMaxCountLimit = iPrintedJobNotVerifiedOnDeviceJobListMaxCountLimit;
			CDevicePrintJob* pReferenceDevicePrintJob = DevicePossibleLostJobList.at(i);

			if (pReferenceDevicePrintJob)
			{
				iOrgJobStatusMode = pReferenceDevicePrintJob->m_iJobStatusMode;

				if (!pReferenceDevicePrintJob->m_strJLPQMID.empty() && (pReferenceDevicePrintJob->m_strJLPQMID != "0"))
				{
					CFCIPPJobObject FCIPPJobObject(m_pFCIPPCommandsBase, (CFCIPPConnectionObject*)this, pReferenceDevicePrintJob);
					FCIPPJobObject.jobID = atoi(pReferenceDevicePrintJob->m_strJLPQMID.c_str());
					uiError = GetJobProgress(&FCIPPJobObject, pReferenceDevicePrintJob, true);

					if (uiError == NO_ERROR)
					{
						if (FCIPPJobObject.jobState != 0)
							bJobVerified = true;
					}

					if (!bJobVerified && !bAddLostJob && !m_bDeviceSupportsStatusAfterRemovedFromJobList)
						bExtendMaxCountLimit = true;
				}
				else
					bExtendMaxCountLimit = true;

			
				if (bExtendMaxCountLimit)
				{
					iJobMaxCountLimit += 12;
					if (pReferenceDevicePrintJob->m_iJobListPollCountSinceAddedToDevicePrintJobCache >= iJobMaxCountLimit)
						bAddLostJob = true;
				}

				pReferenceDevicePrintJob->m_iJobStatusMode = iOrgJobStatusMode;

				if (bAddLostJob)
				{
					pDevicePrintJob = new CDevicePrintJob(pReferenceDevicePrintJob->m_pSubJob);
					pDevicePrintJob->CopyDevicePrintJob(pReferenceDevicePrintJob);

					IsJobInLocalCache(pDevicePrintJob);
					pDevicePrintJob->m_iJobStatusMode = JOBLIST_STATUS_MODE_CANCELLED;
					pDevicePrintJob->m_iCurrJobListStatusMode = JOBLIST_STATUS_MODE_CANCELLED;
					if (bMonitorJobStatus)
						CheckForJobProgress(pDevicePrintJob);

					pJobList->push_back(pDevicePrintJob);
					CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPConnectionObjectBase::AddDevicePossiblePrintedJobList: Added Job name %s, JobPrintNumber = %d", pDevicePrintJob->m_strJobName.c_str(), pDevicePrintJob->m_uiJobPrintNumber);
				}
			}
		}
	}
}
