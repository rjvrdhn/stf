// FCIPPConnectionObjectBase.h
/********************************************************************
*
*  (c) Copyright 2013  
*      Electronics for Imaging, Inc. ("EFI").
*      All Rights Reserved
*
*  EFI products contain certain trade secrets and confidential and
*  proprietary information of EFI.  Use, reproduction, disclosure,
*  distribution by any means are prohibited, except pursuant to
*  a written license from EFI. Modification, translation, reverse
*  engineering, decompiling, disassembling, and creating derivative
*  works based on this software are prohibited, except pursuant to
*  a written license from EFI. Use of copyright notice does not imply
*  publication or disclosure.
*
*  Restricted Rights Legend:
*  Use, duplication, or disclosure by the Government is subject to
*  restrictions as set forth in subparagraph (c)(1)(ii) of The
*  Rights in Technical Data and Computer Software clause in DFARS
*  252.227-7013 or subparagraphs (c)(1) and (2) of the Commercial
*  Computer Software--Restricted Rights at 48 CFR 52.227-19, as
*  applicable.
*
**********************************************************************
*/
#pragma once

class CFCIPPConnectionObject;
class CFCIPPCommandsBase;
class CFCIPPJobObject;
class CDevicePrintJob;
class CDevicePrintJobCache;
class CDevice;
class CMediaUtilities;
class CPaperTypeUtilities;

#include "FCIPPDefines.h"
#include "http.h"
#include "cups-private.h"

#pragma warning (push)
#pragma warning (disable:4251)

class CFCIPPConnectionInfo
{
public:
	char		url[HTTP_MAX_URI];
	char		HTTP_uri[HTTP_MAX_URI];
	char		IPP_uri[HTTP_MAX_URI];
	char		method[IPPLIB_MAX_NAME_LEN];	    /* Method in URI */
	char		hostname[IPPLIB_MAX_NAME_LEN];		/* Hostname */
	char		username[IPPLIB_MAX_NAME_LEN];	    /* Username info */
	char		resource[IPPLIB_MAX_NAME_LEN];		/* Resource info (printer name) */
	char*		password;
	int			port;
	char		charset[128];
	char*		language;
	http_t*		http;								/* Cups HTTP connection object*/
	int			do_reconnect;
	ipp_uchar_t	ippversion[2];

public:
	CFCIPPConnectionInfo()
	{
    	password = NULL;
		language = "en_us";							// cups_lang_t* cupsLangGet(const char *language);  "en-US"?
		http = NULL;								// Cups HTTP connection object
    	port = ippPort();
		SetIPPVersion(1,1);							// Set Default Version to 1.1
		Init();
	}

	virtual ~CFCIPPConnectionInfo()
	{ 
		Init();
	}

	void SetIPPVersion(int iVersionMSB, int iVersionLSB)
	{
		ippversion[0] = iVersionMSB;
		ippversion[1] = iVersionLSB;
	}

private:
	void Init()
	{
		memset(url, 0, HTTP_MAX_URI);
		InitConnectionInfo();
	}

protected:
	void InitConnectionInfo()
	{
		memset(HTTP_uri, 0, HTTP_MAX_URI);
		memset(IPP_uri, 0, HTTP_MAX_URI);
		memset(method, 0, IPPLIB_MAX_NAME_LEN);
		memset(hostname, 0, IPPLIB_MAX_NAME_LEN);
		strcpy(username, DEFAULT_USERNAME);
//		memset(username, 0, IPPLIB_MAX_NAME_LEN);
		memset(resource, 0, IPPLIB_MAX_NAME_LEN);
		memset(charset, 0, 128);
		do_reconnect = 1;

		if (password)
		{
			free(password);
			password = NULL;
		}

		if (http)
		{
			httpClose(http);
			http = NULL;
		}
	}

	bool ValidateConnectionInfo()
	{
		bool bValidData = true;

		if ((NULL == language) ||
			(NULL == http) ||
			(NULL == url[0]) ||
			(NULL == HTTP_uri[0]) ||
			(NULL == IPP_uri[0]) ||
			(NULL == method[0]) ||
			(NULL == hostname[0]) ||
//			(NULL == username[0]) ||
			(NULL == resource[0]) ||
			(NULL == charset[0]) ||
			(port <= 0))
		{
			bValidData = false;
		}

		return bValidData;
	}
};

class CFCIPPConnectionObjectBase : public CFCIPPConnectionInfo
{
protected:
	CFCIPPCommandsBase*		m_pFCIPPCommandsBase;
	CMediaUtilities*		m_pMediaTypeUtilities;
	CPaperTypeUtilities*	m_pPaperTypeUtilities;
	CDevicePrintJobCache*	m_pDevicePrintJobCache;
	CDevice* m_pDevice;
	string m_strDeviceID;
	int m_nRetries;
	int m_iCheckJobProgessPrintingState;
	int	m_iPrintedJobNotVerifiedOnDeviceJobListCountLimit;
	int	m_iPrintedJobNotVerifiedOnDeviceJobListMinimumPagesExpected;
	bool m_bUseJobNameToGetJobID;
	bool m_bAddIDToUserNameForJobMappingID;
	bool m_bIPPJobListJobIDIsValid;
	bool m_bDeviceSupportsStatusAfterRemovedFromJobList;
	bool m_bRequiresPrintedJobNotVerifiedOnDeviceJobList;
	bool m_bRequiresLostJobNotVerifiedOnDeviceJobList;
	bool m_bGetJobProgressOnceWhenJobFinished;

public:
	CFCIPPConnectionObjectBase(CFCIPPCommandsBase* pFCIPPCommandsBase);
	virtual ~CFCIPPConnectionObjectBase();

	virtual IPPLIB_RESULT GetIPPJobProgress(CFCIPPJobObject* pFCIPPJobObject, CDevicePrintJob* pDevicePrintJob, bool bFinalStatusCheck) = 0;

	IPPLIB_RESULT FChttpPrintf(http_t *http, const char *format, ...);
	IPPLIB_RESULT FChttpWrite(http_t *http, const char *buffer, int length);
	IPPLIB_RESULT VerifyHttpConnection(http_t *http);
	IPPLIB_RESULT GetJobProgress(CFCIPPJobObject* pFCIPPJobObject, CDevicePrintJob* pDevicePrintJob, bool bFinalStatusCheck);

protected:
	void	setConnectionAuthInfo();
	void	AddDevicePossiblePrintedJobsToJobList(CJobList* pJobList, bool bMonitorJobStatus);
	void	AddDevicePossibleLostJobsToJobList(CJobList* pJobList, bool bMonitorJobStatus);
	bool	IsJobInLocalCache(CDevicePrintJob* pDevicePrintJob);
	bool	IsPossibleFCJob(CDevicePrintJob* pDevicePrintJob);

	IPPLIB_RESULT StartJobRequest(CFCIPPJobObject* pFCIPPJobObject);
	IPPLIB_RESULT SendIPPHeaderChunk(CFCIPPJobObject* pFCIPPJobObject);
	IPPLIB_RESULT SendJobData(CFCIPPJobObject* pFCIPPJobObject, const char* pBuffer, int numBytes);
	IPPLIB_RESULT StartChunkData(CFCIPPJobObject* pFCIPPJobObject, long chunkLength);
	IPPLIB_RESULT SendChunkData(CFCIPPJobObject* pFCIPPJobObject, const char* pBuffer, long numBytes);
	IPPLIB_RESULT SetJobAttribute(CFCIPPJobObject* pFCIPPJobObject, const char* key, const char* value, int tag_type);
	IPPLIB_RESULT AddPageOverride(CFCIPPJobObject* pFCIPPJobObject, PTRIPPPAGEOVERRIDE** pPageOverride, int numOverrides);
	IPPLIB_RESULT AddBodyMedia(CFCIPPJobObject* pFCIPPJobObject, PTRIPPBODYMEDIA pBodyMedia);
	IPPLIB_RESULT AddPageInsert(CFCIPPJobObject* pFCIPPJobObject, PTRIPPPAGEINSERT** pPageInsert, int numInsertions);
	IPPLIB_RESULT EndChunkData(CFCIPPJobObject* pFCIPPJobObject);
	IPPLIB_RESULT EndJobRequest(CFCIPPJobObject* pFCIPPJobObject);
	IPPLIB_RESULT GetJobList(CJobList *pJobList, bool bMyJobsOnly, bool bJobCompleted, char* pUserName, int* pNumJobs, bool bMonitorJobStatus);
	IPPLIB_RESULT CreateJobList(CJobList *pJobList, ipp_t* pResponse, int* pNumJobs, bool bMyJobsOnly, bool bMonitorJobStatus);
	IPPLIB_RESULT CheckForJobProgress(CDevicePrintJob* pDevicePrintJob, bool bUpdatePrintingTimeStamp=true);
	IPPLIB_RESULT UpdateJobBase(CDevicePrintJob* pDevicePrintJob);
//	IPPLIB_RESULT CloseConnection();
	IPPLIB_RESULT GetPrinterState(IPPPRINTERSTATE *pState, IPPPRINTERSTATEREASONSTRUCT *pReason, PRTIPPDETAILEDMSG *pMsg);
	IPPLIB_RESULT GetPrinterInformation(IPPPRINTERINFO *prtInfo);
	IPPLIB_RESULT GetJobAttributes(int nJobID, PTRIPPJOBINFO_3 pJobInfo);
	IPPLIB_RESULT CreateJobRequest(CFCIPPJobObject* pFCIPPJobObject, IPP_JOB_TEMPLATE *pTemplate, PTRIPPJOBINFO_1  pJobInfo);
	IPPLIB_RESULT StartDocument(CFCIPPJobObject* pFCIPPJobObject, const char* pDocName, int lastDoc);
	IPPLIB_RESULT CancelJob(int jobID, const char* userName);
	IPPLIB_RESULT PurgeJobs(const char* userName);
	IPPLIB_RESULT GetMediaReady(IPPMEDIAREADY** mediaReadyList);
	IPPLIB_RESULT GetMediaList(string* pstrMediaCatalog);
	IPPLIB_RESULT GetJobsJLPQMID(CFCIPPJobObject* pFCIPPJobObject, intIntMap* pJobIDMap, CDevicePrintJob* pReferenceDevicePrintJob, CDevicePrintJob* pDevicePrintJob, bool bForwardOrder);
};

#pragma warning (pop)
