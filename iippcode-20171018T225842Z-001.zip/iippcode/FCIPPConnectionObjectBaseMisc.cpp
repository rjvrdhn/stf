// FCIPPConnectionObjectBaseMisc.cpp: implementation of the CFCIPPConnectionObjectBaseMisc class.

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	A macro that defines window 32 lean and mean. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers, Needed with CUPS

#include <windows.h>
#include "http-private.h"   // Cups external library
#include <string>
#include <vector>
using namespace std;

#include "StringExtensions.h"

#include "FCIPPConnectionObjectBaseMisc.h"
#include "DeviceMediaCatalogUtilities.h"
#include "FCIPPDefines.h"
#include "FCPaperTypeUtilities.h"
#include "StringUtils.h"


////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Hashpjws the given datum. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="datum">	The datum. </param>
///
/// <returns>	An int. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

unsigned int hashpjw(const char* datum)
{
	unsigned int hash_value, i;

	for (hash_value = 0;*datum;++datum)
	{
		hash_value = (hash_value << ONE_EIGHTH) + *datum;
		if ((i = hash_value & HIGH_BITS ) != 0)
		{
			hash_value = (hash_value ^ (i >> THREE_QUARTERS)) & ~HIGH_BITS;
		}
	}

	return ( hash_value );
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Initialises the keyword enum hash table. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="tableName">	Name of the table. </param>
/// <param name="pTable">   	[in,out] If non-null, the table. </param>
/// <param name="len">			The length. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void InitKeywordEnumHashTable(const char* tableName, KEYWORDENUMHASHTBL *pTable, int len)
{
	for (int i=0;i<len;i++)
	{
		pTable[i].hashVal = hashpjw(pTable[i].keyword);
	}

	// Make sure that there are not duplicate hash generated*/
	for (int i=0;i<len-1;i++)
	{
		for (int j=(i+1);j<len ;j++)
		{
			if (pTable[i].hashVal == pTable[j].hashVal)
			{
				// We Have a duplicate NOT GOOD
				CLogUtils::LOG_UTILS_EX(eDEBUG, "tableName= %s\nDuplicate hashVal %s and %s (i=%d,j=%d)", tableName, pTable[i].keyword, pTable[j].keyword, i, j);
				// TODO Resolve this
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Searches for the first enum value. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pTable">  	[in,out] If non-null, the table. </param>
/// <param name="tableLen">	Length of the table. </param>
/// <param name="hash">	   	The hash. </param>
///
/// <returns>	The found enum value. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

int FindEnumVal(KEYWORDENUMHASHTBL *pTable, int tableLen, int hash)
{
	int uiError = -1;

	for (int i=0;i<tableLen;i++)
	{
		if (pTable[i].hashVal == hash)
		{
			uiError = pTable[i].enumVal;
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Searches for the first string identifier. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pTable">  	[in,out] If non-null, the table. </param>
/// <param name="tableLen">	Length of the table. </param>
/// <param name="hash">	   	The hash. </param>
///
/// <returns>	null if it fails, else the found string identifier. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

char* FindStringID(KEYWORDENUMHASHTBL *pTable, int tableLen, int hash)
{
	char* uiError = NULL;

	for (int i=0;i<tableLen;i++)
	{
		if (pTable[i].hashVal == hash)
		{
			uiError = (char*) pTable[i].string_id;
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Initialises the hash tables. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

void InitHashTables()
{
	int len = 0;

	len = sizeof(gPrinterStateReasons)/sizeof(gPrinterStateReasons[0]);
	InitKeywordEnumHashTable("gPrinterStateReasons", gPrinterStateReasons, len);

	len = sizeof(gJobStateReasons)/sizeof(gJobStateReasons[0]);
	InitKeywordEnumHashTable("gJobStateReasons", gJobStateReasons, len);
}

/*
void httpFlush1(http_t *http)
{
	fd_set	input;			// Input set for select()
	struct timeval timeout;	// Timeout
	char buffer[4096];
	int nbytes;

	if (http == NULL)
	{
		return ;
	}

	http->data_remaining = 0;
	http->used = 0;

	while(1)
	{
		FD_ZERO(&input);
		FD_SET((u_int)http->fd, &input);

		timeout.tv_sec = 0;
		timeout.tv_usec = 0;
		if (select(http->fd + 1, &input, NULL, NULL, &timeout) > 0)
		{
			if ((nbytes = recv(http->fd, buffer, sizeof(buffer), 0)) <= 0)
			{
				break;
			}
		}
		else
		{
			break;
		}
	}
}

// 'httpCheck()' - Check to see if there is a pending response from the server.
// O - 0 = no data, 1 = data available
int httpCheck1(http_t *http)		// I - HTTP connection
{
	fd_set	input;			// Input set for select()
	struct timeval timeout;	// Timeout

	// First see if there is data in the buffer...
	if (http == NULL)
		return (0);

	// Then try doing a select() to poll the socket...
	FD_ZERO(&input);
	FD_SET((u_int)http->fd, &input);

	timeout.tv_sec = 0;
	timeout.tv_usec = 0;

	return (select(http->fd + 1, &input, NULL, NULL, &timeout) > 0);
}
*/

string CapitalizeFirstChar(string strInput)
{
	string strOutput = strInput;
	string strFirstChar = strOutput.substr(0, 1);
	CStringUtils::MakeUpper(strFirstChar);
	strOutput.replace(0, 1, strFirstChar);
	return strOutput;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets number jobs in list. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pResponse">  	[in,out] If non-null, the response. </param>
/// <param name="strDeviceID">	Identifier for the device. </param>
///
/// <returns>	The number jobs in list. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

int GetNumJobsInList(ipp_t *pResponse, string strDeviceID)
{
	int nCount = 0;
	ipp_attribute_t *attr = NULL;

	if (pResponse)
	{
		for (attr = pResponse->attrs;attr != NULL;attr = attr->next)
		{
			//Skip leading attributes until we hit a job...
			while (attr != NULL && attr->group_tag != IPP_TAG_JOB)
			{
				attr = attr->next;
			}
			if (attr == NULL)
			{
				break;
			}

			while (attr != NULL && attr->group_tag == IPP_TAG_JOB)
			{
				attr = attr->next;
			}
			nCount++;
			if (attr == NULL)
			{
				break;
			}
		}
	}

	return nCount;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Enumerate printer state reason from message. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pBuffer">	[in,out] If non-null, the buffer. </param>
/// <param name="pReason">	[in,out] If non-null, the reason. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void EnumeratePrinterStateReasonFromMsg(char* pBuffer, IPPPRINTERSTATEREASONSTRUCT *pReason)
{
	// At this point Printer State Reason is already set
	// Extract Printer state and add to the printer-state-reason
	if (pReason->nCount == 1)
	{
		if (pReason->Reasons[0] == PRT_STATE_REASON_NONE 
			|| pReason->Reasons[0] == PRT_STATE_REASON_NONE_REPORT
			|| pReason->Reasons[0] == PRT_STATE_REASON_NONE_WARNING
			|| pReason->Reasons[0] == PRT_STATE_REASON_NONE_ERROR)
		{
			pReason->nCount = 0;
		}
	}

	int len = sizeof(gMapMsgToStateReason)/sizeof(gMapMsgToStateReason[0]);
	for (int i=0;i<len;i++)
	{
		if (strstr(pBuffer, gMapMsgToStateReason[i].message))
		{
			pReason->Reasons[pReason->nCount++] = gMapMsgToStateReason[i].enumVal;
		}
	}

	if (pReason->nCount == 0)
	{
		pReason->Reasons[pReason->nCount++] = PRT_STATE_REASON_NONE;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Free detailed message structure. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pMsg">	[in,out] If non-null, the message. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void FreeDetailedMsgStruct(PRTIPPDETAILEDMSG *pMsg)
{
	PRTIPPDETAILEDMSG pPtr = NULL;

	if (pMsg && *pMsg)
	{
		pPtr = *pMsg;
		for (int i=0;i<pPtr->count;i++)
		{
			if (pPtr->msg[i])
			{
				free(pPtr->msg[i]);
			}
		}
		free(pPtr->msg);

		if (pPtr->state_msg)
		{
			free(pPtr->state_msg);
		}

		free(pPtr);
		*pMsg = NULL;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Creates detailed message structure. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="numMsg">	Number of messages. </param>
///
/// <returns>	The new detailed message structure. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

PRTIPPDETAILEDMSG CreateDetailedMsgStruct(int numMsg)
{
	PRTIPPDETAILEDMSG ptr = NULL;

	if (numMsg > 0)
	{
		ptr = (PRTIPPDETAILEDMSG)calloc(1, sizeof(IPPDETAILEDMSG));
		if (ptr)
		{
			ptr->msg = (char* *)calloc(numMsg, sizeof(char* ));
			if (!ptr->msg)
			{
				free(ptr);
				ptr = NULL;
				CLogUtils::LOG_UTILS_DEBUG("CreateDetailedMsgStruct: Cannot allocate the PRTIPPDETAILEDMSG msg");
			}
		}
		else
			CLogUtils::LOG_UTILS_DEBUG("CreateDetailedMsgStruct: Cannot allocate a PRTIPPDETAILEDMSG struct");

	}

	if (ptr)
		ptr->state_msg = NULL;

	return ptr;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Shows the attribute. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="prefix">	The prefix. </param>
/// <param name="attr">  	[in,out] If non-null, the attribute. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void ShowAttribute(int prefix, ipp_attribute_t *attr)
{
	char prefixStr[128];
	if (!attr)
	{
		printf(" attr == NULL\n");
		return ;
	}

	memset(prefixStr, '\t', prefix);
	prefixStr[prefix] = '\0';

	printf("%sAttribute = %s ( Num Values = %d)\n", prefixStr, attr->name, attr->num_values);
	for (int j=0;j<attr->num_values;j++)
	{
		switch (attr->value_tag)
		{
		case IPP_TAG_INTEGER :
		case IPP_TAG_ENUM :
			printf( "%s iValue = %d\n", prefixStr, attr->values[j].integer);
			break;
		case IPP_TAG_BOOLEAN:
			printf( "%s iValue = %d\n", prefixStr, attr->values[j].boolean);
			break;
		case IPP_TAG_TEXT :
		case IPP_TAG_NAME :
		case IPP_TAG_KEYWORD :
		case IPP_TAG_STRING :
		case IPP_TAG_URI :
		case IPP_TAG_URISCHEME :
		case IPP_TAG_CHARSET :
		case IPP_TAG_LANGUAGE :
		case IPP_TAG_MIMETYPE :
			printf( "%s sValue = %s\n", prefixStr, attr->values[j].string.text);
			break;
		case IPP_TAG_NOVALUE:
			printf( "%s sValue = %s\n", prefixStr, "No Value");
			break;
		case IPP_TAG_RANGE :
			printf( "%s rValue = %d to %d\n", prefixStr, attr->values[j].range.lower,
				attr->values[j].range.upper	);
			break;
		case IPP_TAG_BEGIN_COLLECTION:
			DumpCollection(prefix, attr->values[j].collection);

			break;
		default:
			printf("%s attr->value_tag = %d\n", prefixStr, attr->value_tag);
		}
	}

	printf("\n");
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Dumps a collection. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="prefix">	 	The prefix. </param>
/// <param name="collection">	[in,out] If non-null, the collection. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void DumpCollection(int prefix, ipp_t *collection)
{
	ipp_attribute_t *attr = NULL;
	char prefixStr[128];

	prefix++;

	memset(prefixStr, '\t', prefix);
	prefixStr[prefix] = '\0';

	if (collection)
	{
		printf("%s COLLECTION BEGIN....\n", prefixStr);
		for (attr = collection->attrs;;attr = attr->next)
		{
			ShowAttribute(prefix, attr);
			if (attr == collection->last)
				break;
		}
		printf("%s COLLECTION END....\n", prefixStr);

	}
	else
	{
		printf("No Collection ... error\n");
	}

	prefix--;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Dumps the attributes. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pRequest">	[in,out] If non-null, the request. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void DumpAttributes(ipp_t *pRequest)
{
	int i = 0;
	int prefix = 1;
	ipp_attribute_t *attr = NULL;

	for (attr = pRequest->attrs, i=0;;attr = attr->next, i++)
	{
		ShowAttribute(prefix,attr);
		if (attr == pRequest->last)
			break;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sets ipp printer state. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="attr">  	[in,out] If non-null, the attribute. </param>
/// <param name="pState">	[in,out] If non-null, the state. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void SetIPPPrinterState(ipp_attribute_t *attr, IPPPRINTERSTATE* pState)
{
	ipp_pstate_t state = (ipp_pstate_t)attr->values[0].integer;

	switch ((int)state)
	{
		case IPP_PSTATE_IDLE:
			*pState = IPP_PRT_STATE_IDLE;
			break;
		case IPP_PSTATE_PROCESSING:
			*pState = IPP_PRT_STATE_PROCESSING;
			break;
		case IPP_PSTATE_STOPPED:
			*pState = IPP_PRT_STATE_STOPPED;
			break;
		default:
			// See Don if this happens. We may want to add more cases.
			CLogUtils::LOG_UTILS_EX(eDEBUG, "Unknown printer state = %d", state);
			*pState = IPP_PRT_STATE_UNKNOWN;
			break;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sets ipp printer state reason. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="attr">   	[in,out] If non-null, the attribute. </param>
/// <param name="pReason">	[in,out] If non-null, the reason. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void SetIPPPrinterStateReason(ipp_attribute_t *attr, IPPPRINTERSTATEREASONSTRUCT *pReason)
{
	unsigned int valHash = 0;
	int tableSize = sizeof(gPrinterStateReasons)/sizeof(gPrinterStateReasons[0]);

	pReason->nCount = 0;

	for (int i=0;i<attr->num_values && i<64;i++, pReason->nCount++ )
	{
		valHash = hashpjw(attr->values[i].string.text);

		pReason->Reasons[pReason->nCount] = 
			FindEnumVal(gPrinterStateReasons, tableSize, valHash);

		strncpy(pReason->Strings[pReason->nCount],
			attr->values[i].string.text, 255);

		// if the source string was >=256 char, the dest string won't be
		// null-terminated. we'll "fix" that here:
		pReason->Strings[pReason->nCount][255]='\0';

		pReason->String_IDs[pReason->nCount] = (UINT)FindStringID(
			gPrinterStateReasons, tableSize, valHash);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Dumps a job information 3. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pJobInfo">	Information describing the job. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void DumpJobInfo3(PTRIPPJOBINFO_3 pJobInfo)
{
	static const double hundredths_of_a_mm_per_point = 2540.0/72.0;
	FILE *fp = NULL;

	if (pJobInfo && ((fp = fopen("c:\\last_jobinfo3.txt", "r+t")) != NULL))
	{
		fprintf(fp, "   job ID: %d\n", pJobInfo->jobID);
		fprintf(fp, "     name: %s\n", pJobInfo->jobName);
		fprintf(fp, "      URL: %s\n", pJobInfo->jobUrl);
		fprintf(fp, "   copies: %d\n", pJobInfo->num_copies);
		fprintf(fp, "num media: %d\n", pJobInfo->num_media);
		for (int i=0;i<pJobInfo->num_media;i++)
		{
			fprintf(fp, "media %d:\n", i);
			fprintf(fp, "           key: %s\n", pJobInfo->media[i].info.key);
			fprintf(fp, "          desc: %s\n", pJobInfo->media[i].info.description);
			fprintf(fp, "         color: %s\n", pJobInfo->media[i].info.color);
			fprintf(fp, "          type: %s\n", pJobInfo->media[i].info.type);
			fprintf(fp, "    preprinted: %s\n", pJobInfo->media[i].info.pre_printed);
			fprintf(fp, "    hole count: %d\n", pJobInfo->media[i].info.hole_count);
			fprintf(fp, "   order count: %d\n", pJobInfo->media[i].info.order_count);
			fprintf(fp, "          size: %d x %d (%d x %d points)\n",
				pJobInfo->media[i].info.size.x_dim,
				pJobInfo->media[i].info.size.y_dim,
				(int)((pJobInfo->media[i].info.size.x_dim /
				hundredths_of_a_mm_per_point) + 0.5),
				(int)((pJobInfo->media[i].info.size.y_dim /
				hundredths_of_a_mm_per_point) + 0.5));
			fprintf(fp, "        weight: %d\n", pJobInfo->media[i].info.weight_metric);
			fprintf(fp, "          info: %s\n", pJobInfo->media[i].info.info);
			fprintf(fp, "      recycled: %s\n", pJobInfo->media[i].info.recycled);
			fprintf(fp, "    num sheets: %d\n", pJobInfo->media[i].counts.sheets);
			fprintf(fp, "   impressions: %d\n\n", pJobInfo->media[i].counts.impressions);
		}
		fclose(fp);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sets ipp job state. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="attr">  	[in,out] If non-null, the attribute. </param>
/// <param name="pState">	[in,out] If non-null, the state. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void SetIPPJobState(ipp_attribute_t* attr, IPPLIB_JOBSTATE* pState)
{
	int val = attr->values[0].integer;

	if (val >= 3 && val <= 9)
	{
		*pState = (IPPLIB_JOBSTATE) (val);
	}
	else
	{
		CLogUtils::LOG_UTILS_EX(eDEBUG, "Got Invalid Job State = %d", val);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sets ipp job state reason. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="attr">   	[in,out] If non-null, the attribute. </param>
/// <param name="pReason">	[in,out] If non-null, the reason. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

void SetIPPJobStateReason(ipp_attribute_t *attr, IPPJOBSTATEREASONSTRUCT *pReason)
{
	unsigned int valHash;
	int tableSize = sizeof(gJobStateReasons)/sizeof(gJobStateReasons[0]);

	pReason->nCount = 0;

	for (int i=0;i<attr->num_values && i<64;i++, pReason->nCount++)
	{
		valHash = hashpjw(attr->values[i].string.text);

		strncpy(pReason->Strings[pReason->nCount], 
			attr->values[i].string.text, 255);
		pReason->Strings[pReason->nCount][255] = 0;

		pReason->Reasons[pReason->nCount] = 
			FindEnumVal(gJobStateReasons, tableSize, valHash);

		pReason->String_IDs[pReason->nCount] = 
			(UINT)FindStringID(gJobStateReasons, tableSize, valHash);
	}
}

/*
void SetIPPPageOverrides(ipp_attribute_t *attr, IPPPAGEOVERRIDEINFO *pOverrides)
{
	ipp_attribute_t* attr_c;

	for (int i=0;i< attr->num_values;i++)
	{
		pOverrides->nCount++;
	}

	if (attr->collection)
	{
		for (attr_c = attr->collection->members;;attr_c = attr_c->next)
		{
			//
			if (attr_c == attr->collection->last)
				break;
		}
	}
	else
	{
		//
	}
}
*/

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets number media ready. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pResponse">	[in,out] If non-null, the response. </param>
///
/// <returns>	The number media ready. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

int GetNumMediaReady(ipp_t *pResponse)
{
	int nCount = 0;
	ipp_attribute_t *attr = NULL;

	if (pResponse)
	{
		attr = ippFindAttribute(pResponse, "media-col-ready", IPP_TAG_BEGIN_COLLECTION);
		if (attr)
		{
			nCount++;
			attr = attr->next;
			while(attr && attr->name[0] == '\0' && attr->value_tag == IPP_TAG_BEGIN_COLLECTION)
			{
				nCount++;
				attr = attr->next;
			}
		}
	}

	CLogUtils::LOG_UTILS_EX(eDEBUG, "GetNumMediaReady: Number of media = %d", nCount);
	return nCount;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Gets media ready information. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="collection">	[in,out] If non-null, the collection. </param>
/// <param name="pInfo">	 	[in,out] If non-null, the information. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT GetMediaReadyInfo(ipp_t *collection, IPPMEDIAREADYINFO *pInfo)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	int nCount = 0;
	ipp_attribute_t *attr = NULL;

	// return early if there is noting to write to
	if (pInfo == NULL || pInfo->key == NULL)
	{
		return IPPLIB_ERROR;
	}

	for (attr = collection->attrs;attr->next != NULL;attr = attr->next)
	{
		if (strcmp(attr->name, "media-key") == 0)
		{
			// if there is a null pointer set pInfo->key to an empty string
			if (attr->values == NULL || 
				attr->values[0].string.text == NULL)
			{
				pInfo->key[0] = '\0';
			}
			else
			{
				strcpy(pInfo->key, attr->values[0].string.text);
			}
			//break;
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Creates media ready list. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pResponse">	 	[in,out] If non-null, the response. </param>
/// <param name="mediaReadyList">	[in,out] If non-null, list of media readies. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CreateMediaReadyList(ipp_t *pResponse, IPPMEDIAREADY **mediaReadyList)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	IPPMEDIAREADYINFO *pInfo;
	ipp_attribute_t *attr = NULL;
	int count = 0;

	if ((NULL == pResponse) || (NULL == mediaReadyList))
	{
		CLogUtils::LOG_UTILS_DEBUG("CreateMediaReadyList: Invalid param");
		return IPPLIB_ERROR;
	}

	*mediaReadyList = NULL;

	IPPMEDIAREADY* list = (IPPMEDIAREADY*)calloc(sizeof(IPPMEDIAREADY), 1);
	if (!list)
	{
		CLogUtils::LOG_UTILS_DEBUG("CreateMediaReadyList: Cannot allocate IPPMEDIAREADY struct.");
		return IPPLIB_MEM_ERROR;
	}

	count = GetNumMediaReady(pResponse);

	if (count > 0)
	{
		list->mInfo = (IPPMEDIAREADYINFO*)calloc(count, sizeof(IPPMEDIAREADYINFO));
		if (list->mInfo)
		{
			attr = ippFindAttribute(pResponse, "media-col-ready", IPP_TAG_BEGIN_COLLECTION);
			pInfo = list->mInfo;
			do
			{
				//uiError = GetMediaReadyInfo(attr->collection, pInfo);
				if (uiError != IPPLIB_SUCCESS)
					break;

				list->nCount++;
				pInfo++;
				attr = attr->next;
			}while( attr && attr->name[0] == '\0' && attr->value_tag == IPP_TAG_BEGIN_COLLECTION);

		}
		else
		{
			CLogUtils::LOG_UTILS_DEBUG("CreateMediaReadyList: Cannot allocate IPPMEDIAREADYINFO struct.");
			uiError = IPPLIB_MEM_ERROR;
		}
	}

	if (uiError == IPPLIB_SUCCESS)
	{
		*mediaReadyList = list;
	}
	else
	{
		if (list)
		{
			if (list->mInfo)
			{
				free(list->mInfo);
			}
			free(list);
		}
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Extracts the media size. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="collection"> 	[in,out] If non-null, the collection. </param>
/// <param name="pSize">	  	[in,out] If non-null, the size. </param>
/// <param name="value_index">	Zero-based index of the value. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT ExtractMediaSize(ipp_t *collection, IPP_MEDIA_SIZE *pSize, int value_index)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	ipp_attribute_t *attr = NULL;

	if ((NULL == collection) || (NULL == pSize))
	{
		CLogUtils::LOG_UTILS_DEBUG("ExtractMediaSize: Invalid param");
		return IPPLIB_ERROR;
	}

	if (collection && pSize)
	{
		for (attr = collection->attrs;attr != NULL;attr= attr->next)
		{
			if (strcmp(attr->name, "x-dimension") == 0)
			{
				pSize->x_dim = attr->values[value_index].integer;
			}
			else if (strcmp(attr->name, "y-dimension") == 0)
			{
				pSize->y_dim = attr->values[value_index].integer;
			}

			if (attr == collection->last)
				break;
		}
	}
	else
	{
		CLogUtils::LOG_UTILS_EX(eDEBUG, "ExtractMediaSize: Error: collection (%x), pSize (%x)", collection, pSize);
		uiError = IPPLIB_ERROR;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Extracts the media information. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="collection"> 	[in,out] If non-null, the collection. </param>
/// <param name="pEntry">	  	[in,out] If non-null, the entry. </param>
/// <param name="value_index">	Zero-based index of the value. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT ExtractMediaInfo(ipp_t *collection, IPP_MEDIA_INFO *pEntry, int value_index)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	ipp_attribute_t *attr = NULL;
	string strValue;

	if ((NULL == collection) || (NULL == pEntry))
	{
		CLogUtils::LOG_UTILS_DEBUG("ExtractMediaInfo: Invalid param");
		return IPPLIB_ERROR;
	}

	if (collection && pEntry)
	{
		memset (pEntry, '\0', sizeof(IPP_MEDIA_INFO));
		for (attr = collection->attrs;attr != NULL;attr= attr->next)
		{
			if (strcmp(attr->name, "media-key") == 0 && attr->values[value_index].string.text != NULL)
			{
				strValue = CapitalizeFirstChar(attr->values[value_index].string.text);
				strncpy(pEntry->key, strValue.c_str(), sizeof(pEntry->key)-1);
				pEntry->key[sizeof(pEntry->key)-1] = 0;
			}
			else if (strcmp(attr->name, "media-description") == 0 && attr->values[value_index].string.text != NULL)
			{
				strValue = CapitalizeFirstChar(attr->values[value_index].string.text);
				strncpy(pEntry->description, strValue.c_str(), sizeof(pEntry->description)-1);
				pEntry->description[sizeof(pEntry->description)-1] = 0;
			}
			else if (strcmp(attr->name, "media-color") == 0 && attr->values[value_index].string.text != NULL)
			{
				strValue = CapitalizeFirstChar(attr->values[value_index].string.text);
				strncpy(pEntry->color, strValue.c_str(), sizeof(pEntry->color)-1);
				pEntry->color[sizeof(pEntry->color)-1] = 0;
			}
			else if (strcmp(attr->name, "media-type") == 0 && attr->values[value_index].string.text != NULL)
			{
				strValue = CapitalizeFirstChar(attr->values[value_index].string.text);
				strncpy(pEntry->type, strValue.c_str(), sizeof(pEntry->type)-1);
				pEntry->type[sizeof(pEntry->type)-1] = 0;
			}
			else if (strcmp(attr->name, "media-pre-printed") == 0 && attr->values[value_index].string.text != NULL)
			{
				strValue = CapitalizeFirstChar(attr->values[value_index].string.text);
				strncpy(pEntry->pre_printed, strValue.c_str(), sizeof(pEntry->pre_printed)-1);
				pEntry->pre_printed[sizeof(pEntry->pre_printed)-1] = 0;
			}

			else if (strcmp(attr->name, "media-hole-count") == 0)
			{
				pEntry->hole_count = attr->values[value_index].integer;
			}
			else if (strcmp(attr->name, "media-order-count") == 0)
			{
				pEntry->order_count = attr->values[value_index].integer;
			}
			else if (strcmp(attr->name, "media-size") == 0)
			{
				ExtractMediaSize(attr->values[value_index].collection, &pEntry->size, value_index);
			}
			else if (strcmp(attr->name, "media-weight-metric") == 0)
			{
				pEntry->weight_metric = attr->values[value_index].integer;			
			}
			else if (strcmp(attr->name, "media-info") == 0 && attr->values[value_index].string.text != NULL)
			{
				strValue = CapitalizeFirstChar(attr->values[value_index].string.text);
				strncpy(pEntry->info, strValue.c_str(), sizeof(pEntry->info)-1);			
				pEntry->info[sizeof(pEntry->info)-1] = 0;
			}
			else if (strcmp(attr->name, "media-recycled") == 0 && attr->values[value_index].string.text != NULL)
			{
				strValue = CapitalizeFirstChar(attr->values[value_index].string.text);
				strncpy(pEntry->recycled, strValue.c_str(), sizeof(pEntry->recycled)-1);
				pEntry->recycled[sizeof(pEntry->recycled)-1] = 0;
			}

			if (attr == collection->last)
				break;
		}
	}
	else
	{
		CLogUtils::LOG_UTILS_EX(eDEBUG, "ExtractMediaInfo: Error: collection (%x), pEntry (%x)", collection, pEntry);
		uiError = IPPLIB_ERROR;
	}

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Extracts the mixed media information. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="job_sheets_col_actual">	[in,out] If non-null, the job sheets col actual. </param>
/// <param name="pJobInfo">					Information describing the job. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT ExtractMixedMediaInfo(ipp_attribute_t *job_sheets_col_actual, PTRIPPJOBINFO_3 pJobInfo)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	ipp_attribute_t *attr = NULL;
	int num_media = 0;

	if ((job_sheets_col_actual == NULL) || (pJobInfo == NULL))
		return IPPLIB_ERROR;

	// we are parsing an IPP 1SETOF, which is represented differently
	// than a normal IPP COLLECTION;see RFC3382
	for (int i=0; i<job_sheets_col_actual->num_values; i++)
	{
		if ((attr = ippFindAttribute(job_sheets_col_actual->values[i].collection, "job-sheets", IPP_TAG_NAME)) != NULL)
		{
			sscanf(attr->values[1].string.text,
				"sheets:%d;impressions:%d",
				&pJobInfo->media[num_media].counts.sheets,
				&pJobInfo->media[num_media].counts.impressions);
		}

		if ((attr = ippFindAttribute(job_sheets_col_actual->values[i].collection, "media-col",
			IPP_TAG_BEGIN_COLLECTION)) != NULL)
		{
			ExtractMediaInfo(attr->values[1].collection,
				&pJobInfo->media[num_media].info, 1);
		}

		num_media++;
	}

	pJobInfo->num_media = num_media;

	return uiError;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Executes the update media list operation. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pResponse">		  	[in,out] If non-null, the response. </param>
/// <param name="pstrMediaCatalog">   	[in,out] If non-null, the pstr media catalog. </param>
/// <param name="pMediaTypeUtilities">	[in,out] If non-null, the media type utilities. </param>
/// <param name="pPaperTypeUtilities">	[in,out] If non-null, the paper type utilities. </param>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT DoUpdateMediaList(ipp_t *pResponse, string* pstrMediaCatalog, CMediaUtilities* pMediaTypeUtilities, CPaperTypeUtilities* pPaperTypeUtilities)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	ipp_attribute_t* attrMedia = NULL;
	ipp_attribute_t* attr1 = NULL;
	int iAddUpdate = 0;
	int iEndUpdate = 0;
	CIPPMediaInfo MediaInfo;
	FC_PAPER_TYPE PaperType;
	double dHeightMM;
	double dWidthMM;
	double dHeightPoints;
	double dWidthPoints;
	string strValue;

	CDeviceMediaCatalogUtilities DeviceMediaCatalogUtilities;
	CMediaCatalogEntryArray* pMediaCatalogEntryArray = DeviceMediaCatalogUtilities.GetMediaCatalogEntryArray();
	CMediaCatalogEntry* pMediaCatalogEntry = NULL;

	if (NULL == pResponse)
	{
		CLogUtils::LOG_UTILS_DEBUG("DoUpdateMediaList: Invalid param");
		return IPPLIB_ERROR;
	}

	attrMedia = ippFindAttribute(pResponse, "media-col-database", IPP_TAG_BEGIN_COLLECTION);

	if (!attrMedia)
	{
		CLogUtils::LOG_UTILS_DEBUG("DoUpdateMediaList: media-col-database not found");
		return IPPLIB_ERROR;
	}

	for (attr1 = attrMedia;attr1 != NULL;attr1 = attr1->next)
	{
		if (attr1->value_tag != IPP_TAG_BEGIN_COLLECTION)
		{
			break;
		}

		for (int i=0; i<attr1->num_values; i++)
		{
			uiError = ExtractMediaInfo(attr1->values[i].collection, &MediaInfo, 0);
			bool bTabPage = false;

			if (uiError == IPPLIB_SUCCESS)
			{
				pMediaCatalogEntry = new CMediaCatalogEntry;

				string strID = FormatString("m%d", (int)pMediaCatalogEntryArray->size());
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("Class", "Consumable"));
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("ID", strID));
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("Status", "Available"));
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("MediaType", "Paper"));
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("MediaTypeDetails", "Plain"));
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("MediaUnit", "Sheet"));
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("MediaSetCount", "0"));
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("Texture", "None"));
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("PrintingTechnology", "None"));
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("PrePrinted", "false"));
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("Recycled", "0"));
				pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("UserMediaType", "Plain"));

				if (MediaInfo.key[0] != 0)
				{
					strValue = MediaInfo.key;
					pMediaCatalogEntry->m_MediaCatalogEntryData["ProductID"] = strValue;
					int iStart = (int)strValue.find("[");
					int iEnd = (int)strValue.find("]");
					if ((iStart != -1) && (iEnd != -1))
					{
						strValue = strValue.substr(iStart+1, iEnd-1);
						pMediaCatalogEntry->m_MediaCatalogEntryData["EFI:MID"] = strValue;
					}
				}

				if (MediaInfo.pre_printed[0] != 0)
				{
					strValue = MediaInfo.pre_printed;
					if (!strValue.empty() && (strValue != "Blank"))
						pMediaCatalogEntry->m_MediaCatalogEntryData["PrePrinted"] = "true";
				}

				if (MediaInfo.recycled[0] != 0)
				{
					strValue = MediaInfo.recycled;
					if (!strValue.empty() && (strValue != "None"))
						pMediaCatalogEntry->m_MediaCatalogEntryData["Recycled"] = strValue;
				}

				//if (MediaInfo.info[0] != 0)
				//{
				//	strValue = MediaInfo.info;
				//	CStringUtils::MakeLower(strValue);
				//	if (strValue.find(" tab") != -1)
				//		bTabPage = true;
				//}

				dHeightMM = (double)(MediaInfo.size.y_dim/100.0);
				dWidthMM = (double)(MediaInfo.size.x_dim/100.0);
				dHeightPoints = (double)(dHeightMM/25.4)*72.0;
				dWidthPoints = (double)(dWidthMM/25.4)*72.0;

				PaperType = pPaperTypeUtilities->GetPaperSizeFromMM(dHeightMM, dWidthMM);
				if (PaperType != PT_UNKNOWN)
					pPaperTypeUtilities->GetPaperDimensionsInPoints(PaperType, dHeightPoints, dWidthPoints);

				if (dHeightPoints > dWidthPoints)
				{
					double dTemp = dWidthPoints;
					dWidthPoints = dHeightPoints;
					dHeightPoints = dTemp;
				}

				strValue = FormatString("%1.1f %1.1f", dHeightPoints, dWidthPoints);
				if (!strValue.empty())
					pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("Dimension", strValue));

				if (MediaInfo.order_count > 1)
					bTabPage = true;

				strValue = FormatString("%d", MediaInfo.order_count);
				pMediaCatalogEntry->m_MediaCatalogEntryData["MediaSetCount"] = strValue;

				if (MediaInfo.description[0] != 0)
					pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("DescriptiveName", MediaInfo.description));
				
				if (MediaInfo.type[0] != 0)
				{
					pMediaCatalogEntry->m_MediaCatalogEntryData["MediaTypeDetails"] = MediaInfo.type;

					string strMediaType = MediaInfo.type;
					CStringUtils::Replace(strMediaType, " paper", "");
					pMediaCatalogEntry->m_MediaCatalogEntryData["UserMediaType"] = strMediaType;

					CStringUtils::MakeLower(strMediaType);
					if (strMediaType == "precuttabs")
						bTabPage = true;
				}

				if (MediaInfo.weight_metric > 0)
				{
					strValue = FormatString("%d", MediaInfo.weight_metric);
					pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("Weight", strValue));
				}

				if (MediaInfo.color[0] != 0)
				{
					strValue = MediaInfo.color;
					pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("MediaColorName", strValue));

					// Want/Need to do this later Don
					FC_MEDIA_COLOR mcColor = pMediaTypeUtilities->GetMediaColorFromMediaColorName(strValue);
					COLORREF ColorRef = pMediaTypeUtilities->GetMediaColorReferenceFromMediaColor(mcColor);
					int R = GetRValue(ColorRef);
					int G = GetGValue(ColorRef);
					int B = GetBValue(ColorRef);
					strValue = FormatString("%d %d %d", R, G, B);
					pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("LabColorValue", strValue));
				}

				if (MediaInfo.hole_count > 0)
					pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("HoleType", "Explicit"));
				else
					pMediaCatalogEntry->m_MediaCatalogEntryData.insert(stringMap::value_type("HoleType", "None"));

				if (bTabPage)
				{
					pMediaCatalogEntry->m_MediaCatalogEntryData["UserMediaType"] = "Tabstock";
					pMediaCatalogEntry->m_MediaCatalogEntryData["MediaTypeDetails"] = "PreCutTabs";
				}

				pMediaCatalogEntryArray->push_back(pMediaCatalogEntry);
				MediaInfo.Init();
			}
			else
			{
				break;
			}
		}
	}

	if ((int)pMediaCatalogEntryArray->size() > 0)
	{
		DeviceMediaCatalogUtilities.CreateDeviceMediaCatalogXMLString(*pstrMediaCatalog, pMediaCatalogEntryArray, true);
	}

	return uiError;
}
