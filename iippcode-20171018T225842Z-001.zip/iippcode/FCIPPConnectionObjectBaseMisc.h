// FCIPPConnectionObjectBaseMisc.h
/********************************************************************
*
*  (c) Copyright 2013  
*      Electronics for Imaging, Inc. ("EFI").
*      All Rights Reserved
*
*  EFI products contain certain trade secrets and confidential and
*  proprietary information of EFI.  Use, reproduction, disclosure,
*  distribution by any means are prohibited, except pursuant to
*  a written license from EFI. Modification, translation, reverse
*  engineering, decompiling, disassembling, and creating derivative
*  works based on this software are prohibited, except pursuant to
*  a written license from EFI. Use of copyright notice does not imply
*  publication or disclosure.
*
*  Restricted Rights Legend:
*  Use, duplication, or disclosure by the Government is subject to
*  restrictions as set forth in subparagraph (c)(1)(ii) of The
*  Rights in Technical Data and Computer Software clause in DFARS
*  252.227-7013 or subparagraphs (c)(1) and (2) of the Commercial
*  Computer Software--Restricted Rights at 48 CFR 52.227-19, as
*  applicable.
*
**********************************************************************
*/
#pragma once

#include "cups.h"
#include "ipp.h"
#include "http.h"
#include "FCIPPDefines.h"

class CMediaUtilities;
class CPaperTypeUtilities;

typedef struct 
{
	char message[512];
	int  enumVal;
} MAPMESSAGETOSTATEREASON;

// Make sure that the message is < 512 bytes
static MAPMESSAGETOSTATEREASON gMapMsgToStateReason[]=
{
	"The Print Station is Stopped", PRT_STATE_REASON_STOPPED_WARNING
};

typedef struct
{
	char            keyword[255];
	unsigned int    string_id;
	int             enumVal;
	int    hashVal;
} KEYWORDENUMHASHTBL;

static KEYWORDENUMHASHTBL gPrinterStateReasons[]=
{
	"other",                            211, PRT_STATE_REASON_OTHER,         0,
	"other-report",                     212, PRT_STATE_REASON_OTHER_REPORT,  0,
	"other-warning",                    213, PRT_STATE_REASON_OTHER_WARNING, 0,
	"other-error",                      214, PRT_STATE_REASON_OTHER_ERROR,   0,
	"none",                             215, PRT_STATE_REASON_NONE,          0,
	"none-report",                      216, PRT_STATE_REASON_NONE_REPORT,   0,
	"none-warning",                     217, PRT_STATE_REASON_NONE_WARNING,  0,
	"none-error",                       218, PRT_STATE_REASON_NONE_ERROR,    0,
	"media-needed",                     219, PRT_STATE_REASON_MEDIA_NEEDED,  0,
	"media-needed-report",              220, PRT_STATE_REASON_MEDIA_NEEDED_REPORT,  0,
	"media-needed-warning",             221, PRT_STATE_REASON_MEDIA_NEEDED_WARNING, 0,
	"media-needed-error",               222, PRT_STATE_REASON_MEDIA_NEEDED_ERROR,   0,
	"media-jam",                        223, PRT_STATE_REASON_MEDIA_JAM,         0,
	"media-jam-report",                 224, PRT_STATE_REASON_MEDIA_JAM_REPORT,  0,
	"media-jam-warning",                225, PRT_STATE_REASON_MEDIA_JAM_WARNING, 0,
	"media-jam-error",                  226, PRT_STATE_REASON_MEDIA_JAM_ERROR,   0,
	"moving-to-paused",                 227, PRT_STATE_REASON_MOVING_TO_PAUSED, 0,
	"moving-to-paused-report",          228, PRT_STATE_REASON_MOVING_TO_PAUSED_REPORT,  0,
	"moving-to-paused-warning",         229, PRT_STATE_REASON_MOVING_TO_PAUSED_WARNING, 0,
	"moving-to-paused-error",           230, PRT_STATE_REASON_MOVING_TO_PAUSED_ERROR,   0,
	"stopped",                          231, PRT_STATE_REASON_STOPPED,         0,
	"stopped-report",                   232, PRT_STATE_REASON_STOPPED_REPORT,  0,
	"stopped-warning",                  233, PRT_STATE_REASON_STOPPED_WARNING, 0,
	"stopped-error",                    234, PRT_STATE_REASON_STOPPED_ERROR,   0,
	"paused",                           235, PRT_STATE_REASON_PAUSED,          0,
	"paused-report",                    236, PRT_STATE_REASON_PAUSED_REPORT,   0,
	"paused-warning",                   237, PRT_STATE_REASON_PAUSED_WARNING,  0,
	"paused-error",                     238, PRT_STATE_REASON_PAUSED_ERROR,    0,
	"shutdown",                         239, PRT_STATE_REASON_SHUTDOWN,        0,
	"shutdown-report",                  240, PRT_STATE_REASON_SHUTDOWN_REPORT, 0,
	"shutdown-warning",                 241, PRT_STATE_REASON_SHUTDOWN_WARNING,0,
	"shutdown-error",                   242, PRT_STATE_REASON_SHUTDOWN_ERROR,            0,
	"connecting-to-device",             243, PRT_STATE_REASON_CONNECTING_TO_DEVICE,      0,
	"connecting-to-device-report",      244, PRT_STATE_REASON_CONNECTING_TO_DEVICE_REPORT,      0,
	"connecting-to-device-warning",     245, PRT_STATE_REASON_CONNECTING_TO_DEVICE_WARNING,     0,
	"connecting-to-device-error",       246, PRT_STATE_REASON_CONNECTING_TO_DEVICE_ERROR,       0,
	"timed-out",                        247, PRT_STATE_REASON_TIMED_OUT,              0,
	"timed-out-report",                 248, PRT_STATE_REASON_TIMED_OUT_REPORT,       0,
	"timed-out-warning",                249, PRT_STATE_REASON_TIMED_OUT_WARNING,      0,
	"timed-out-error",                  250, PRT_STATE_REASON_TIMED_OUT_ERROR,        0,
	"stopping",                         251, PRT_STATE_REASON_STOPPING,               0,
	"stopping-report",                  252, PRT_STATE_REASON_STOPPING_REPORT,        0,
	"stopping-warning",                 253, PRT_STATE_REASON_STOPPING_WARNING,       0,
	"stopping-error",                   254, PRT_STATE_REASON_STOPPING_ERROR,         0,
	"stopped-partly",                   255, PRT_STATE_REASON_STOPPED_PARTLY,         0,
	"stopped-partly-report",            256, PRT_STATE_REASON_STOPPED_PARTLY_REPORT,  0,
	"stopped-partly-warning",           257, PRT_STATE_REASON_STOPPED_PARTLY_WARNING, 0,
	"stopped-partly-error",             258, PRT_STATE_REASON_STOPPED_PARTLY_ERROR,   0,
	"toner-low",                        259, PRT_STATE_REASON_TONER_LOW,              0,
	"toner-low-report",                 260, PRT_STATE_REASON_TONER_LOW_REPORT,       0,
	"toner-low-warning",                261, PRT_STATE_REASON_TONER_LOW_WARNING,      0,
	"toner-low-error",                  262, PRT_STATE_REASON_TONER_LOW_ERROR,        0,
	"toner-empty",                      263, PRT_STATE_REASON_TONER_EMPTY,            0,
	"toner-empty-report",               264, PRT_STATE_REASON_TONER_EMPTY_REPORT,     0,
	"toner-empty-warning",              265, PRT_STATE_REASON_TONER_EMPTY_WARNING,    0,
	"toner-empty-error",                266, PRT_STATE_REASON_TONER_EMPTY_ERROR,      0,
	"spool-area-full",                  267, PRT_STATE_REASON_SPOOL_AREA_FULL,        0,
	"spool-area-full-report",           268, PRT_STATE_REASON_SPOOL_AREA_FULL_REPORT, 0,
	"spool-area-full-warning",          269, PRT_STATE_REASON_SPOOL_AREA_FULL_WARNING,0,
	"spool-area-full-error",            270, PRT_STATE_REASON_SPOOL_AREA_FULL_ERROR,  0,
	"cover-open",                       271, PRT_STATE_REASON_COVER_OPEN,             0,
	"cover-open-report",                272, PRT_STATE_REASON_COVER_OPEN_REPORT,      0,
	"cover-open-warning",               273, PRT_STATE_REASON_COVER_OPEN_WARNING,     0,
	"cover-open-error",                 274, PRT_STATE_REASON_COVER_OPEN_ERROR,       0,
	"interlock-open",                   275, PRT_STATE_REASON_INTERLOCK_OPEN,         0,
	"interlock-open-report",            276, PRT_STATE_REASON_INTERLOCK_OPEN_REPORT,  0,
	"interlock-open-warning",           277, PRT_STATE_REASON_INTERLOCK_OPEN_WARNING, 0,
	"interlock-open-error",             278, PRT_STATE_REASON_INTERLOCK_OPEN_ERROR,   0,
	"door-open",                        279, PRT_STATE_REASON_DOOR_OPEN,              0,
	"door-open-report",                 280, PRT_STATE_REASON_DOOR_OPEN_REPORT,       0,
	"door-open-warning",                281, PRT_STATE_REASON_DOOR_OPEN_WARNING,      0,
	"door-open-error",                  282, PRT_STATE_REASON_DOOR_OPEN_ERROR,        0,
	"input-tray-missing",               283, PRT_STATE_REASON_INPUT_TRAY_MISSING,     0,
	"input-tray-missing-report",        284, PRT_STATE_REASON_INPUT_TRAY_MISSING_REPORT,     0,
	"input-tray-missing-warning",       285, PRT_STATE_REASON_INPUT_TRAY_MISSING_WARNING,    0,
	"input-tray-missing-error",         286, PRT_STATE_REASON_INPUT_TRAY_MISSING_ERROR,      0,
	"media-low",                        287, PRT_STATE_REASON_MEDIA_LOW,                     0,
	"media-low-report",                 288, PRT_STATE_REASON_MEDIA_LOW_REPORT,              0,
	"media-low-warning",                289, PRT_STATE_REASON_MEDIA_LOW_WARNING,             0,
	"media-low-error",                  290, PRT_STATE_REASON_MEDIA_LOW_ERROR,               0,
	"media-empty",                      291, PRT_STATE_REASON_MEDIA_EMPTY,                   0,
	"media-empty-report",               292, PRT_STATE_REASON_MEDIA_EMPTY_REPORT,            0,
	"media-empty-warning",              293, PRT_STATE_REASON_MEDIA_EMPTY_WARNING,           0,
	"media-empty-error",                294, PRT_STATE_REASON_MEDIA_EMPTY_ERROR,             0,
	"output-tray-missing",              295, PRT_STATE_REASON_OUTPUT_TRAY_MISSING,           0,
	"output-tray-missing-report",       296, PRT_STATE_REASON_OUTPUT_TRAY_MISSING_REPORT,        0,
	"output-tray-missing-warning",      297, PRT_STATE_REASON_OUTPUT_TRAY_MISSING_WARNING,       0,
	"output-tray-missing-error",        298, PRT_STATE_REASON_OUTPUT_TRAY_MISSING_ERROR,         0,
	"output-area-almost-full",          299, PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL,           0,
	"output-area-almost-full-report",   300, PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL_REPORT,    0,
	"output-area-almost-full-warning",  301, PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL_WARNING,   0,
	"output-area-almost-full-error",    302, PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL_ERROR,     0,
	"output-area-full",                 303, PRT_STATE_REASON_OUTPUT_AREA_FULL,                  0,
	"output-area-full-report",          304, PRT_STATE_REASON_OUTPUT_AREA_FULL_REPORT,           0,
	"output-area-full-warning",         305, PRT_STATE_REASON_OUTPUT_AREA_FULL_WARNING,          0,
	"output-area-full-error",           306, PRT_STATE_REASON_OUTPUT_AREA_FULL_ERROR,            0,
	"marker-supply-low",                307, PRT_STATE_REASON_MARKER_SUPPLY_LOW,                 0,
	"marker-supply-low-report",         308, PRT_STATE_REASON_MARKER_SUPPLY_LOW_REPORT,          0,
	"marker-supply-low-warning",        309, PRT_STATE_REASON_MARKER_SUPPLY_LOW_WARNING,         0,
	"marker-supply-low-error",          310, PRT_STATE_REASON_MARKER_SUPPLY_LOW_ERROR,           0,
	"marker-supply-empty",              311, PRT_STATE_REASON_MARKER_SUPPLY_EMPTY,               0,
	"marker-supply-empty-report",       312, PRT_STATE_REASON_MARKER_SUPPLY_EMPTY_REPORT,        0,
	"marker-supply-empty-warning",      313, PRT_STATE_REASON_MARKER_SUPPLY_EMPTY_WARNING,       0,
	"marker-supply-empty-error",        314, PRT_STATE_REASON_MARKER_SUPPLY_EMPTY_ERROR,         0,
	"marker-waste-almost-full",         315, PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL,          0,
	"marker-waste-almost-full-report",  316, PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL_REPORT,   0,
	"marker-waste-almost-full-warning", 317, PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL_WARNING,  0,
	"marker-waste-almost-full-error",   318, PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL_ERROR,    0,
	"marker-waste-full",                319, PRT_STATE_REASON_MARKER_WASTE_FULL,         0,
	"marker-waste-full-report",         320, PRT_STATE_REASON_MARKER_WASTE_FULL_REPORT,  0,
	"marker-waste-full-warning",        321, PRT_STATE_REASON_MARKER_WASTE_FULL_WARNING, 0,
	"marker-waste-full-error",          322, PRT_STATE_REASON_MARKER_WASTE_FULL_ERROR,   0,
	"fuser-over-temp",                  323, PRT_STATE_REASON_FUSER_OVER_TEMP,           0,
	"fuser-over-temp-report",           324, PRT_STATE_REASON_FUSER_OVER_TEMP_REPORT,    0,
	"fuser-over-temp-warning",          325, PRT_STATE_REASON_FUSER_OVER_TEMP_WARNING,   0,
	"fuser-over-temp-error",            326, PRT_STATE_REASON_FUSER_OVER_TEMP_ERROR,     0,
	"fuser-under-temp",                 327, PRT_STATE_REASON_FUSER_UNDER_TEMP,          0,
	"fuser-under-temp-report",          328, PRT_STATE_REASON_FUSER_UNDER_TEMP_REPORT,   0,
	"fuser-under-temp-warning",         329, PRT_STATE_REASON_FUSER_UNDER_TEMP_WARNING,  0,
	"fuser-under-temp-error",           330, PRT_STATE_REASON_FUSER_UNDER_TEMP_ERROR,    0,
	"opc-near-eol",                     331, PRT_STATE_REASON_OPC_NEAR_EOL,              0,
	"opc-near-eol-report",              332, PRT_STATE_REASON_OPC_NEAR_EOL_REPORT,       0,
	"opc-near-eol-warning",             333, PRT_STATE_REASON_OPC_NEAR_EOL_WARNING,      0,
	"opc-near-eol-error",               334, PRT_STATE_REASON_OPC_NEAR_EOL_ERROR,        0,
	"opc-life-over",                    335, PRT_STATE_REASON_OPC_LIFE_OVER,             0,
	"opc-life-over-report",             336, PRT_STATE_REASON_OPC_LIFE_OVER_REPORT,      0,
	"opc-life-over-warning",            337, PRT_STATE_REASON_OPC_LIFE_OVER_WARNING,     0,
	"opc-life-over-error",              338, PRT_STATE_REASON_OPC_LIFE_OVER_ERROR,       0,
	"developer-low",                    339, PRT_STATE_REASON_DEVELOPER_LOW,             0,
	"developer-low-report",             340, PRT_STATE_REASON_DEVELOPER_LOW_REPORT,      0,
	"developer-low-warning",            341, PRT_STATE_REASON_DEVELOPER_LOW_WARNING,     0,
	"developer-low-error",              342, PRT_STATE_REASON_DEVELOPER_LOW_ERROR,       0,
	"developer-empty",                  343, PRT_STATE_REASON_DEVELOPER_EMPTY,           0,
	"developer-empty-report",           344, PRT_STATE_REASON_DEVELOPER_EMPTY_REPORT,    0,
	"developer-empty-warning",          345, PRT_STATE_REASON_DEVELOPER_EMPTY_WARNING,   0,
	"developer-empty-error",            346, PRT_STATE_REASON_DEVELOPER_EMPTY_ERROR,     0,
	"interpreter-resource-unavailable", 347, PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE,                  0,
	"interpreter-resource-unavailable-report",  348, PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE_REPORT,   0,
	"interpreter-resource-unavailable-warning", 349, PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE_WARNING,  0,
	"interpreter-resource-unavailable-error",   350, PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE_ERROR,    0,
};

static KEYWORDENUMHASHTBL gJobStateReasons[]=
{
	"none",                         181, IPP_JOB_STATE_REASON_NONE,                           0,
	"job-incoming",                 182, IPP_JOB_STATE_REASON_JOB_INCOMING,                   0,
	"job-data-insufficient",        183, IPP_JOB_STATE_REASON_JOB_DATA_INSUFFICIENT,          0,
	"document-access-error",        184, IPP_JOB_STATE_REASON_DOCUMENT_ACCESS_ERROR,          0,
	"submission-interrupted",       185, IPP_JOB_STATE_REASON_SUBMISSION_INTERRUPTED,         0,
	"job-outgoing",                 186, IPP_JOB_STATE_REASON_JOB_OUTGOING,                   0,
	"job-hold-until-specified",     187, IPP_JOB_STATE_REASON_JOB_HOLD_UNTIL_SPECIFIED,       0,
	"resources-are-not-ready",      188, IPP_JOB_STATE_REASON_RESOURCES_ARE_NOT_READY,        0,
	"printer-stopped-partly",       189, IPP_JOB_STATE_REASON_PRINTER_STOPPED_PARTLY,         0,
	"printer-stopped",              190, IPP_JOB_STATE_REASON_PRINTER_STOPPED,                0,
	"job-interpreting",             191, IPP_JOB_STATE_REASON_JOB_INTERPRETING,               0,
	"job-queued",                   192, IPP_JOB_STATE_REASON_JOB_QUEUED,                     0,
	"job-transforming",             193, IPP_JOB_STATE_REASON_JOB_TRANSFORMING,               0,
	"job-queued-for-marker",        194, IPP_JOB_STATE_REASON_JOB_QUEUED_FOR_MARKER,          0,
	"job-printing",                 195, IPP_JOB_STATE_REASON_JOB_PRINTING,                   0,
	"job-canceled-by-user",         196, IPP_JOB_STATE_REASON_JOB_CANCELED_BY_USER,           0,
	"job-canceled-by-operator",     197, IPP_JOB_STATE_REASON_JOB_CANCELED_BY_OPERATOR,       0,
	"job-canceled-at-device",       198, IPP_JOB_STATE_REASON_JOB_CANCELED_AT_DEVICE,         0,
	"aborted-by-system",            199, IPP_JOB_STATE_REASON_ABORTED_BY_SYSTEM,              0,
	"unsupported-compression",      200, IPP_JOB_STATE_REASON_UNSUPPORTED_COMPRESSION,        0,
	"compression-error",            201, IPP_JOB_STATE_REASON_COMPRESSION_ERROR,              0,
	"unsupported-document-format",  202, IPP_JOB_STATE_REASON_UNSUPPORTED_DOCUMENT_FORMAT,    0,
	"document-format-error",        203, IPP_JOB_STATE_REASON_DOCUMENT_FORMAT_ERROR,          0,
	"processing-to-stop-point",     204, IPP_JOB_STATE_REASON_PROCESSING_TO_STOP_POINT,       0,
	"service-off-line",             205, IPP_JOB_STATE_REASON_SERVICE_OFF_LINE,               0,
	"job-completed-successfully",   206, IPP_JOB_STATE_REASON_JOB_COMPLETED_SUCCESSFULLY,     0,
	"job-completed-with-warnings",  207, IPP_JOB_STATE_REASON_JOB_COMPLETED_WITH_WARNINGS,    0,
	"job-completed-with-errors",    208, IPP_JOB_STATE_REASON_JOB_COMPLETED_WITH_ERRORS,      0,
	"job-restartable",              209, IPP_JOB_STATE_REASON_JOB_RESTARTABLE,                0,
	"queued-in-device",             210, IPP_JOB_STATE_REASON_QUEUED_IN_DEVICE,               0,
	"other",			            351, IPP_JOB_STATE_REASON_OTHER,						  0,
};

static const char* requested[] =	/* Requested attributes */
{
	"job-id",
	"job-uri",
	"job-state",
	"job-state-reasons",
	"job-printer-uri",
	"job-originating-user-name",
	"job-name"
};

static const char* jobListAttributesRequested[] =
{
	"document-format",
	"job-id",
	"job-k-octets",
	"job-name",
	"job-originating-user-name",
	"job-printer-uri",
	"job-priority",
	"job-state",
	"time-at-completed",
	"time-at-creation",
	"time-at-processing"
};

static const char* jobDescription11[] =
{
//	"attributes-charset",
//	"attributes-natural-language",
	"copies",
	"date-time-at-completed",
	"date-time-at-creation",
	"date-time-at-processing",
	"finishings",
	"job-detailed-status-messages",
	"job-document-access-errors",
	"job-hold-until",
	"job-id",
	"job-impressions",
	"job-impressions-completed",
	"job-k-octets",
	"job-k-octets-processed",
	"job-media-sheets",
	"job-media-sheets-completed",
	"job-message-from-operator",
	"job-more-info",
	"job-name",
	"job-originating-user-name",
	"job-printer-up-time",
	"job-printer-uri",
	"job-priority",
	"job-sheets",
	"job-state",
	"job-state-message",
	"job-state-reasons",
	"media",
	"multiple-document-handling",
	"number-of-intervening-jobs",
	"number-up",
	"orientation-requested",
	"output-device-assigned",
	"page-ranges",
	"printer-resolution",
	"print-quality",
	"sides",
	"time-at-completed",
	"time-at-creation",
	"time-at-processing"
};

static const char* jobDescription20[] =
{
	"compression-supplied",
	"copies-actual",
	"cover-back-actual",
	"cover-front-actual",
	"current-page-order",
	"date-time-at-completed",
	"date-time-at-creation",
	"date-time-at-processing",
	"destination-statuses",
	"document-charset-supplied",
	"document-digital-signature-supplied",
	"document-format-details-supplied",
	"document-format-supplied",
	"document-message-supplied",
	"document-metadata",
	"document-name-supplied",
	"document-natural-language-supplied",
	"document-overrides-actual",
	"errors-count",
	"finishings-actual",
	"finishings-col-actual",
	"force-front-side-actual",
	"imposition-template-actual",
	"impressions-completed-current-copy",
	"insert-sheet-actual",
	"job-account-id-actual",
	"job-accounting-sheets-actual",
	"job-accounting-user-id-actual",
	"job-attribute-fidelity",
	"job-charge-info",			/* CUPS extension */
	"job-collation-type",
	"job-collation-type-actual",
	"job-copies-actual",
	"job-cover-back-actual",
	"job-cover-front-actual",
	"job-detailed-status-message",
	"job-document-access-errors",
	"job-error-sheet-actual",
	"job-finishings-actual",
	"job-finishings-col-actual",
	"job-hold-until-actual",
	"job-id",
	"job-impressions",
	"job-impressions-completed",
	"job-k-octets",
	"job-k-octets-processed",
	"job-mandatory-attributes",
	"job-media-progress",		/* CUPS extension */
	"job-media-sheets",
	"job-media-sheets-completed",
	"job-message-from-operator",
	"job-more-info",
	"job-name",
	"job-originating-host-name",	/* CUPS extension */
	"job-originating-user-name",
	"job-originating-user-uri",
	"job-pages",
	"job-pages-completed",
	"job-pages-completed-current-copy",
	"job-printer-state-message",	/* CUPS extension */
	"job-printer-state-reasons",	/* CUPS extension */
	"job-printer-up-time",
	"job-printer-uri",
	"job-priority-actual",
	"job-save-printer-make-and-model",
	"job-sheet-message-actual",
	"job-sheets-actual",
	"job-sheets-col-actual",
	"job-state",
	"job-state-message",
	"job-state-reasons",
	"job-uri",
	"job-uuid",
	"media-actual",
	"media-col-actual",
	"media-check-input-tray-actual",
	"multiple-document-handling-actual",
	"number-of-documents",
	"number-of-intervening-jobs",
	"number-up-actual",
	"orientation-requested-actual",
	"original-requesting-user-name",
	"output-bin-actual",
	"output-device-assigned",
	"overrides-actual",
	"page-delivery-actual",
	"page-order-received-actual",
	"page-ranges-actual",
	"presentation-direction-number-up-actual",
	"print-color-mode-actual",
	"print-content-optimize-actual",
	"print-quality-actual",
	"print-rendering-intent-actual",
	"print-scaling-actual",		/* IPP Paid Printing */
	"printer-resolution-actual",
	"separator-sheets-actual",
	"sheet-collate-actual",
	"sheet-completed-copy-number",
	"sheet-completed-document-number",
	"sides-actual",
	"time-at-completed",
	"time-at-creation",
	"time-at-processing",
	"warnings-count",
	"x-image-position-actual",
	"x-image-shift-actual",
	"x-side1-image-shift-actual",
	"x-side2-image-shift-actual",
	"y-image-position-actual",
	"y-image-shift-actual",
	"y-side1-image-shift-actual",
	"y-side2-image-shift-actual"
};

static const char* gja_requested[] =	/* Requested attributes */
{
	"job-id",
	"job-uri",
	"job-state",
	"job-state-reasons",
	"job-k-octets",
	"job-impressions-completed",
	"job-media-sheets-completed",
	"job-printer-uri",
	"job-originating-user-name",
	"job-name",
	"copies",
	"time-at-creation",
	"time-at-processing",
	"time-at-completed",
	"date-time-at-creation",
	"date-time-at-processing",
	"date-time-at-completed",
	"job-detailed-status-messages"//,
	//  "page-overrides"
};

static const char* gja2_requested[] =	/* Requested attributes */
{
	"job-id",
	"job-uri",
	"job-name",
	"copies",
	"media-col",
	"job-sheets-col-actual" /* Oce VP6xxx series-specific extension */
};

static const char* gpa_state_requested[] =	/* Requested attributes */
{
	"printer-state",
	"printer-state-reasons",
	"printer-detailed-status-messages",
	"printer-state-message"
}  ;

static const char* gpa_ready_requested[] =	/* Requested attributes */
{
	"media-col-ready"
}  ;

static const char* gpa_info_requested[] =	/* Requested attributes */
{
	"printer-make-and-model",
	"printer-location",
	"printer-name",
	"printer-info"
}  ;

static const char* gpa_media_list_requested[] =	/* Requested attributes */
{
	"media-col-database"
}  ;

extern unsigned int hashpjw(const char* datum);
extern void InitKeywordEnumHashTable(const char* tableName, KEYWORDENUMHASHTBL *pTable, int len);
extern int FindEnumVal(KEYWORDENUMHASHTBL *pTable, int tableLen, int hash);
extern char* FindStringID(KEYWORDENUMHASHTBL *pTable, int tableLen, int hash);
extern const char* password_cb(const char* prompt);
extern void InitHashTables();
//extern void httpFlush1(http_t *http);
//extern int httpCheck1(http_t *http);
extern int GetNumJobsInList(ipp_t *pResponse, string strDeviceID);
extern void EnumeratePrinterStateReasonFromMsg(char* pBuffer, IPPPRINTERSTATEREASONSTRUCT *pReason);
extern void FreeDetailedMsgStruct(PRTIPPDETAILEDMSG *pMsg);
extern PRTIPPDETAILEDMSG CreateDetailedMsgStruct(int numMsg);
extern void ShowAttribute(int prefix, ipp_attribute_t *attr);
extern void DumpCollection(int prefix, ipp_t *collection);
extern void DumpAttributes(ipp_t *pRequest);
extern void SetIPPPrinterState(ipp_attribute_t *attr, IPPPRINTERSTATE* pState);
extern void SetIPPPrinterStateReason(ipp_attribute_t *attr, IPPPRINTERSTATEREASONSTRUCT *pReason);
extern void DumpJobInfo3(PTRIPPJOBINFO_3 pJobInfo);
extern void SetIPPJobState(ipp_attribute_t* attr, IPPLIB_JOBSTATE* pState);
extern void SetIPPJobStateReason(ipp_attribute_t *attr, IPPJOBSTATEREASONSTRUCT *pReason);
//extern void SetIPPPageOverrides(ipp_attribute_t *attr, IPPPAGEOVERRIDEINFO *pOverrides);
extern int GetNumMediaReady(ipp_t *pResponse);
extern IPPLIB_RESULT GetMediaReadyInfo(ipp_t *collection, IPPMEDIAREADYINFO *pInfo);
extern IPPLIB_RESULT CreateMediaReadyList(ipp_t *pResponse, IPPMEDIAREADY **mediaReadyList);
extern IPPLIB_RESULT ExtractMediaSize(ipp_t *collection, IPP_MEDIA_SIZE *pSize, int value_index);
extern IPPLIB_RESULT ExtractMediaInfo(ipp_t *collection, IPP_MEDIA_INFO *pEntry, int value_index);
extern IPPLIB_RESULT ExtractMixedMediaInfo(ipp_attribute_t *job_sheets_col_actual, PTRIPPJOBINFO_3 pJobInfo);
extern IPPLIB_RESULT DoUpdateMediaList(ipp_t *pResponse, string* pstrMediaCatalog, CMediaUtilities* pMediaTypeUtilities, CPaperTypeUtilities* pPaperTypeUtilities);
