// FCIPPDefines.h
/********************************************************************
*
*  (c) Copyright 2013  
*      Electronics for Imaging, Inc. ("EFI").
*      All Rights Reserved
*
*  EFI products contain certain trade secrets and confidential and
*  proprietary information of EFI.  Use, reproduction, disclosure,
*  distribution by any means are prohibited, except pursuant to
*  a written license from EFI. Modification, translation, reverse
*  engineering, decompiling, disassembling, and creating derivative
*  works based on this software are prohibited, except pursuant to
*  a written license from EFI. Use of copyright notice does not imply
*  publication or disclosure.
*
*  Restricted Rights Legend:
*  Use, duplication, or disclosure by the Government is subject to
*  restrictions as set forth in subparagraph (c)(1)(ii) of The
*  Rights in Technical Data and Computer Software clause in DFARS
*  252.227-7013 or subparagraphs (c)(1) and (2) of the Commercial
*  Computer Software--Restricted Rights at 48 CFR 52.227-19, as
*  applicable.
*
**********************************************************************
*/
#pragma once

#include <stdio.h>
#include <limits.h>
#include <time.h>

#define IPP_DEF_CHUNKSIZE	(32*1024)

#define BITS_IN_int     ( sizeof(int) * CHAR_BIT )
#define THREE_QUARTERS	((int) ((BITS_IN_int * 3) / 4))
#define ONE_EIGHTH		((int) (BITS_IN_int / 8))
#define HIGH_BITS		( ~((unsigned int)(~0) >> ONE_EIGHTH ))

// All of the data below is from ippdefs.h

#define IPPLIB_MAX_TEXT_LEN	   1024
#define IPPLIB_MAX_URL_LEN     1024
#define IPPLIB_MAX_NAME_LEN    1024

#define IPPLIB_MAX_JOB_MEDIA   16

#define DEFAULT_USERNAME		"Fiery Central Client"
#define DEFAULT_DOCUMENTNAME	"Fiery Central Document"
#define DEFAULT_JOBNAME			"Fiery Central Job"
/*
*   Defines API Results
*/
typedef enum tagIppResult
{
    IPPLIB_SUCCESS = 0,
    IPPLIB_ERROR = 1,
    IPPLIB_INVALID_URL = 2,
    IPPLIB_CONNECT_FAILED = 3,
    IPPLIB_HTTP_ERROR = 4,
    IPPLIB_IPP_ERROR = 5,
    IPPLIB_MEDIA_UPDATE_BEGIN_ERROR = 6,
    IPPLIB_MEDIA_UPDATE_ADD_ERROR = 7,
    IPPLIB_MEDIA_UPDATE_END_ERROR = 7,

    IPPLIB_INVALID_PARAM    =  400,

    IPPLIB_INTERNAL_ERROR   =  500,
    IPPLIB_MEM_ERROR        =  501,
    IPPLIB_JOBSEND_TIMEOUT_ERROR = 502

} IPPLIB_RESULT;

// Defines Job States
typedef enum tagJobState
{
    IPP_JOB_STATE_PENDING = 3,
    IPP_JOB_STATE_PENDING_HELD,
    IPP_JOB_STATE_PROCESSING,
    IPP_JOB_STATE_STOPPED,
    IPP_JOB_STATE_CANCELLED,
    IPP_JOB_STATE_ABORTED,
    IPP_JOB_STATE_COMPLETED
} IPPLIB_JOBSTATE;

typedef enum tagJobStateReason
{
    IPP_JOB_STATE_REASON_NONE,
    IPP_JOB_STATE_REASON_JOB_INCOMING,
    IPP_JOB_STATE_REASON_JOB_DATA_INSUFFICIENT,
    IPP_JOB_STATE_REASON_DOCUMENT_ACCESS_ERROR,
    IPP_JOB_STATE_REASON_SUBMISSION_INTERRUPTED,
    IPP_JOB_STATE_REASON_JOB_OUTGOING,
    IPP_JOB_STATE_REASON_JOB_HOLD_UNTIL_SPECIFIED,
    IPP_JOB_STATE_REASON_RESOURCES_ARE_NOT_READY,
    IPP_JOB_STATE_REASON_PRINTER_STOPPED_PARTLY,
    IPP_JOB_STATE_REASON_PRINTER_STOPPED,
    IPP_JOB_STATE_REASON_JOB_INTERPRETING,
    IPP_JOB_STATE_REASON_JOB_QUEUED,
    IPP_JOB_STATE_REASON_JOB_TRANSFORMING,
    IPP_JOB_STATE_REASON_JOB_QUEUED_FOR_MARKER,
    IPP_JOB_STATE_REASON_JOB_PRINTING,
    IPP_JOB_STATE_REASON_JOB_CANCELED_BY_USER,
    IPP_JOB_STATE_REASON_JOB_CANCELED_BY_OPERATOR,
    IPP_JOB_STATE_REASON_JOB_CANCELED_AT_DEVICE,
    IPP_JOB_STATE_REASON_ABORTED_BY_SYSTEM,
    IPP_JOB_STATE_REASON_UNSUPPORTED_COMPRESSION,
    IPP_JOB_STATE_REASON_COMPRESSION_ERROR,
    IPP_JOB_STATE_REASON_UNSUPPORTED_DOCUMENT_FORMAT,
    IPP_JOB_STATE_REASON_DOCUMENT_FORMAT_ERROR,
    IPP_JOB_STATE_REASON_PROCESSING_TO_STOP_POINT,
    IPP_JOB_STATE_REASON_SERVICE_OFF_LINE,
    IPP_JOB_STATE_REASON_JOB_COMPLETED_SUCCESSFULLY,
    IPP_JOB_STATE_REASON_JOB_COMPLETED_WITH_WARNINGS,
    IPP_JOB_STATE_REASON_JOB_COMPLETED_WITH_ERRORS,
    IPP_JOB_STATE_REASON_JOB_RESTARTABLE,
    IPP_JOB_STATE_REASON_QUEUED_IN_DEVICE,
	IPP_JOB_STATE_REASON_OTHER
} IPPLIB_JOBSTATEREASON;

typedef struct {
    int nCount;
    int Reasons[64];
    char Strings[64][256];
    unsigned int String_IDs[64];
} IPPJOBSTATEREASONSTRUCT;

/*typedef struct {
    char * key;
    char * value;
} IPPPAGEOVERRIDES, * PTRIPPPAGEOVERRIDES;

typedef struct {
    int nCount;
    PTRIPPPAGEOVERRIDES pageOverrides;
} IPPPAGEOVERRIDEINFO;*/
/*
typedef enum tagWhichJob
{
    JOBS_NOT_COMPLETED =0,
    JOBS_COMPLETED = 1
} WHICH_JOBS;

typedef enum tagUserJobs
{
    ALL_JOBS =0,
    MY_JOBS = 1
} WHOSE_JOBS;

typedef struct{
	int		x_dim;
	int		y_dim;
} IPP_MEDIA_SIZE;

typedef struct {
	char	key				[IPPLIB_MAX_TEXT_LEN];	//media-key
	char	description		[IPPLIB_MAX_TEXT_LEN];	//media-description
	char	color			[IPPLIB_MAX_TEXT_LEN];	//media-color
	char	type			[IPPLIB_MAX_TEXT_LEN];	//media-type
	char	pre_printed		[IPPLIB_MAX_TEXT_LEN];	//media-pre-printed
	int		hole_count;							    //media-hole-count
	int		order_count;						    //media-order-count
	IPP_MEDIA_SIZE	size;						    //media-size
	int		weight_metric;						    //media-weight-metric
	char	info			[IPPLIB_MAX_TEXT_LEN];	//media-info
    char    recycled        [IPPLIB_MAX_TEXT_LEN];	//media-recycles
} IPP_MEDIA_INFO;
*/

class CIPPMediaSize
{
public:
	int	x_dim;
	int	y_dim;

public:
	CIPPMediaSize() { Init(); }
	virtual ~CIPPMediaSize() {;}

	void Init()
	{
		x_dim = 0;
		y_dim = 0;
	}
};

class CIPPMediaInfo
{
public:
	char	key				[IPPLIB_MAX_TEXT_LEN];	//media-key
	char	description		[IPPLIB_MAX_TEXT_LEN];	//media-description
	char	color			[IPPLIB_MAX_TEXT_LEN];	//media-color
	char	type			[IPPLIB_MAX_TEXT_LEN];	//media-type
	char	pre_printed		[IPPLIB_MAX_TEXT_LEN];	//media-pre-printed
	int		hole_count;							    //media-hole-count
	int		order_count;						    //media-order-count
	CIPPMediaSize size;								//media-size
	int		weight_metric;						    //media-weight-metric
	char	info			[IPPLIB_MAX_TEXT_LEN];	//media-info
    char    recycled        [IPPLIB_MAX_TEXT_LEN];	//media-recycles

public:
	CIPPMediaInfo() { Init(); }
	virtual ~CIPPMediaInfo() {;}

	void Init()
	{
		memset(key, 0, IPPLIB_MAX_TEXT_LEN);
		memset(description, 0, IPPLIB_MAX_TEXT_LEN);
		memset(color, 0, IPPLIB_MAX_TEXT_LEN);
		memset(type, 0, IPPLIB_MAX_TEXT_LEN);
		memset(pre_printed, 0, IPPLIB_MAX_TEXT_LEN);
		hole_count = 0;
		order_count = 0;
		size.Init();
		weight_metric = 0;
		memset(info, 0, IPPLIB_MAX_TEXT_LEN);
		memset(recycled, 0, IPPLIB_MAX_TEXT_LEN);
	}
};

#define IPP_MEDIA_SIZE			CIPPMediaSize
#define IPP_MEDIA_INFO			CIPPMediaInfo

typedef struct {
   int  sheets;
   int  impressions;
} IPP_COUNT_INFO;

typedef struct tagJobInfo_1
{
    unsigned int    jobID;
    char            jobName[IPPLIB_MAX_NAME_LEN];
    char            jobUrl[IPPLIB_MAX_URL_LEN];
    IPPLIB_JOBSTATE state;
    IPPJOBSTATEREASONSTRUCT reasons;
} IPPJOBINFO_1, *PTRIPPJOBINFO_1;

typedef struct tagJobInfo_2
{
    int             jobID;
    char            jobName[IPPLIB_MAX_NAME_LEN];
    char            jobUrl[IPPLIB_MAX_URL_LEN];
    IPPLIB_JOBSTATE state;
    IPPJOBSTATEREASONSTRUCT reasons;
    int             bytesProcessed;
    int             impressionsCompleded;
    int             mediaSheetsCompleded;
    time_t          dateTimeAtCreation;
    time_t          dateTimeAtProcessing;
    time_t          dateTimeAtCompleted;
    char           detailedStatusMessage[2048];
//    IPPPAGEOVERRIDEINFO     pageOverrides;
} IPPJOBINFO_2, *PTRIPPJOBINFO_2;

typedef struct tagPageOverride
{
    int startPage;
    int endPage;
    //char media[512];
    IPP_MEDIA_INFO media_col;
    char sides[512]; 
    int xImageShift;
    int yImageShift;
    int xSide1ImageShift;
    int xSide2ImageShift;
    int ySide1ImageShift;
    int ySide2ImageShift;
} IPPPAGEOVERRIDE, *PTRIPPPAGEOVERRIDE;

typedef struct tagBodyMedia
{
	char mediaKey[512];
} IPPBODYMEDIA, *PTRIPPBODYMEDIA;

typedef struct tagPageInsert
{
    int afterPage;    
    int count;
    //char media[512]; 
    IPP_MEDIA_INFO media_col;
} IPPPAGEINSERT, *PTRIPPPAGEINSERT;

typedef struct tagJobInfo_3
{
    int             jobID;
    char            jobName[IPPLIB_MAX_NAME_LEN];
    char            jobUrl[IPPLIB_MAX_URL_LEN];
    int             num_copies;
    int             num_media;
    struct {
       IPP_MEDIA_INFO  info;
       IPP_COUNT_INFO  counts;
    } media[IPPLIB_MAX_JOB_MEDIA];

//    IPPPAGEOVERRIDEINFO     pageOverrides;
} IPPJOBINFO_3, *PTRIPPJOBINFO_3;

typedef enum 
{
    IPP_PRT_STATE_IDLE,
    IPP_PRT_STATE_PROCESSING,
    IPP_PRT_STATE_STOPPED,
    IPP_PRT_STATE_UNKNOWN
} IPPPRINTERSTATE;

typedef enum {

    PRT_STATE_REASON_OTHER,
    PRT_STATE_REASON_OTHER_REPORT,
    PRT_STATE_REASON_OTHER_WARNING,
    PRT_STATE_REASON_OTHER_ERROR,

    PRT_STATE_REASON_NONE,
    PRT_STATE_REASON_NONE_REPORT,
    PRT_STATE_REASON_NONE_WARNING,
    PRT_STATE_REASON_NONE_ERROR,

    PRT_STATE_REASON_MEDIA_NEEDED,
    PRT_STATE_REASON_MEDIA_NEEDED_REPORT,
    PRT_STATE_REASON_MEDIA_NEEDED_WARNING,
    PRT_STATE_REASON_MEDIA_NEEDED_ERROR,
    
    PRT_STATE_REASON_MEDIA_JAM,
    PRT_STATE_REASON_MEDIA_JAM_REPORT,
    PRT_STATE_REASON_MEDIA_JAM_WARNING,
    PRT_STATE_REASON_MEDIA_JAM_ERROR,
    
    PRT_STATE_REASON_MOVING_TO_PAUSED,
    PRT_STATE_REASON_MOVING_TO_PAUSED_REPORT,
    PRT_STATE_REASON_MOVING_TO_PAUSED_WARNING,
    PRT_STATE_REASON_MOVING_TO_PAUSED_ERROR,

    PRT_STATE_REASON_PAUSED,
    PRT_STATE_REASON_PAUSED_REPORT,
    PRT_STATE_REASON_PAUSED_WARNING,
    PRT_STATE_REASON_PAUSED_ERROR,

    PRT_STATE_REASON_STOPPED,
    PRT_STATE_REASON_STOPPED_REPORT,
    PRT_STATE_REASON_STOPPED_WARNING,
    PRT_STATE_REASON_STOPPED_ERROR,

    PRT_STATE_REASON_SHUTDOWN,
    PRT_STATE_REASON_SHUTDOWN_REPORT,
    PRT_STATE_REASON_SHUTDOWN_WARNING,
    PRT_STATE_REASON_SHUTDOWN_ERROR,

    PRT_STATE_REASON_CONNECTING_TO_DEVICE,
    PRT_STATE_REASON_CONNECTING_TO_DEVICE_REPORT,
    PRT_STATE_REASON_CONNECTING_TO_DEVICE_WARNING,
    PRT_STATE_REASON_CONNECTING_TO_DEVICE_ERROR,

    PRT_STATE_REASON_TIMED_OUT,
    PRT_STATE_REASON_TIMED_OUT_REPORT,
    PRT_STATE_REASON_TIMED_OUT_WARNING,
    PRT_STATE_REASON_TIMED_OUT_ERROR,

    PRT_STATE_REASON_STOPPING,
    PRT_STATE_REASON_STOPPING_REPORT,
    PRT_STATE_REASON_STOPPING_WARNING,
    PRT_STATE_REASON_STOPPING_ERROR,

    PRT_STATE_REASON_STOPPED_PARTLY,
    PRT_STATE_REASON_STOPPED_PARTLY_REPORT,
    PRT_STATE_REASON_STOPPED_PARTLY_WARNING,
    PRT_STATE_REASON_STOPPED_PARTLY_ERROR,
    
    PRT_STATE_REASON_TONER_LOW,
    PRT_STATE_REASON_TONER_LOW_REPORT,
    PRT_STATE_REASON_TONER_LOW_WARNING,
    PRT_STATE_REASON_TONER_LOW_ERROR,

    PRT_STATE_REASON_TONER_EMPTY,
    PRT_STATE_REASON_TONER_EMPTY_REPORT,
    PRT_STATE_REASON_TONER_EMPTY_WARNING,
    PRT_STATE_REASON_TONER_EMPTY_ERROR,

    PRT_STATE_REASON_SPOOL_AREA_FULL,
    PRT_STATE_REASON_SPOOL_AREA_FULL_REPORT,
    PRT_STATE_REASON_SPOOL_AREA_FULL_WARNING,
    PRT_STATE_REASON_SPOOL_AREA_FULL_ERROR,

    PRT_STATE_REASON_COVER_OPEN,
    PRT_STATE_REASON_COVER_OPEN_REPORT,
    PRT_STATE_REASON_COVER_OPEN_WARNING,
    PRT_STATE_REASON_COVER_OPEN_ERROR,

    PRT_STATE_REASON_INTERLOCK_OPEN,
    PRT_STATE_REASON_INTERLOCK_OPEN_REPORT,
    PRT_STATE_REASON_INTERLOCK_OPEN_WARNING,
    PRT_STATE_REASON_INTERLOCK_OPEN_ERROR,

    PRT_STATE_REASON_DOOR_OPEN,
    PRT_STATE_REASON_DOOR_OPEN_REPORT,
    PRT_STATE_REASON_DOOR_OPEN_WARNING,
    PRT_STATE_REASON_DOOR_OPEN_ERROR,
    
    PRT_STATE_REASON_INPUT_TRAY_MISSING,
    PRT_STATE_REASON_INPUT_TRAY_MISSING_REPORT,
    PRT_STATE_REASON_INPUT_TRAY_MISSING_WARNING,
    PRT_STATE_REASON_INPUT_TRAY_MISSING_ERROR,
    
    PRT_STATE_REASON_MEDIA_LOW,
    PRT_STATE_REASON_MEDIA_LOW_REPORT,
    PRT_STATE_REASON_MEDIA_LOW_WARNING,
    PRT_STATE_REASON_MEDIA_LOW_ERROR,
    
    PRT_STATE_REASON_MEDIA_EMPTY,
    PRT_STATE_REASON_MEDIA_EMPTY_REPORT,
    PRT_STATE_REASON_MEDIA_EMPTY_WARNING,
    PRT_STATE_REASON_MEDIA_EMPTY_ERROR,
    
    PRT_STATE_REASON_OUTPUT_TRAY_MISSING,
    PRT_STATE_REASON_OUTPUT_TRAY_MISSING_REPORT,
    PRT_STATE_REASON_OUTPUT_TRAY_MISSING_WARNING,
    PRT_STATE_REASON_OUTPUT_TRAY_MISSING_ERROR,
    
    PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL,
    PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL_REPORT,
    PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL_WARNING,
    PRT_STATE_REASON_OUTPUT_AREA_ALMOST_FULL_ERROR,
    
    PRT_STATE_REASON_OUTPUT_AREA_FULL,
    PRT_STATE_REASON_OUTPUT_AREA_FULL_REPORT,
    PRT_STATE_REASON_OUTPUT_AREA_FULL_WARNING,
    PRT_STATE_REASON_OUTPUT_AREA_FULL_ERROR,
    
    PRT_STATE_REASON_MARKER_SUPPLY_LOW,
    PRT_STATE_REASON_MARKER_SUPPLY_LOW_REPORT,
    PRT_STATE_REASON_MARKER_SUPPLY_LOW_WARNING,
    PRT_STATE_REASON_MARKER_SUPPLY_LOW_ERROR,
    
    PRT_STATE_REASON_MARKER_SUPPLY_EMPTY,
    PRT_STATE_REASON_MARKER_SUPPLY_EMPTY_REPORT,
    PRT_STATE_REASON_MARKER_SUPPLY_EMPTY_WARNING,
    PRT_STATE_REASON_MARKER_SUPPLY_EMPTY_ERROR,
    
    PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL,
    PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL_REPORT,
    PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL_WARNING,
    PRT_STATE_REASON_MARKER_WASTE_ALMOST_FULL_ERROR,
    
    PRT_STATE_REASON_MARKER_WASTE_FULL,
    PRT_STATE_REASON_MARKER_WASTE_FULL_REPORT,
    PRT_STATE_REASON_MARKER_WASTE_FULL_WARNING,
    PRT_STATE_REASON_MARKER_WASTE_FULL_ERROR,
    
    PRT_STATE_REASON_FUSER_OVER_TEMP,
    PRT_STATE_REASON_FUSER_OVER_TEMP_REPORT,
    PRT_STATE_REASON_FUSER_OVER_TEMP_WARNING,
    PRT_STATE_REASON_FUSER_OVER_TEMP_ERROR,
    
    PRT_STATE_REASON_FUSER_UNDER_TEMP,
    PRT_STATE_REASON_FUSER_UNDER_TEMP_REPORT,
    PRT_STATE_REASON_FUSER_UNDER_TEMP_WARNING,
    PRT_STATE_REASON_FUSER_UNDER_TEMP_ERROR,

    PRT_STATE_REASON_OPC_NEAR_EOL,
    PRT_STATE_REASON_OPC_NEAR_EOL_REPORT,
    PRT_STATE_REASON_OPC_NEAR_EOL_WARNING,
    PRT_STATE_REASON_OPC_NEAR_EOL_ERROR,

    PRT_STATE_REASON_OPC_LIFE_OVER,
    PRT_STATE_REASON_OPC_LIFE_OVER_REPORT,
    PRT_STATE_REASON_OPC_LIFE_OVER_WARNING,
    PRT_STATE_REASON_OPC_LIFE_OVER_ERROR,

    PRT_STATE_REASON_DEVELOPER_LOW,
    PRT_STATE_REASON_DEVELOPER_LOW_REPORT,
    PRT_STATE_REASON_DEVELOPER_LOW_WARNING,
    PRT_STATE_REASON_DEVELOPER_LOW_ERROR,

    PRT_STATE_REASON_DEVELOPER_EMPTY,
    PRT_STATE_REASON_DEVELOPER_EMPTY_REPORT,
    PRT_STATE_REASON_DEVELOPER_EMPTY_WARNING,
    PRT_STATE_REASON_DEVELOPER_EMPTY_ERROR,

    PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE,
    PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE_REPORT,
    PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE_WARNING,
    PRT_STATE_REASON_INTERPRETER_RESOURCE_UNAVAILABLE_ERROR
} IPPPRINTERSTATEREASON;

typedef struct {
    int nCount;
    int Reasons[64];
    char Strings[64][256];
    unsigned int String_IDs[64];
} IPPPRINTERSTATEREASONSTRUCT;


typedef struct{
	char key[IPPLIB_MAX_NAME_LEN];
} IPPMEDIAREADYINFO;

typedef struct {
    int				nCount;
    IPPMEDIAREADYINFO	*mInfo;
} IPPMEDIAREADY;


typedef struct 
{
    char	name	[IPPLIB_MAX_NAME_LEN];
    char	model	[IPPLIB_MAX_NAME_LEN];
	char	location[IPPLIB_MAX_NAME_LEN];
	char	info	[IPPLIB_MAX_NAME_LEN];

} IPPPRINTERINFO, *PRTIPPPRINTERINFO;


typedef struct 
{
    char	**msg;
	int		count;
    char    *state_msg;

} IPPDETAILEDMSG, *PRTIPPDETAILEDMSG;


#define JOBTMPPL_OUTPUT_BIN_SYSTEM_SPECIFIED		NULL
#define JOBTMPPL_OUTPUT_BIN_SYSTEM_TOP				"Top"
#define JOBTMPPL_OUTPUT_BIN_SYSTEM_STACKER			"Stacker"

#define JOBTMPPL_PAGE_DELIVERY_SYSTEM_SPECIFIED		NULL
#define JOBTMPPL_PAGE_DELIVERY_SYSTEM_SPECIFIED1	"system-specified"
#define JOBTMPPL_PAGE_DELIVERY_FACE_UP				"same-order-face-up"
#define JOBTMPPL_PAGE_DELIVERY_FACE_DOWN			"same-order-face-down"


#define JOBTMPPL_SIDES_SYSTEM_SPECIFIED				NULL
#define JOBTMPPL_SIDES_ONE_SIDED					"one-sided"
#define JOBTMPPL_SIDES_TWO_SIDED_LONG_EDGE			"two-sided-long-edge"
#define JOBTMPPL_SIDES_TWO_SIDED_SHORT_EDGE			"two-sided-short-edge"


#define JOBTMPPL_COLLATION_SYSTEM_SPECIFIED			NULL
#define JOBTMPPL_COLLATION_COLLATED					"collated"
#define JOBTMPPL_COLLATION_UNCOLLATED				"uncollated"

#define JOBTMPPL_SLIP_SHEET_SYSTEM_SPECIFIED		NULL
#define JOBTMPPL_SLIP_SHEET_NONE					"none"
#define JOBTMPPL_SLIP_SHEET_YES						"slip-sheets"


typedef struct {
	int	 *copies;
	char *outputBin;
	char *pageDelivery;
	char *sides;
	char *collate;
	char *slipSheet;
	char *slipSheetStock;
} IPP_JOB_TEMPLATE;

typedef enum {
	MEDIALIST_UPDATE_BEGIN,
	MEDIALIST_UPDATE_ADD_ENTRY,
	MEDIALIST_UPDATE_END

} MEDIALIST_UPDATE_ACTION;

typedef int (*FNIPPMEDIAINFO)(unsigned long context,
                              MEDIALIST_UPDATE_ACTION action,
                              const IPP_MEDIA_INFO *info);

typedef unsigned long CONNECTIONHANDLE, *PTRCONNECTIONHANDLE;
typedef unsigned long PRINTJOBHANDLE, *PTRPRINTJOBHANDLE;
