// FCIPPJobObject.cpp

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	A macro that defines window 32 lean and mean. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers, Needed with CUPS

#include <windows.h>
#if __cplusplus
extern "C" {
#endif
#include "http-private.h"   // Cups external library
#if __cplusplus
}
#endif
#include <string>
#include <vector>
using namespace std;

#include "StringExtensions.h"
#include "DeviceJobList.h"
#include "JobConfDefines.h"
#include "FCIPPJobObject.h"
#include "FCIPPConnectionObject.h"
#include "FCIPPCommandsBase.h"
#include "SubJob.h"
#include <sys/stat.h>
#include "DevicePrintJobCache.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Constructor. </summary>
///
/// <remarks>	</remarks>
///
/// <param name="pFCIPPCommandsBase">	 	[in,out] If non-null, the fcipp commands base. </param>
/// <param name="pFCIPPConnectionObject">	[in,out] If non-null, the fcipp connection object. </param>
/// <param name="pSubJob">				 	[in,out] If non-null, the sub job. </param>
////////////////////////////////////////////////////////////////////////////////////////////////////

CFCIPPJobObject::CFCIPPJobObject(CFCIPPCommandsBase* pFCIPPCommandsBase, CFCIPPConnectionObject* pFCIPPConnectionObject, CDevicePrintJob* pDevicePrintJob)
{
	m_pFCIPPConnectionObject = pFCIPPConnectionObject;
	m_pFCIPPCommandsBase = pFCIPPCommandsBase;
	m_pDevicePrintJobCache = pFCIPPCommandsBase->GetDevicePrintJobCache();
	m_pPrintJobBase = pDevicePrintJob;
	m_pSubJob = pDevicePrintJob->m_pSubJob;
	m_strDeviceID = m_pFCIPPCommandsBase->GetDeviceID();
	Init();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Destructor. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

CFCIPPJobObject::~CFCIPPJobObject()
{
	if (pIPPRequest)
		ippDelete(pIPPRequest);

	if (pIPPResponse)
		ippDelete(pIPPResponse);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Initialises this object. </summary>
///
/// <remarks>	</remarks>
////////////////////////////////////////////////////////////////////////////////////////////////////

void CFCIPPJobObject::Init()
{
	memset(jobName, 0, IPPLIB_MAX_NAME_LEN);
	memset(userName, 0, IPPLIB_MAX_NAME_LEN);
	memset(jobUri, 0, HTTP_MAX_URI);
	jobID = 0;
	pIPPRequest = NULL;
	pIPPResponse = NULL;
	jobState = 0;
	error = 0;

	string strJobName = DEFAULT_JOBNAME;
	string strUserName = DEFAULT_USERNAME;

	if (NULL != m_pPrintJobBase)
	{
		strJobName = m_pPrintJobBase->m_strJobName;
		strUserName = m_pPrintJobBase->m_strActualUserNameSentToDevice;
		if (strUserName.empty())
			strUserName = m_pPrintJobBase->m_strJobUserName;
	}

	sprintf_s(jobName, IPPLIB_MAX_NAME_LEN, "%s", strJobName.c_str());
	sprintf_s(userName, IPPLIB_MAX_NAME_LEN, "%s", strUserName.c_str());
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// <summary>	Sends the job. </summary>
///
/// <remarks>	</remarks>
///
/// <returns>	An IPPLIB_RESULT error code if the function has passed or not. </returns>
////////////////////////////////////////////////////////////////////////////////////////////////////

IPPLIB_RESULT CFCIPPJobObject::SendJob()
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;
	jobID = 0;
	jobUri[0] = '\0';
	jobState = 0;

	if (m_pFCIPPConnectionObject)
	{
		ipp_t* request = pIPPRequest;
		http_t* http = m_pFCIPPConnectionObject->http;
		CCollatedJob* pJob = m_pSubJob->GetDeviceReadyJob();
		int iLastDeviceJobListID = 0;
		UINT uiMasterJobPrintNumber = m_pPrintJobBase->m_uiMasterJobPrintNumber;

		string strJobTicket = pJob->GetJobTicket();
		int iTicketSize = (int)strJobTicket.size();

		string strJobTicketEnd = pJob->GetJobTicketEnd();
		int iEndTicketSize = (int)strJobTicketEnd.size();

		struct stat fileinfo;
		stat(m_pSubJob->m_strJobFilename.c_str(), &fileinfo);
		FILE *pFile = fopen(m_pSubJob->m_strJobFilename.c_str(), "rb");

		if (pFile)
		{
			// Loop until we can send the request without authorization problems.
			char buffer[32768] = {0};
			ipp_t* response = NULL;
			char* resource = m_pFCIPPConnectionObject->resource;
			http_status_t status = HTTP_ERROR;
			char length[255] = {0};
			int bytes = 0;

			while (response == NULL)
			{
				sprintf(length, "%lu", (unsigned long)(ippLength(request) + (size_t)fileinfo.st_size) + iTicketSize + iEndTicketSize);

				httpClearFields(http);
				httpSetField(http, HTTP_FIELD_CONTENT_LENGTH, length);
				httpSetField(http, HTTP_FIELD_CONTENT_TYPE, "application/ipp");
				httpSetField(http, HTTP_FIELD_CONNECTION, "Keep-Alive");
				httpSetField(http, HTTP_FIELD_KEEP_ALIVE, "timeout=60");
				httpSetField(http, HTTP_FIELD_AUTHORIZATION, "");

				// Try the request...
				if (httpPost(http, resource))
				{
					if (httpReconnect(http))
					{
						status = HTTP_ERROR;
						break;
					}
					else
						continue;
				}
				
				// Send the IPP data and wait for the response...
				request->state = IPP_IDLE;

				if (ippWrite(http, request) != IPP_ERROR)
				{
					if (httpWrite(http, strJobTicket.c_str(), iTicketSize) == iTicketSize)
					{
						while ((bytes = (int)fread(buffer, 1, sizeof(buffer), pFile)) > 0)
						{
							if (httpWrite(http, buffer, bytes) < bytes)
								break;
						}

						if (strJobTicketEnd.empty() != true)
							bytes = httpWrite(http, strJobTicketEnd.c_str(), iEndTicketSize);
					}

					// Get the server's return status...
					while ((status = httpUpdate(http)) == HTTP_CONTINUE)
					{
						uiError = CheckForJobSendTimeout(uiMasterJobPrintNumber, false);
						if (uiError == IPPLIB_JOBSEND_TIMEOUT_ERROR)
							break;
					}

					if (uiError != IPPLIB_JOBSEND_TIMEOUT_ERROR)
						uiError = CheckForJobSendTimeout(uiMasterJobPrintNumber, false);

					if (uiError == IPPLIB_JOBSEND_TIMEOUT_ERROR)
					{
						status = HTTP_STATUS_REQUEST_TIMEOUT;
						if (response == NULL)
							response = ippNew();
					}

					if (status == HTTP_STATUS_OK)
					{
						// Read the response...
						response = ippNew();

						if (response)
						{
							if (ippRead(http, response) == IPP_ERROR)
							{
								uiError = IPPLIB_IPP_ERROR;
								ippDelete(response);
								response = NULL;
								break;
							}
							else
							{
								if (response->request.status.status_code > IPP_OK_CONFLICT)
								{
									CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPJobObject::SendJob: failed: %s", ippErrorString(response->request.status.status_code));
									// TODO: Set Good Error
									uiError = IPPLIB_ERROR;
								}
								else
								{
									ipp_attribute_t* attr = ippFindAttribute(response, "job-id", IPP_TAG_INTEGER);

									if (attr)
									{
										jobID = attr->values[0].integer;
										iLastDeviceJobListID = m_pFCIPPCommandsBase->GetLastDeviceJobListID();
										if (jobID > iLastDeviceJobListID)
											m_pFCIPPCommandsBase->SetLastDeviceJobListID(jobID);
										m_pSubJob->m_strRemotePQMID = FormatString("%d", jobID);
										CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPJobObject::SendJob: job-id = %d, FieryCentral Job Folder = FCSubJob_%d, SubJob ID = %d", jobID, m_pSubJob->m_uiJobPrintNumber, m_pSubJob->m_uiSubJobPrintNumber);
									}
									else
									{
										CLogUtils::LOG_UTILS_DEBUG("CFCIPPJobObject::SendJob: IPP Error did not find job-id attribute");
										uiError = IPPLIB_ERROR;
									}

									attr = ippFindAttribute(response, "job-uri", IPP_TAG_URI);

									if (attr)
									{
										strncpy(jobUri, attr->values[0].string.text, sizeof(jobUri)-1);
										jobUri[sizeof(jobUri)-1] = 0;
										CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPJobObject::SendJob: job-uri = %s", jobUri);
									}
									else
									{
										CLogUtils::LOG_UTILS_DEBUG("CFCIPPJobObject::SendJob: IPP Error did not find job-uri attribute");
										uiError = IPPLIB_ERROR;
									}

									attr = ippFindAttribute(response, "job-state", IPP_TAG_ENUM);
									if (attr)
									{
										jobState = (int)attr->values[0].integer;
										CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPJobObject::SendJob: job-state = %d", jobState);
									}
									else
									{
										CLogUtils::LOG_UTILS_DEBUG("CFCIPPJobObject::SendJob: IPP Error did not find job-state attribute");
										uiError = IPPLIB_ERROR;
									}
								}

								if (jobID == 0)
								{
									iLastDeviceJobListID = m_pFCIPPCommandsBase->GetNextLastDeviceJobListID();
									m_pSubJob->m_strProjectedRemotePQMID = FormatString("%d", iLastDeviceJobListID);
//									m_pSubJob->m_strRemotePQMID = FormatString("%d", jobID);
									CLogUtils::LOG_UTILS_EX(eDEBUG, "CFCIPPJobObject::SendJob: job-id = 0, projected id = %d, FieryCentral Job Folder = FCSubJob_%d, SubJob ID = %d", iLastDeviceJobListID, m_pSubJob->m_uiJobPrintNumber, m_pSubJob->m_uiSubJobPrintNumber);
								}
							}
						}
					}
				}
			}

			fclose(pFile);

			if (response)
			{
				ippDelete(response);
				response = NULL;
			}
		}
	}

	// we are done with request
	if (pIPPRequest)
	{
		ippDelete(pIPPRequest);
		pIPPRequest = NULL;
	}

	if (uiError != IPPLIB_SUCCESS)
	{
		error = 1;
		m_pFCIPPConnectionObject->do_reconnect = 1;
	}

	return uiError;
}

IPPLIB_RESULT CFCIPPJobObject::CheckForJobSendTimeout(UINT uiMasterJobPrintNumber, bool bCheckJobStatus)
{
	IPPLIB_RESULT uiError = IPPLIB_SUCCESS;

	if ((m_pPrintJobBase == NULL) || (m_pDevicePrintJobCache == NULL))
		return IPPLIB_JOBSEND_TIMEOUT_ERROR;

	CJob* pParentJob = m_pDevicePrintJobCache->GetDevicePrintJobFromJobID(uiMasterJobPrintNumber);
	if (pParentJob != NULL)
	{
		if (bCheckJobStatus && (m_pPrintJobBase->m_iJobStatusMode > JOBLIST_STATUS_MODE_SUSPENDED))
		{
			uiError = IPPLIB_JOBSEND_TIMEOUT_ERROR;
			CLogUtils::LOG_UTILS_EX(eERROR, "CFCIPPJobObject::CheckForJobSendTimeout: Timed Out waiting for IPP Status, FieryCentral device = %s, Job Folder = FCSubJob_%d, SubJob ID = %d", m_strDeviceID.c_str(), m_pSubJob->m_uiJobPrintNumber, m_pSubJob->m_uiSubJobPrintNumber);
		}
	}
	else
	{
		m_pPrintJobBase = NULL;
		uiError = IPPLIB_JOBSEND_TIMEOUT_ERROR;
		CLogUtils::LOG_UTILS_EX(eERROR, "CFCIPPJobObject::SendJob: Timed Out error set(IPPLIB_JOBSEND_TIMEOUT_ERROR) for device %s", m_strDeviceID.c_str());
	}

	return uiError;
}
